import gurobipy as gp
from gurobipy import GRB
import gurobipy as grb
import pandas as pd
from datetime import datetime, timedelta
import time
import json
from statistics import mean, stdev
import RQ4_06_Functions, RQ4_05_DataInput

class TDM():

    def __init__(self):
        self.tools = []
        self.pallets = []

class ERP():

    def __init__(self):
        self.jobs = []

class JOB():

    def __init__(self, id, ncRef, cycle, ta, pa, precedingOperation):
        self.id = id
        self.ncRef = ncRef
        self.cycle = cycle
        self.ta = ta
        self.pa = pa
        self.precedingOperation = precedingOperation
        self.toolstorage = []
        self.toolinsert = []

class TD():

    def __init__(self):
        self.machines = []

class Shopfloor():

    def __init__(self, cncCapacity, palletCapacity, jobIdList, xrefJobNc, ncDatabase, xrefJobPrecedence, inputParameters):
        
        self.tdm = TDM()
        self.erp = ERP()
        self.td = TD()

        palletSetupTime = inputParameters['palletSetupTime']
        toolMax = inputParameters['toolMax']

        self.horizon = 0

        for machineId in range(cncCapacity):
            self.td.machines.append(machineId)

        for palletId in range(palletCapacity):
            self.tdm.pallets.append(palletId)

        for jobId in jobIdList:
            ncRef = xrefJobNc[jobId]
            cycle = ncDatabase[ncRef]['cycle']
            ta = ncDatabase[ncRef]['ta'][:toolMax]
            pa = ncDatabase[ncRef]['pa']
            addJob = JOB(jobId, ncRef, cycle, ta, pa, xrefJobPrecedence[jobId])
            self.erp.jobs.append(addJob)
            for tnumber in ta:
                if tnumber not in self.tdm.tools:
                    self.tdm.tools.append(tnumber)
            self.horizon += (cycle + palletSetupTime)

        self.reconfigureMatrix = dict()
        for job1 in self.erp.jobs:
            for job2 in self.erp.jobs:
                if job1 != job2:
                    if job1.pa == job2.pa:
                        self.reconfigureMatrix[(job1,job2)] = 1
                    else:
                        self.reconfigureMatrix[(job1,job2)] = 0

        self.erp.jobs.sort(key=lambda job: job.id)
        self.td.machines.sort()
        self.tdm.pallets.sort()
        self.tdm.tools.sort()

        print('Jobs:     {}'.format([job.id for job in self.erp.jobs]))
        print('Machines: {}'.format(self.td.machines))
        print('Pallets:  {}'.format(self.tdm.pallets))
        print('Tools:    {}'.format(self.tdm.tools))
