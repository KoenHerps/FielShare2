from asyncio.format_helpers import extract_stack
from datetime import datetime, time, timedelta
from doctest import testfile
from re import S
# from statistics import mean, stdev
import time as timeDouble
# from lib2to3.pgen2.pgen import generate_grammar
# from msilib import sequence
# from numpy.core.numeric import False
# from multiprocessing import Pool
# from multiprocessing import Process
import multiprocessing
from tkinter import N, TRUE
from typing import overload
import pandas as pd
# import simpy
import numpy as np
import random
import math
# import threading
# import sys
# from tqdm import tqdm
# import csv
import json
# from simpy import AllOf, Event
# from itertools import count
# import gurobipy as gp
# from gurobipy import GRB
from RQ4_01_Model_GA import Chromosome, Generation, GaCalcFitness, GaRandomChromosome, GaSelectMatingPool, GaSafeguard, GaSelectParents, GaUX, GaOX, GaPMX, GaMSwap, GaMInv, GaMIns
from RQ4_02_Model_MILP import MilpCalcFitness
from RQ4_02_Model_PH import PhBuildSequences
from RQ4_05_DataInput import GetProductData, GenerateJobs, GeneratePalletNc, getEmpiricalData, ClusterInitialData, ChangeNcDatabases
from RQ4_08_RLA import RLA
# from RQ4_06_Functions import calculateChangeIndex

runPH = False
runGA = False
runGARL = False
runMILP = True

rlaTuning = False

rlaOperDiv = 1                  ## number of classes within operator, index on 0
rlaGaGenerationsMax = 1         ## number of GA genarations before RL agent iterates
rlaEpIterMax = 250              ## number of RL iterations within one episode
rlaEpMax = 10                   ## number of RL episodes

rlaAlphas = [0.75]                     ## impact of new value on overall value
rlaGammas = [0.2]                     ## impact of future reward with respect to immediate rewards
if rlaTuning:
    rlaEpsilon = 0.85                  ## chance of selecting an random action
else:
    rlaEpsilon = 0

runExperiments = True  # control variable to preempt experiment running
omitExperiments = 0    # make 0 to start at experiment 1, 2 to start at experiment 3, etcetera
stopExperiments = -1    # make -1 to stop until the end. Otherwise stop AFTER the id in stopExperiment, so stopExperiment is included.
experimentsDict = {}

workloadOrg = 763
sToolOrg = 1
gPalOrg = 50    ## refers to the amount of jobs that use the same pallet ==> if 50 jobs, only 1 pallet, 100 jobs 2 pallets etcetera
sPalOrg = 12

mainTests = ['ProblemSize']  #   ['BaseCase', 'ProblemSize', 'Sensitivity']    
for mainTest in mainTests:
    experimentsDict[mainTest] = {}
    if mainTest == 'BaseCase':
        keys = ['B']
        values = [0]
        for key in keys:
            experimentsDict[mainTest][key] = values
    if mainTest == 'ProblemSize':
        keys = ['W']        ## workload                   1x (308 uur)   3x   5x   7x
        # values = [20, 25, 30, 40, 50, 70, 100, 140, 190, 250, 310, 380, 480, 600, 763]
        values = [1,2,3,4,5]
        for key in keys:
            experimentsDict[mainTest][key] = values
    if mainTest == 'Sensitivity':
        # keys = ['TH', 'AM', 'S', 'PH']
        keys = ['TH']
        for key in keys:
            if key == 'TH':  ## Heterogeniety, if != 1, ratio is relative change in tools/pallets
                values = [0.6, 0.7]
                # values = [0.6, 0.7, 0.8, 0.9, 1.1, 1.2, 1.3, 1.4]
                experimentsDict[mainTest][key] = values
            if key == 'AM':  ## Additive Manufacturing, a percentage of the jobs are "Additive Manufacturing" -- 10% processing times, first setup also specific pallet
                values = [0.4]
                # values = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4]
                experimentsDict[mainTest][key] = values
            if key == 'S':  ## delay, incurred delay after tool switch
                values = [10, 8]
                # values = [24, 22, 20, 16, 14, 12, 10, 8]
                experimentsDict[mainTest][key] = values
            if key == 'PH':
                values = [0.2, 0.4, 0.6, 0.8, 1.2, 1.4, 1.6, 1.8]
                # values = [0.2, 0.4, 0.6, 0.8, 1.2, 1.4, 1.6, 1.8]
                experimentsDict[mainTest][key] = values

## GENERAL DATA INPUT

if rlaTuning:
    conversionReached = False
    runs = int(rlaEpMax * rlaEpIterMax) ## total allowed actions * number of episodes
else:
    conversionReached = True
    runs = 10

## Crossover parameters

cMethods = ['UX', 'OX', 'PMX', 'OX + UX-R']
cWeights = [0,1,0,0]
cProbList = [0.05, 0.2]
cProb = cProbList[1]

## Mutation parameters

mMethods = ['SWAP', 'INV.', 'INS.']
mMethod = 0
mProbList = [0.05, 0.2]
mProb = mProbList[0]

## Overall parameters

cncCapacity = 3
toolCapacity = 60
palletCapacity = cncCapacity * 8
supervisedShift = 18

operMax = 9999
toolMax = toolCapacity

cncDepreciationCost = 40
toolSwitchCost = 10
palletSetupTime = 60 * 4
palletSetupCost = 200
inputParametersFix = {'cncDepreciationCost': cncDepreciationCost, 'toolSwitchCost': toolSwitchCost, 'palletSetupTime': palletSetupTime, 'palletSetupCost': palletSetupCost, 'cncCapacity': cncCapacity, 'toolCapacity': toolCapacity, 'palletCapacity': palletCapacity, 'supervisedShift': supervisedShift, 'operMax': operMax, 'toolMax': toolMax, 'cMethods': cMethods, 'cWeights': cWeights, 'cProb': cProb, 'mMethods': mMethods, 'mMethod': mMethod, 'mProb': mProb}

k = 0
ct = timeDouble.time()
ctPrint = timeDouble.strftime('%Y-%m-%d %H:%M:%S', timeDouble.localtime(ct))
ctMaxMinutes = 60
ctMax = ct + (ctMaxMinutes * 60)            # in seconds

## GENERATION PARAMETERS

kMaxValues = [20]                    ## number of generations (+1 because of tuning)
kMax = kMaxValues[0]
populationSizes = [240] # [60, 240]
populationSize = populationSizes[0]                    # refers to the number of unique chromosomes in a generation

## Selection OPERATOR PARAMETERS

selectParentsMethods = ['Tournament Selection']
selectParentsMethod = selectParentsMethods[0]  # or 'Tournament Selection' / 'random'
tournamentSizes = [4]   # [4]
defTournamentSize = tournamentSizes[0]
tournamentReqSize = tournamentSizes[0]                                             ## tournament size of previous generation to next mating pool
elitismRates = [0.9]   # [0.1, 0.9]
elitismRate = elitismRates[0]                                           ## elitism rate, SELECTION                                        ## tournament rate, SELECTION
tournamentRates = [0.9]    # [0.1, 0.9]
tournamentRate = tournamentRates[0]

class Experiment():

    experiments = []

    def __init__(self, id, cWeights, cProb, mMethod, mProb, tournamentReqSize, tournamentRate, elitismRate, populationSize, kMax):

        self.id = id
        self.cWeights = cWeights
        self.cProb = cProb
        self.mMethod = mMethod
        self.mProb = mProb
        self.tournamentReqSize = tournamentReqSize
        self.tournamentRate = tournamentRate
        self.elitismRate = elitismRate
        self.populationSize = populationSize
        self.kMax = kMax

        ##
        self.timesGARL = 0

        self.chromosomes = []
        Experiment.experiments.append(self)

        self.currentK = 0
        self.generations = []
        self.bestResult = 9999999
        self.leadBest = 999999
        self.toolBest = 999999
        self.palletBest = 9999999
        self.topChromosomes = []
        self.topChromosomesWorst = 9999999

def GeneticAlgorithm(initialData, mainTest, experiment, expParameter, inputParametersGA, expParameters, tuning, RLActive):

    gPal = expParameters['Pallet'][0]
    sPal = expParameters['Pallet'][1]

    omit = 0

    # initialData = [jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, actToolStorage, jobFamily]
    jobList = initialData[0]
    xrefJobPrecedence = initialData[3]

    cncCapacity = inputParametersGA['cncCapacity']
    palletCapacity = inputParametersGA['palletCapacity']

    cMethods = inputParametersGA['cMethods']
    cWeights = inputParametersGA['cWeights']
    cProb = inputParametersGA['cProb']
    mMethods = inputParametersGA['mMethods']
    mProb = inputParametersGA['mProb']

    runFrom = 'GA'
    experimentId = 0
    expResultsGA = []
    runExperiments = True

    for kMaxIndex in range(len(kMaxValues)):                                            # include, set to 20
        for populationIndex in range(len(populationSizes)):                             # include, 60, 240
            for elitismIndex in range(len(elitismRates)):                               # include, 0.1, 0.9
                for tournamentRateIndex in range(len(tournamentRates)):                 # include, 0.1, 0.9
                    for tournamentSizeIndex in range(len(tournamentSizes)):             # exclude, set to 4
                        for rlaAlphaIndex in range(len(rlaAlphas)):                     # include, 
                            for rlaGammaIndex in range(len(rlaGammas)):                 # include                        
                                experimentId += 1
                                Chromosome.id = 0
                                defTournamentSize = tournamentSizes[tournamentSizeIndex]
                                tournamentRate = tournamentRates[tournamentRateIndex]
                                elitismRate = elitismRates[elitismIndex]
                                populationSize = populationSizes[populationIndex]
                                kMax = kMaxValues[kMaxIndex]

                                rlaAlpha = rlaAlphas[rlaAlphaIndex]
                                rlaGamma = rlaGammas[rlaGammaIndex]              
                                
                                print('#############################################################')
                                print('          Start experiment ID: {}'.format(experimentId))
                                print('#############################################################')
                                print('   K Max generations:   \t {} \t | \t from: {}'.format(kMax, kMaxValues))
                                print('   Population size:     \t {} \t | \t from: {}'.format(populationSize, populationSizes))
                                print('   Elitism rate:        \t {} \t | \t from: {}'.format(elitismRate, elitismRates))
                                print('   Tournament rate:     \t {} \t | \t from: {}'.format(tournamentRate, tournamentRates))
                                print('   Tournament size:     \t {} \t | \t from: {}'.format(tournamentReqSize, tournamentSizes))
                                print('   RL-Alpha:            \t {} \t | \t from: {}'.format(rlaAlpha, rlaAlphas))
                                print('   RL-Gamma:            \t {} \t | \t from: {}'.format(rlaGamma, rlaGammas))
                                print('   RL-Epsilon:          \t {}'.format(rlaEpsilon))

                                omit += 1

                                if (omit <= omitExperiments) or (runExperiments == False):
                                    print()
                                    print('skip this one')
                                    print()
                                    continue
                                    

                                ## initiate experiment

                                runResultsGA = []
                                simResultsGA = []
                                genResultsGA = []

                                expImmigrants = 0
                                expOffsprings = 0
                                expDuplicates = 0

                                GARL = RLA(rlaEpMax, rlaEpIterMax, rlaAlpha, rlaGamma, rlaEpsilon, rlaOperDiv, len(cProbList), len(mMethods), len(mProbList), conversionReached)
                                if rlaTuning:
                                    GARL.currState = 0
                                else:
                                    q_table_best = pd.read_excel(r'GRL_Qtable_Best_{}{}{}{}{}{}.xlsx'.format(kMax, populationSize, elitismRate, tournamentRate, rlaAlpha, rlaGamma), engine='openpyxl', sheet_name='Q_Table')
                                    q_dict_best = q_table_best.to_dict('index')
                                    for k in q_dict_best.keys():
                                        newVal = []
                                        for key, value in q_dict_best[k].items():
                                            newVal.append(value)
                                        q_dict_best[k] = newVal
                                    q_table_avg = pd.read_excel(r'GRL_Qtable_Avg_{}{}{}{}{}{}.xlsx'.format(kMax, populationSize, elitismRate, tournamentRate, rlaAlpha, rlaGamma), engine='openpyxl', sheet_name='Q_Table')
                                    q_dict_avg = q_table_avg.to_dict('index')
                                    for k in q_dict_avg.keys():
                                        newVal = []
                                        for key, value in q_dict_avg[k].items():
                                            newVal.append(value)
                                        q_dict_avg[k] = newVal
                                    q_table_diff = pd.read_excel(r'GRL_Qtable_Diff_{}{}{}{}{}{}.xlsx'.format(kMax, populationSize, elitismRate, tournamentRate, rlaAlpha, rlaGamma), engine='openpyxl', sheet_name='Q_Table')
                                    q_dict_diff = q_table_diff.to_dict('index')
                                    for k in q_dict_diff.keys():
                                        newVal = []
                                        for key, value in q_dict_diff[k].items():
                                            newVal.append(value)
                                        q_dict_diff[k] = newVal
                                    GARL.Q_best = q_dict_best
                                    GARL.Q_avg = q_dict_avg
                                    GARL.Q_diff = q_dict_diff
                                    if RLActive:
                                        GARL.currState, GARL.currAction = GARL.loadQTable(GARL.Q_diff)
                                    else:
                                        GARL.currState = 44
                                        GARL.currAction = 7
                                    print('Start at State: {} at action: {}'.format(GARL.currState, GARL.currAction))
                                cWeights, cProbIdx, mMethodIdx, mProbIdx = GARL.initializeRL(rlaTuning)
                                print('Next state: {}'.format(GARL.nextState))
                                mMethod = mMethods[mMethodIdx]
                                cProb, mProb = cProbList[cProbIdx], mProbList[mProbIdx] 
                                
                                    ## add code to load Qtable and set operators
                                print()
                                print('\tTune case cross weights: {}'.format(cWeights))
                                print('\tTune case cross prob.:   {}'.format(cProb))
                                print('\tTune case mutate method: {}'.format(mMethod))
                                print('\tTune case mutate prob.:  {}'.format(mProb))
                                print()

                                for run in range(runs):

                                    currExperiment = Experiment(experimentId, cWeights, cProb, mMethod, mProb, tournamentReqSize, tournamentRate, elitismRate, populationSize, kMax)

                                    runPrint = run + 1

                                    ctRunSim = 0

                                    runOffsprings = 0
                                    runImmigrants = 0
                                    runDuplicates = 0

                                    GARL.generations = []
                                    activateGARL = 0

                                    currExperiment.currentK = 0
                                    currExperiment.generations = []
                                    currExperiment.bestResult = 9999999

                                    bestChromosome = None

                                    currentGeneration = Generation(currExperiment)
                                    # GaRandomChromosome(jobList, xrefJobPrecedence, currExperiment, cncCapacity, palletCapacity, currentGeneration, True, False)
                                    manager = multiprocessing.Manager()
                                    resultDatabase = manager.dict()

                                    k = 0
                                    ct = timeDouble.time()
                                    startRun = ct
                                    # ctPrint = timeDouble.strftime('%Y-%m-%d %H:%M:%S', timeDouble.localtime(ct))
                                    ctMax = ct + (60*60)            # second parameter is amount of minutes

                                    ## start run

                                    print('-----------------------')
                                    print('Experiment {}, Run {} -- Start!'.format(experimentId, runPrint))
                                    print()

                                    while (ct < ctMax) and (k < kMax):                            ## loop to control termination of GA

                                        k += 1

                                        if currentGeneration.k < 10:
                                            printK = ' ' + str(k)
                                        else:
                                            printK = str(k)

                                        # improve = Generation.bestResult == Generation.lastResult                ## calculate if the last result improved the final outcome [True/False]

                                        simOffsprings = 0
                                        simImmigrants = 0
                                        simDuplicates = 0

                                        countPopulationIterations = 0

                                        while len(currentGeneration.population) < populationSize:
                                            countPopulationIterations += 1
                                            crossover = False
                                            if len(currentGeneration.matingPool) > 1:
                                                runOffsprings += 1
                                                expOffsprings += 1
                                                simOffsprings += 1
                                                crossover = True
                                                selectedParents = GaSelectParents(currentGeneration, selectParentsMethod, defTournamentSize)
                                                cMethod = random.choices(cMethods, weights=cWeights, k=1)[0]
                                                if cMethod in ['UX']:
                                                    offspringChildren = GaUX(currentGeneration, currExperiment, selectedParents, cMethod, cProb, crossover, True)
                                                elif cMethod in ['OX']:
                                                    offspringChildren = GaOX(currentGeneration, currExperiment, selectedParents, cMethod, cProb, crossover, True)
                                                elif cMethod in ['PMX']:
                                                    offspringChildren = GaPMX(currentGeneration, currExperiment, selectedParents, cMethod, cProb, crossover, True)
                                                elif cMethod in ['OX + UX-R']:
                                                    offspringChildren = GaOX(currentGeneration, currExperiment, selectedParents, 'OX', cProb, crossover, True)
                                                    offspringChildren = GaUX(currentGeneration, currExperiment, offspringChildren, 'UX-R', cProb, crossover, False)
                                                if mMethod == 'SWAP':
                                                    mutatedChromosomes = GaMSwap(offspringChildren, mMethod, mProb)
                                                elif mMethod == 'INV.':
                                                    mutatedChromosomes = GaMInv(offspringChildren, mMethod, mProb)
                                                elif mMethod == 'INS.':
                                                    mutatedChromosomes = GaMIns(offspringChildren, mMethod, mProb)
                                            else:
                                                runImmigrants += 1
                                                expImmigrants += 1
                                                simImmigrants += 1
                                                if len(currentGeneration.population) > 0:
                                                    GaRandomChromosome(jobList, xrefJobPrecedence, currExperiment, cncCapacity, palletCapacity, currentGeneration, True, 1, False)
                                                else:
                                                    sequenceVector, machineVector, palletVector = PhBuildSequences(initialData, inputParametersGA)
                                                    phChromosome = Chromosome(currExperiment, currentGeneration, sequenceVector, machineVector, palletVector, 'Random', 'Random', '-', '-', False)
                                                    currentGeneration.population.append(phChromosome)
                                                mutatedChromosomes = [currentGeneration.population[-1]]
                                            checkChromosomes = [[x.sequenceVector, x.machineVector, x.palletVector] for x in currExperiment.chromosomes if (x not in mutatedChromosomes) if (x.obsolete == False)]
                                            fromMatingPool = True
                                            for chromosome in mutatedChromosomes:
                                                geneRepresentation = GaSafeguard(jobList, xrefJobPrecedence, [chromosome.sequenceVector, chromosome.machineVector, chromosome.palletVector])
                                                if (geneRepresentation in checkChromosomes) or (len(currentGeneration.population) > populationSize):
                                                    if chromosome in currentGeneration.population:
                                                        currentGeneration.population.remove(chromosome)
                                                    chromosome.obsolete = True
                                                    runDuplicates += 1
                                                    expDuplicates += 1
                                                    simDuplicates += 1
                                                else:
                                                    chromosome.sequenceVector = geneRepresentation[0]
                                                    chromosome.machineVector = geneRepresentation[1]
                                                    chromosome.palletVector = geneRepresentation[2]
                                                    if crossover:
                                                        currentGeneration.population.append(chromosome)
                                                        if fromMatingPool:
                                                            fromMatingPool = False
                                                            for parent in selectedParents:
                                                                currentGeneration.matingPool.remove(parent)
                                            if len(currentGeneration.population) > populationSize:
                                                raise('Population size not according to GA rules')
                                            if countPopulationIterations > populationSize:
                                                now = datetime.now()
                                                currentTime = now.strftime('%H:%M:%S')
                                                print('[{}]: Generation {}: Difficulties creating population!'.format(currentTime, printK))

                                        # now = datetime.now()
                                        # currentTime = now.strftime('%H:%M:%S')
                                        # print('[{}]: Generation {}: Population created! Total pool length: {}'.format(currentTime, printK, len(currExperiment.chromosomes)))

                                        evaluateChromosomes = [x for x in currentGeneration.population if x.fitnessValue == None]
                                        for chromosome in evaluateChromosomes:
                                            startSim = timeDouble.time()
                                            # with open('RQ2_03_Debug_Chromosome_sequenceVector.json', 'w') as fp:
                                            #     json.dump(chromosome.sequenceVector, fp)
                                            # with open('RQ2_03_Debug_Chromosome_machineVector.json', 'w') as fp:
                                            #     json.dump(chromosome.machineVector, fp)
                                            # with open('RQ2_03_Debug_Chromosome_palletVector.json', 'w') as fp:
                                            #     json.dump(chromosome.palletVector, fp)                                                        
                                            geneRepresentation = [chromosome.sequenceVector, chromosome.machineVector, chromosome.palletVector]
                                            
                                            objectiveFunctionValue, makespanCost, toolSwitchCost, palletSetupCost, invalidRun = GaCalcFitness(initialData, chromosome.id, geneRepresentation, resultDatabase, inputParametersGA, runFrom)
                                            resultDatabase[chromosome.id] = [objectiveFunctionValue, makespanCost, toolSwitchCost, palletSetupCost]
                                            
                                            duration = (timeDouble.time() - startSim) / 60      # in minutes
                                            ctRunSim += duration
                                            chromosomeResults = resultDatabase[chromosome.id]
                                            chromosome.fitnessValue = chromosomeResults[0]
                                            chromosome.leadCost = chromosomeResults[1]
                                            chromosome.toolCost = chromosomeResults[2]
                                            chromosome.palletCost = chromosomeResults[3]
                                            chromosome.generation.allResults.append(chromosome.fitnessValue)
                                            chromosome.generation.avgResult = sum(chromosome.generation.allResults) / len(chromosome.generation.allResults)
                                            if chromosome.generation.bestGenerationResult > chromosome.fitnessValue:
                                                chromosome.generation.bestGenerationResult = chromosome.fitnessValue
                                                chromosome.generation.bestChromosome = chromosome
                                            # simResultsGA.append([mainTest, experiment, expParameter, experimentId, runPrint, chromosome.generation.experiment.currentK, chromosome.id, chromosome.parent1, chromosome.parent2, chromosome.fitnessValue, chromosome.leadCost, chromosome.toolCost, chromosome.palletCost, simOffsprings, simImmigrants, simDuplicates, populationSize, elitismRate, tournamentRate, cMethodChr, cProb, mMethodChr, mProb, k, duration, chromosome.sequenceVector, chromosome.machineVector, chromosome.palletVector, invalidRun])
                                            if currExperiment.bestResult > chromosome.fitnessValue:
                                                currExperiment.bestResult = chromosome.fitnessValue
                                                currExperiment.leadBest = chromosome.leadCost
                                                currExperiment.toolBest = chromosome.toolCost
                                                currExperiment.palletBest = chromosome.palletCost
                                                bestChromosome = chromosome
                                            if (chromosome.fitnessValue < currExperiment.topChromosomesWorst) or (len(currExperiment.topChromosomes) < populationSize):
                                                if len(currExperiment.topChromosomes) >= populationSize:
                                                    currExperiment.topChromosomes.pop(-1)
                                                currExperiment.topChromosomes.append(chromosome)
                                                currExperiment.topChromosomes.sort(key=lambda x: x.fitnessValue, reverse=False)
                                                currExperiment.topChromosomesWorst = currExperiment.topChromosomes[-1].fitnessValue
                                        # print('-------------')
                                        
                                        # now = datetime.now()
                                        # currentTime = now.strftime('%H:%M:%S')
                                        # print('[{}]: Generation {}: Population evaluated!'.format(currentTime, printK))

                                        now = datetime.now()
                                        currentTime = now.strftime('%H:%M:%S')
                                        print('[{}]: Generation {}: OBJECTIVE FUNCTION VALUE = {}\t[Lead: {} - Tool: {} - Pallet: {}]'.format(currentTime, printK, round(currentGeneration.bestGenerationResult), int(round(currentGeneration.bestChromosome.leadCost, 0)), int(round(currentGeneration.bestChromosome.toolCost, 0)), int(round(currentGeneration.bestChromosome.palletCost, 0))))

                                        if RLActive:
                                            if (GARL.running):               
                                                GARL.generations.append(currentGeneration)
                                                if k > 1:
                                                    GARL.analyzeRL(GARL.generations, k, kMax)
                                                    GARL.updateRL(k)
                                                    print('Immediate reward Best:  {}'.format(GARL.immediateReward_best))
                                                    print('Immediate reward Avg:   {}'.format(GARL.immediateReward_avg))
                                                    print('Immediate reward Diff:  {}'.format(GARL.immediateReward_diff))
                                                    print()
                                                    if (rlaTuning):
                                                        cWeights, cProbIdx, mMethodIdx, mProbIdx = GARL.iterateRL(k, kMax)
                                                        mMethod = mMethods[mMethodIdx]
                                                        cProb, mProb = cProbList[cProbIdx], mProbList[mProbIdx] 
                                                        if GARL.overallIter >= ((GARL.nStates * GARL.nActionsAvg) / 2):
                                                            printReached = True
                                                        else:
                                                            printReached = False
                                                        print('Conversion reached [{}]: {} >= {} ({} * {} / 2)'.format(printReached, GARL.overallIter, ((GARL.nStates * GARL.nActionsAvg) / 2), GARL.nStates, round(GARL.nActionsAvg, 2)))
                                                        print()
                                                        print('\tTune case cross weights: {}'.format(cWeights))
                                                        print('\tTune case cross prob.:   {}'.format(cProb))
                                                        print('\tTune case mutate method: {}'.format(mMethod))
                                                        print('\tTune case mutate prob.:  {}'.format(mProb))
                                                        print()
                                                    else:
                                                        immediateReward = 0
                                                        GARL.phase = GARL.getPhase(k, kMax)
                                                        print('Currently in phase: {}'.format(GARL.phase))
                                                        print()
                                                        if GARL.phase == 'diversify population':
                                                            immediateReward = GARL.immediateReward_diff
                                                        elif GARL.phase == 'avgerage population':
                                                            immediateReward = GARL.immediateReward_avg
                                                        else:
                                                            immediateReward = GARL.immediateReward_best
                                                        if immediateReward <= 0:
                                                            cWeights, cProbIdx, mMethodIdx, mProbIdx = GARL.iterateRL(k, kMax)
                                                            mMethod = mMethods[mMethodIdx]
                                                            cProb, mProb = cProbList[cProbIdx], mProbList[mProbIdx] 
                                                            # # GARL.iterRL = 0
                                                            # GARL.generations = []
                                                            print()
                                                            print('\tTune case cross weights: {}'.format(cWeights))
                                                            print('\tTune case cross prob.:   {}'.format(cProb))
                                                            print('\tTune case mutate method: {}'.format(mMethod))
                                                            print('\tTune case mutate prob.:  {}'.format(mProb))
                                                            print()

                                                            currExperiment.timesGARL += 1
                                                            activateGARL += 1
                                                    # GARL.iterGA = k ## iteration of iterGA is equal to current generation k, to persist results adequately
                                            
                                        ## PERSIST GENERATION RESULTS

                                        fromK = bestChromosome.generation.k
                                        fromCrossover = bestChromosome.fromCrossover

                                        pUX = cWeights[0]
                                        pOX = cWeights[1]
                                        pPMX = cWeights[2]
                                        pXX = cWeights[3]

                                        genResultsGA.append([mainTest, experiment, expParameter, experimentId, k, runPrint, currExperiment.bestResult, currExperiment.leadBest, currExperiment.toolBest, currExperiment.palletBest, duration, ctRunSim, runOffsprings, runImmigrants, runDuplicates, populationSize, elitismRate, tournamentRate, pUX, pOX, pPMX, pXX, cProb, mMethod, mProb, ctMaxMinutes, k, kMax, rlaAlpha, rlaGamma, rlaEpsilon, gPal, sPal])

                                        ## GET NEW POPULATION
                                        previousGeneration = currentGeneration
                                        currentGeneration = Generation(currExperiment)

                                        GaSelectMatingPool(currentGeneration, previousGeneration, currExperiment, elitismRate, tournamentRate, defTournamentSize, populationSize)
                                        ct = timeDouble.time()                        

                                    endRun = timeDouble.time()
                                    duration = (endRun - startRun) / 60     # in minutes

                                    if ct >= ctMax:
                                        termination = "ct" # time
                                    else:
                                        termination = 'k' # generations ('k') ran out


                                    fromK = bestChromosome.generation.k
                                    fromCrossover = bestChromosome.fromCrossover

                                    pUX = cWeights[0]
                                    pOX = cWeights[1]
                                    pPMX = cWeights[2]
                                    pXX = cWeights[3]
                                

                                    runResultsGA.append([mainTest, experiment, expParameter, experimentId, runPrint, currExperiment.bestResult, fromK, fromCrossover, currExperiment.leadBest, currExperiment.toolBest, currExperiment.palletBest, duration, ctRunSim, runOffsprings, runImmigrants, runDuplicates, populationSize, elitismRate, tournamentRate, pUX, pOX, pPMX, pXX, cProb, mMethod, mProb, ctMaxMinutes, k, kMax, termination, rlaAlpha, rlaGamma, rlaEpsilon, activateGARL, gPal, sPal])
                                    expResultsGA.append([mainTest, experiment, expParameter, experimentId, runPrint, currExperiment.bestResult, fromK, fromCrossover, currExperiment.leadBest, currExperiment.toolBest, currExperiment.palletBest, duration, ctRunSim, runOffsprings, runImmigrants, runDuplicates, populationSize, elitismRate, tournamentRate, pUX, pOX, pPMX, pXX, cProb, mMethod, mProb, ctMaxMinutes, k, kMax, termination, rlaAlpha, rlaGamma, rlaEpsilon, currExperiment.timesGARL, gPal, sPal])
                                    thrResultsGA.append([mainTest, experiment, expParameter, experimentId, runPrint, currExperiment.bestResult, fromK, fromCrossover, currExperiment.leadBest, currExperiment.toolBest, currExperiment.palletBest, duration, ctRunSim, runOffsprings, runImmigrants, runDuplicates, populationSize, elitismRate, tournamentRate, pUX, pOX, pPMX, pXX, cProb, mMethod, mProb, ctMaxMinutes, k, kMax, termination, gPal, sPal])

                                    print('-----------------------')
                                    print('Experiment {}, Run {} -- Finished. OBJECTIVE FUNCTION VALUE = {},    Lead {}, Tool {}, Pallet {}'.format(experimentId, runPrint, round(currExperiment.bestResult), round(currExperiment.leadBest), round(currExperiment.toolBest), round(currExperiment.palletBest)))
                                    print()

                                    if (rlaTuning) and (GARL.conversionReached):
                                        break

                                # dfSimResultsFinal = pd.DataFrame(simResultsGA, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'run', 'generation', 'chromosomeId', 'p1', 'p2', 'obj', 'leadCost', 'toolCost', 'palletCost', 'offspring', 'immigrants', 'duplicates', 'population size', 'elitism', 'tournament', 'cMethod', 'cProb', 'mMethod', 'mProb', 'k', 'ctSim', 'sequence', 'machine', 'pallet', 'invalidRun'])
                                # filenameDate = timeDouble.time()
                                # filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
                                # write = 'GA_' + mainTest + '_' + experiment + '_' + str(expParameter) + '_Exp_' + str(experimentId) + '_Sim_' + filenameDateAct + '.xlsx'
                                # with pd.ExcelWriter(write) as writer:
                                #     dfSimResultsFinal.to_excel(writer, sheet_name = 'Experiments', index = False)

                                dfGenResultsFinal = pd.DataFrame(genResultsGA, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'k', 'run', 'objBest', 'makespanCost', 'toolDiscardCost', 'toolHoldingCost', 'ctRun', 'ctSim', 'offspring', 'immigrants', 'duplicates', 'population size', 'elitism', 'tournament', 'pUX', 'pOX', 'pPMX', 'pXX', 'cProb', 'mMethod', 'mProb', 'ctMax', 'k', 'kbMax', 'alpha', 'gamma', 'epsilon', 'gPal', 'sPal'])
                                filenameDate = timeDouble.time()
                                filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
                                write = 'GA_' + mainTest + '_' + experiment + '_' + str(expParameter) + '_Exp_' + str(experimentId) + '_Gen_' + filenameDateAct + '.xlsx'
                                with pd.ExcelWriter(write) as writer:
                                    dfGenResultsFinal.to_excel(writer, sheet_name = 'Experiments', index = False)

                                dfRunResultsFinal = pd.DataFrame(runResultsGA, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'run', 'objBest', 'k', 'fromCross', 'makespanCost', 'toolDiscardCost', 'toolHoldingCost', 'ctRun', 'ctSim', 'offspring', 'immigrants', 'duplicates', 'population size', 'elitism', 'tournament', 'pUX', 'pOX', 'pPMX', 'pXX', 'cProb', 'mMethod', 'mProb', 'ctMax', 'k', 'kbMax', 'termination', 'alpha', 'gamma', 'epsilon', 'activateGARL', 'gPal', 'sPal'])
                                filenameDate = timeDouble.time()
                                filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
                                write = 'GA_' + mainTest + '_' + experiment + '_' + str(expParameter) + '_Exp_' + str(experimentId) + '_Run_' + filenameDateAct + '.xlsx'
                                with pd.ExcelWriter(write) as writer:
                                    dfRunResultsFinal.to_excel(writer, sheet_name = 'Experiments', index = False)

                                ### END OF GA Iteration

                                if rlaTuning:
                                    suffix = '{}{}{}{}{}{}{}'.format(kMax, populationSize, elitismRate, tournamentRate, rlaAlpha, rlaGamma, rlaEpsilon)
                                    GARL.exportResults(suffix)

                                if experimentId == stopExperiments:
                                    runExperiments = False

    suffix = '{}{}{}{}{}{}{}'.format(kMax, populationSize, elitismRate, tournamentRate, rlaAlpha, rlaGamma, rlaEpsilon)
    GARL.exportResults(suffix)

    dfExpResultsFinalGA = pd.DataFrame(expResultsGA, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'run', 'objBest', 'k', 'fromCross', 'makespanCost', 'toolDiscardCost', 'toolHoldingCost', 'ctRun', 'ctSim', 'offspring', 'immigrants', 'duplicates', 'population size', 'elitism', 'tournament', 'pUX', 'pOX', 'pPMX', 'pXX', 'cProb', 'mMethod', 'mProb', 'ctMax', 'k', 'kMax', 'termination', 'alpha', 'gamma', 'epsilon', 'GARL', 'gPal', 'sPal'])
    filenameDate = timeDouble.time()
    filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
    write = 'GA_' + mainTest + '_' + experiment + '_' + str(expParameter) + '_Exp_' + filenameDateAct + '.xlsx'
    with pd.ExcelWriter(write) as writer:
        dfExpResultsFinalGA.to_excel(writer, sheet_name = 'Results', index = False)

def PractitionersHeuristic(initialData, mainTest, experiment, expParameter, inputParametersPH, expParameters):

    experimentId = 1

    runResultsPH = []
    expResultsPH = []

    cncCapacity = inputParametersPH['cncCapacity']
    cncDepreciationCost = inputParametersPH['cncDepreciationCost']
    palletSetupCost = inputParametersPH['palletSetupCost']
    palletSetupTime = inputParametersPH['palletSetupTime']
    toolSwitchCost = inputParametersPH['toolSwitchCost']

    palletCapacity = inputParametersPH['palletCapacity']
    toolCapacity = inputParametersPH['toolCapacity']
    supervisedShift = inputParametersPH['supervisedShift']

    for run in range(runs):

        manager = multiprocessing.Manager()
        resultDatabase = manager.dict()

        ct = timeDouble.time()
        startRun = ct

        printRun = run + 1

        # print('start Run: {}'.format(run))

        runFrom = 'PH'

        # jobList = initialData[0].copy()
        # ncDatabase = initialData[1].copy()
        # xrefJobNc = initialData[4].copy()
        # toolStorageAct = initialData[6].copy()
        # jobFamily = initialData[7].copy()
        # xrefJobSuccession = initialData[8].copy()

        # ## FIRST:   Create the existing tool storage per machine
        
        # toolStorageAct = initialData[6]
        # toolStorageMachine = {}
        # for machineId in toolStorageAct.keys():
        #     toolStorageMachine[int(machineId)] = [x for x in toolStorageAct[machineId].keys()]
        
        # ## SECOND:  Set the total threshold per machine and per pallet

        # totalWorkload = 0
        # for job in jobList:
        #     totalWorkload += ncDatabase[xrefJobNc[job]]['cycle']

        # thresholdMachine = totalWorkload / cncCapacity
        # thresholdPallet = totalWorkload / palletCapacity

        # ## THIRD:   Allocate jobs to pallets based on:
        # #               1. pallet similarity of current job allocated to it

        # jobAllocation = {}
        # for job in jobList:
        #     jobAllocation[job] = {'p': None, 'm': None, 'seq': None}

        # palletAllocation = {}
        # for p in range(palletCapacity):
        #     palletAllocation[p] = {'jobs': [], 'workload': 0, 'pallets': [], 'randomSearch': True}   
        
        # palletOpenJobList = jobList.copy()
        # for _p in palletAllocation:
        #     while palletOpenJobList != []:
        #         allocateJobInstance = None
        #         if palletAllocation[_p]['randomSearch']:
        #             allocateJobCandidate = palletOpenJobList[0]
        #             allocateJobCandidateCycle = ncDatabase[xrefJobNc[allocateJobCandidate]]['cycle']
        #             ## if the randomly allocated job (and thus doesnt fit in the current pallets) increases the threshold higher than average ==> break, unless it is the final pallet
        #             if ((palletAllocation[_p]['workload'] + allocateJobCandidateCycle) > thresholdPallet) and (_p != len(palletAllocation)-1):
        #                 break
        #             ## if this is not the case allocate the job
        #             else:
        #                 allocateJobInstance = allocateJobCandidate
        #                 palletAllocation[_p]['randomSearch'] = False
        #         else:
        #             for allocateJobCandidate in palletOpenJobList:
        #                 allocateJobCandidatePallet = ncDatabase[xrefJobNc[allocateJobCandidate]]['pa']
        #                 if allocateJobCandidatePallet in palletAllocation[_p]['pallets']:
        #                     allocateJobInstance = allocateJobCandidate
        #                     break
        #         if allocateJobInstance == None:
        #             palletAllocation[_p]['randomSearch'] = True
        #         else:
        #             jobAllocation[allocateJobInstance]['p'] = _p
        #             palletAllocation[_p]['jobs'].append(allocateJobInstance)
        #             palletAllocation[_p]['workload'] += ncDatabase[xrefJobNc[allocateJobInstance]]['cycle']
        #             allocateJobPallet = ncDatabase[xrefJobNc[allocateJobInstance]]['pa']
        #             if allocateJobPallet not in palletAllocation[_p]['pallets']:
        #                 palletAllocation[_p]['pallets'].append(allocateJobPallet)
        #             palletOpenJobList.remove(allocateJobInstance)
        #         ## stopping criteria
        #         if (palletAllocation[_p]['workload'] > thresholdPallet) or (palletOpenJobList == []):
        #             break

        # ## to check the workload per pallet
        # # for _p in palletAllocation:
        # #     print('Pallet [{}]: {}\t{}'.format(_p, round(palletAllocation[_p]['workload']), round((palletAllocation[_p]['workload']-thresholdPallet))))
        # #     print('\tUnique Pallets: {}'.format(len(palletAllocation[_p]['pallets'])))

        # ## FOURTH:  Allocate jobs to machines based on tool similarities

        # machineAllocation = {}
        # for _m in range(cncCapacity):
        #     machineAllocation[_m] = {'jobs': [], 'workload': 0, 'toolset': [], 'randomSearch': True}

        # machineOpenJobList = jobList.copy()
        # jobFamilyMachine = jobFamily.copy()
        # for _m in machineAllocation:
        #     while machineOpenJobList != []:
        #         allocateJobInstance = None
        #         if machineAllocation[_m]['randomSearch']:
        #             allocateJobCandidate = machineOpenJobList[0]
        #             allocateJobCandidateCycle = ncDatabase[xrefJobNc[allocateJobCandidate]]['cycle']
        #             ## if the randomly allocated job (and thus doesnt fit in the current pallets) increases the threshold higher than average ==> break, unless it is the final pallet
        #             if ((machineAllocation[_m]['workload'] + allocateJobCandidateCycle) > thresholdMachine) and (_m != len(machineAllocation)-1):
        #                 break
        #             else:
        #                 allocateJobInstance = allocateJobCandidate
        #                 machineAllocation[_m]['randomSearch'] = False
        #         else:
        #             bestFit = toolCapacity + 1
        #             for allocateJobCandidate in machineOpenJobList:
        #                 allocateJobCandidateTools = ncDatabase[xrefJobNc[allocateJobCandidate]]['ta']
        #                 allocateJobCandidateUniqueTools = len(list(set(allocateJobCandidateTools) - set(machineAllocation[_m]['toolset'])))
        #                 if allocateJobCandidateUniqueTools < bestFit:
        #                     bestFit = allocateJobCandidateUniqueTools
        #                     allocateJobInstance = allocateJobCandidate
        #         if allocateJobInstance == None:
        #             machineAllocation[_m]['randomSearch'] = True
        #         else:
        #             allocateJobFamily = None
        #             for family in jobFamilyMachine:
        #                 if allocateJobInstance in jobFamilyMachine[family]:
        #                     allocateJobList = jobFamilyMachine[family]
        #                     allocateJobFamily = family
        #                     break
        #             jobFamilyMachine.pop(allocateJobFamily, None)
        #             for allocateJob in allocateJobList:
        #                 jobAllocation[allocateJob]['m'] = _m
        #                 machineAllocation[_m]['jobs'].append(allocateJob)
        #                 machineAllocation[_m]['workload'] += ncDatabase[xrefJobNc[allocateJob]]['cycle']
        #                 allocateJobTools = ncDatabase[xrefJobNc[allocateJob]]['ta']
        #                 allocateJobUniqueTools = list(set(allocateJobTools) - set(machineAllocation[_m]['toolset']))
        #                 machineAllocation[_m]['toolset'].extend(allocateJobUniqueTools)
        #                 machineOpenJobList.remove(allocateJob)
        #         ## stopping criteria
        #         if (machineAllocation[_m]['workload'] > thresholdMachine) or (machineOpenJobList == []):
        #             break

        # ## to check the workload per pallet
        # # for machine in machineAllocation:
        # #     print('Machine [{}]: {}\t{}'.format(machine, round(machineAllocation[machine]['workload']), round((machineAllocation[machine]['workload']-thresholdMachine))))

        # # for job in jobList:
        # #     print(jobAllocation[job])

        # ## FIFTH:   Sequence jobs based on least differences rule based on previous operation per machine, assign index

        # scheduleOpenJobList = jobList.copy()
        # sequenceVector = [-1 for job in jobList]
        # palletTypeTrack = {_p: None for _p in palletAllocation}
        # machineToolTrack = {_m: toolStorageMachine[_m] for _m in machineAllocation}
        # jobEligible = {_j: False for _j in jobList}
        # ## instantiate the eligibility claim
        # for _j in jobEligible:
        #     if _j[-2:] == 'S1':
        #         jobEligible[_j] = True
        # sequence = 0
        
        # while scheduleOpenJobList != []:
        #     scheduleJobInstance = None
        #     jobEligibleTrue = [job for job in jobEligible if jobEligible[job] if job in scheduleOpenJobList]
        #     palletFit = False
        #     toolFit = toolCapacity + 1
        #     for _m in machineAllocation:
        #         for _p in palletAllocation:
        #             for _j in jobEligibleTrue:
        #                 currentPalletType = palletTypeTrack[_p]
        #                 requiredPalletType = ncDatabase[xrefJobNc[_j]]['pa']
        #                 toolsRequired = ncDatabase[xrefJobNc[_j]]['ta']
        #                 toolsToBeLoaded = list(set(toolsRequired) - set(machineToolTrack[_m]))
        #                 amountOfToolsToBeLoaded = len(toolsToBeLoaded)
        #                 ## code if the required pallet is the same
        #                 if (currentPalletType == requiredPalletType):
        #                     if (amountOfToolsToBeLoaded < toolFit) or (palletFit == False):
        #                         scheduleJobInstance = _j
        #                         toolFit = amountOfToolsToBeLoaded
        #                     palletFit = True
        #                 ## code to check tool similarity IF there is no matching pallet found YET
        #                 elif palletFit == False:
        #                     if (amountOfToolsToBeLoaded < toolFit):
        #                         scheduleJobInstance = _j
        #                         toolFit = amountOfToolsToBeLoaded
        #     jobAllocation[scheduleJobInstance]['seq'] = sequence
        #     # jobIndexJobList = jobList.index(scheduleJobInstance)
        #     # sequenceVector[jobIndexJobList] = sequence
        #     scheduleOpenJobList.remove(scheduleJobInstance)
        #     newJobeligible = xrefJobSuccession[scheduleJobInstance]
        #     if newJobeligible != None:
        #         jobEligible[newJobeligible] = True
        #     sequence += 1
        
        # sequenceVector = [jobAllocation[_j]['seq'] for _j in jobList]
        # machineVector = [jobAllocation[_j]['m'] for _j in jobList]
        # palletVector = [jobAllocation[_j]['p'] for _j in jobList]

        sequenceVector, machineVector, palletVector = PhBuildSequences(initialData, inputParametersPH)

        geneRepresentation = GaSafeguard(jobList, xrefJobPrecedence, [sequenceVector, machineVector, palletVector])
        sequenceVector = geneRepresentation[0]
        machineVector = geneRepresentation[1]

        objectiveFunctionValue, makespanCost, toolSwitchCost, palletSetupCost, invalidRun = GaCalcFitness(initialData, 1, geneRepresentation, resultDatabase, inputParametersPH, runFrom)
        resultDatabase[1] = [objectiveFunctionValue, makespanCost, toolSwitchCost, palletSetupCost]

        endRun = timeDouble.time()
        duration = (endRun - startRun) / 60     # in minutes

        print('-----------------------')
        print('Experiment {}, Run {} -- Finished. OBJECTIVE FUNCTION VALUE = {}\t[Lead {} - Tool {} - Pallet {}]'.format(experimentId, run+1, round(objectiveFunctionValue), round(makespanCost), round(toolSwitchCost), round(palletSetupCost)))
        print()

        runResultsPH.append([mainTest, experiment, expParameter, 1, printRun, objectiveFunctionValue, makespanCost, toolSwitchCost, palletSetupCost, duration, gPal, sPal, sequenceVector, machineVector, palletVector])
        expResultsPH.append([mainTest, experiment, expParameter, 1, printRun, objectiveFunctionValue, makespanCost, toolSwitchCost, palletSetupCost, duration, gPal, sPal])
        thrResultsPH.append([mainTest, experiment, expParameter, 1, printRun, objectiveFunctionValue, makespanCost, toolSwitchCost, palletSetupCost, duration, gPal, sPal])

    dfsimResultsPH = pd.DataFrame(runResultsPH, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'run', 'objBest', 'makespanCost', 'toolSwitchCost', 'palletSetupCost', 'duration', 'gPal', 'sPal', 'seq', 'm', 'p'])
    filenameDate = timeDouble.time()
    filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
    write = 'PH_' + mainTest + '_' + experiment + '_' + str(expParameter) + '_Run_' + filenameDateAct + '.xlsx'
    with pd.ExcelWriter(write) as writer:
        dfsimResultsPH.to_excel(writer, sheet_name = 'Experiments', index = False)

    dfExpResultsPH = pd.DataFrame(expResultsPH, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'run', 'objBest', 'makespanCost', 'toolSwitchCost', 'palletSetupCost', 'duration', 'gPal', 'sPal'])
    filenameDate = timeDouble.time()
    filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
    write = 'PH_' + mainTest + '_' + experiment + '_' + str(expParameter) + '_Exp_' + filenameDateAct + '.xlsx'
    with pd.ExcelWriter(write) as writer:
        dfExpResultsPH.to_excel(writer, sheet_name = 'Experiments', index = False)

def MixedIntegerLinearProgram(initialData, mainTest, experiment, expParameter, inputParametersFix, expParameters):
    
    inputParameters = inputParametersFix.copy()
    objList, terminList, objAvg, objStd, termAvg, termStd = MilpCalcFitness(initialData, inputParameters, runs)

if __name__ == '__main__':

    thrResultsGA = []
    thrResultsPH = []
    expResultsMILP = []

    print('Let\'s process the following experiments: {}'.format(experimentsDict))

    gPal = gPalOrg
    sPal = sPalOrg
    workload = workloadOrg

    portfolioOrg, ncDatabaseOrg = GetProductData(workload)

    expParametersFix = {'Workload': workload, 'Tool': [0, 0], 'Pallet': [gPal, sPal]}

    for mainTest in experimentsDict:                                                ## e.g., BaseCase
        for experiment in experimentsDict[mainTest]:                                ## e.g., 'T'
            for expParameter in experimentsDict[mainTest][experiment]:

                portfolio = portfolioOrg.copy()
                ncDatabase = ncDatabaseOrg.copy()
                
                expParameter = round(expParameter, 2)

                expParameters = expParametersFix.copy()

                ## instantiate the basic parameters
                inputParameters = inputParametersFix.copy()

                if experiment == 'W':
                    workload = expParameter
                    print('Start workload increasing with workload {}'.format(workload))
                    portfolio, ncDatabase = GetProductData(workload)

                print('#############################################################')
                print('          Start experiment: {}: value: {}'.format(experiment, expParameter))
                print('#############################################################')

                jobList, jobFamily, xrefJobOperation, xrefJobPrecedence, xrefJobNc, xrefJobSuccession = GenerateJobs(portfolio, ncDatabase, workload)
                
                if (experiment == 'PH'):
                    expParameters['pallet'] = [int(gPalOrg * expParameter), int(sPalOrg * expParameter)]
                
                ncDatabase = GeneratePalletNc(jobList, ncDatabase, xrefJobNc, expParameters)

                if (experiment == 'TH') or (experiment == 'AM'):
                    portfolio, ncDatabase = ChangeNcDatabases(jobList, ncDatabase, portfolio, experiment, expParameter, expParameters)
                if experiment == 'S':
                    inputParameters['supervisedShift'] = expParameter

                toolStorageAct = getEmpiricalData()
                initialData = ClusterInitialData(jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, experiment, expParameter, toolStorageAct, jobFamily, xrefJobSuccession)

                # to make the simulation completely random / NOT THE INPUT PARAMETERS
                startSim = datetime.now()
                CreationData = "2023-12-01"
                buildSim = datetime.strptime(CreationData, "%Y-%m-%d")
                difference = (startSim.timestamp()-buildSim.timestamp())
                seedVal = round(difference, 0)
                random.seed(seedVal)

                if runPH:
                    PractitionersHeuristic(initialData, mainTest, experiment, expParameter, inputParameters, expParameters)

                if runGA:
                    GeneticAlgorithm(initialData, mainTest, experiment, expParameter, inputParameters, expParameters, rlaTuning, False)

                if runGARL:
                    GeneticAlgorithm(initialData, mainTest, experiment, expParameter, inputParameters, expParameters, rlaTuning, True)

                if runMILP:
                    MixedIntegerLinearProgram(initialData, mainTest, experiment, expParameter, inputParameters, expParameters)
        
        if runPH:
            dfThreadResultsPH = pd.DataFrame(thrResultsPH, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'run', 'objBest', 'makespanCost', 'toolSwitchCost', 'palletSetupCost', 'duration', 'gPal', 'sPal'])
            filenameDate = timeDouble.time()
            filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
            write = 'PH_' + mainTest + '_' + '_Thread' + filenameDateAct + '.xlsx'
            with pd.ExcelWriter(write) as writer:
                dfThreadResultsPH.to_excel(writer, sheet_name = 'Experiments', index = False)

        if runGA:
            dfThreadResultsFinalGA = pd.DataFrame(thrResultsGA, columns=['mainTest', 'experiment', 'parameter', 'experimentId', 'run', 'objBest', 'k', 'fromCross', 'leadBest', 'toolBest', 'palletBest', 'ctRun', 'ctSim', 'offspring', 'immigrants', 'duplicates', 'population size', 'elitism', 'tournament', 'pUX', 'pOX', 'pPMX', 'pXX', 'cProb', 'mMethod', 'mProb', 'ctMax', 'k', 'kMax', 'termination', 'gPal', 'sPal'])
            filenameDate = timeDouble.time()
            filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
            write = 'GA_' + mainTest + '_' + '_Thread' + filenameDateAct + '.xlsx'
            with pd.ExcelWriter(write) as writer:
                dfThreadResultsFinalGA.to_excel(writer, sheet_name = 'Results', index = False)

        if runMILP:
            print('hell yeah')

