import gurobipy as gp
from gurobipy import GRB, max_
import sys

import pandas as pd
from datetime import datetime, timedelta
import time
import json
import re
from statistics import mean, stdev
import RQ4_06_Functions, RQ4_05_DataInput
from RQ4_02_Model_MILP_Classes import TDM, ERP, JOB, TD, Shopfloor

ctMax = 3600 ## max computational time in seconds > 3600 = 1 hour

def MilpCalcFitness(initialData, inputParameters, runs):
    #initialData = [jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, actToolStorage, jobFamily, xrefJobSuccession]

    startModel = time.time()

    jobIdList = initialData[0]
    ncDatabase = initialData[1]
    xrefJobPrecedence = initialData[3]
    xrefJobNc = initialData[4]

    supervisedShift = inputParameters['supervisedShift']

    cncCapacity = inputParameters['cncCapacity']
    palletCapacity = inputParameters['palletCapacity']
    toolCapacity = inputParameters['toolCapacity']

    cncDepreciationCost = inputParameters['cncDepreciationCost']
    palletSetupTime = inputParameters['palletSetupTime']
    palletSetupCost = inputParameters['palletSetupCost']
    toolSwitchCost = inputParameters['toolSwitchCost']

    measuresRuns = {'objs': [], 'termins': []}

    horizon = 10000
    bestObjective = 999999999999

    for run in range(runs):
        
        shopfloor = Shopfloor(cncCapacity, palletCapacity, jobIdList, xrefJobNc, ncDatabase, xrefJobPrecedence, inputParameters)
        td = shopfloor.td
        erp = shopfloor.erp
        tdm = shopfloor.tdm
        jobs = erp.jobs


        ################################# Initialization ##############################
        # Create a new model
        model = gp.Model('MILP_IPMTCFC')

        # Minimization model
        model.modelSense = GRB.MINIMIZE
        # Disables output visualization
        model.setParam("OutputFlag", False) # set to true to prevent output
        # Save log of run to a file
        model.setParam("LogFile", "Logfile of test_24-11-2023")
        # Time limit for optimization
        model.setParam("TimeLimit", ctMax)
        # # Threads
        # model.setParam("Threads", 1)


        ############################# Create decision variables #######################

        ## job variables

        # activity times of job (i,j) in minutes  # jon = '+str(oper.ID))

        # loading start
        ls = {(job): model.addVar(lb=0, vtype=GRB.CONTINUOUS, name = 'ls: '+str(job.id))
            for job in jobs} #CONTINUOUS
        # loading end
        le = {(job): model.addVar(lb=0, vtype=GRB.CONTINUOUS, name = 'le: '+str(job.id))
            for job in jobs} #CONTINUOUS
        # mill start
        s = {(job): model.addVar(lb=0, vtype=GRB.CONTINUOUS, name = 's: '+str(job.id))
            for job in jobs} #CONTINUOUS
        # mill end
        e = {(job): model.addVar(lb=0, vtype=GRB.CONTINUOUS, name = 'e: '+str(job.id))
            for job in jobs}
        # unloading
        u = {(job): model.addVar(lb=0, vtype=GRB.CONTINUOUS, name = 'u: '+str(job.id))
            for job in jobs}
        
        # Module24 variables
        lsd =  {(job): model.addVar(vtype=GRB.INTEGER, name = 'lsd: '+str(job.id)) for job in jobs}             #CONTINUOUS
        lsm =  {(job): model.addVar(ub=24*60, vtype=GRB.INTEGER, name = 'lsm: '+str(job.id)) for job in jobs}   #CONTINUOUS
        led =  {(job): model.addVar(vtype=GRB.INTEGER, name = 'led: '+str(job.id)) for job in jobs}             #CONTINUOUS
        lem =  {(job): model.addVar(ub=24*60, vtype=GRB.INTEGER, name = 'lem: '+str(job.id)) for job in jobs}   #CONTINUOUS
        ud =  {(job): model.addVar(vtype=GRB.INTEGER, name = 'ud: '+str(job.id)) for job in jobs}               #CONTINUOUS
        um =  {(job): model.addVar(ub=24*60, vtype=GRB.INTEGER, name = 'um: '+str(job.id)) for job in jobs}     #CONTINUOUS
        tsd =  {(job): model.addVar(vtype=GRB.INTEGER, name = 'tsd: '+str(job.id)) for job in jobs}             #CONTINUOUS
        tsm =  {(job): model.addVar(ub=24*60, vtype=GRB.INTEGER, name = 'tsm: '+str(job.id)) for job in jobs}   #CONTINUOUS

        # Equal to 1 if job (j,k) is assigned to resource r, 0 otherwise
        alphaM = {(job,machine): model.addVar(vtype=GRB.BINARY, name = 'alphaM: m = '+str(machine)+', job = '+str(job.id))
            for job in jobs for machine in td.machines}
        alphaP = {(job,pallet): model.addVar(vtype=GRB.BINARY, name = 'alphaP: p = '+str(pallet)+', job = '+str(job.id))
            for job in jobs for pallet in tdm.pallets}

        # Variable is 1, if operation (i,j) is immediately succeeded by operation (i',j') on machine (m)
        betaM = {(job1,job2,machine): model.addVar(vtype=GRB.BINARY, name = 'betaM: m = '+str(machine)+', job 1 = '+str(job1.id)+' -> job 2 = '+str(job2.id))
            for job1 in jobs for job2 in jobs if (job1 != job2) for machine in td.machines} #
        betaP = {(job1,job2,pallet): model.addVar(vtype=GRB.BINARY, name = 'betaP: p = '+str(pallet)+', job 1 = '+str(job1.id)+' -> job 2 = '+str(job2.id))
            for job1 in jobs for job2 in jobs if (job1 != job2) for pallet in tdm.pallets} #

        ## tool variables

        # Equal to 1 if tool t is present at the start of job (i,j), 0 otherwise
        x = {(job,tnumber): model.addVar(vtype=GRB.BINARY, name = 'x: job = ' + str(job.id) + ', t = '+str(tnumber))
            for job in jobs for tnumber in tdm.tools}

        # Equal to 1 if tool t is inserted at the start of job (i,j), 0 otherwise
        y = {(job,tnumber): model.addVar(vtype=GRB.BINARY, name = 'y: job = ' + str(job.id) + ', t = '+str(tnumber))
            for job in jobs for tnumber in tdm.tools}
        
        # Equal to 1 if pallet p is reconfigured between job (i,j) and job (i',j'), 0 otherwise
        z = {(job1,job2,pallet): model.addVar(vtype=GRB.BINARY, name = 'z: p = '+str(pallet)+', job 1 = '+str(job1.id)+' -> job 2 = '+str(job2.id))
            for job1 in jobs for job2 in jobs if job1 != job2 for pallet in tdm.pallets}
        
        ### part of objective function
        cmax = model.addVar(vtype=GRB.CONTINUOUS, name = 'cmax: ')
        model.addConstr(cmax == max_(u[job] for job in jobs))

        ############################# Create objective function #######################

        # calculate end time of the total makespan
        
        obj_leadtime = cncDepreciationCost * cncCapacity * (cmax / 60)
        obj_toolSwitch = toolSwitchCost * gp.quicksum(y[job,tnumber] for job in jobs for tnumber in tdm.tools)
        obj_palletSetup = palletSetupCost * gp.quicksum(z[job1,job2,pallet] for job1 in jobs for job2 in jobs if job1 != job2 for pallet in tdm.pallets)
        model.setObjective(obj_leadtime + obj_toolSwitch + obj_palletSetup)

        ################# Constraints (numbered according to paper) ###################

        constrDict = {'c7': [], 'c8': [], 'c10a': [], 'c10b': [], 'c10c': [], 'c12': []}

        # Constraint (2): jobs can only be succeeded by 1 job
        for job1 in jobs:  
            model.addConstr(gp.quicksum(betaM[job1,job2,machine] for job2 in jobs if (job2 != job1) for machine in td.machines) <= 1, "c2a") 
            model.addConstr(gp.quicksum(betaP[job1,job2,pallet] for job2 in jobs if (job2!= job1) for pallet in tdm.pallets) <= 1, "c2b") 

        # Constraint (4): jobs can only be preceded by 1 job
        for job2 in jobs:      
            model.addConstr(gp.quicksum(betaM[job1,job2,machine] for job1 in jobs if (job1 != job2) for machine in td.machines) <= 1, "c3a")   
            model.addConstr(gp.quicksum(betaP[job1,job2,pallet] for job1 in jobs if (job1 != job2) for pallet in tdm.pallets) <= 1, "c3b")

        # Constraint (4): jobs are allocated to 1 machine
        for job in jobs:            
            model.addConstr(gp.quicksum(alphaM[job,machine] for machine in td.machines) == 1, "c4a")         
            model.addConstr(gp.quicksum(alphaP[job,pallet] for pallet in tdm.pallets) == 1, "c4b")

        # Constraint (5): two successive jobs must be allocated to the same resource
        for job1 in jobs:  
            for job2 in jobs:  
                if (job1 != job2):
                    for machine in td.machines:
                        model.addConstr(2 * betaM[job1,job2,machine] <= alphaM[job1,machine] + alphaM[job2,machine], "c5a")
                    for pallet in tdm.pallets:
                        model.addConstr(2 * betaP[job1,job2,pallet] <= alphaP[job1,pallet] + alphaP[job2,pallet], "c5b")

        # Constraint (6): all successive jobs must be allocated on the same resource
        for machine in td.machines:
            model.addConstr((gp.quicksum(betaM[job1,job2,machine] for job1 in jobs for job2 in jobs if (job1 != job2)) + 1) >= gp.quicksum(alphaM[job1,machine] for job1 in jobs), "c6a")
        for pallet in tdm.pallets:
            model.addConstr((gp.quicksum(betaP[job1,job2,pallet] for job1 in jobs for job2 in jobs if (job1 != job2)) + 1) >= gp.quicksum(alphaP[job1,pallet] for job1 in jobs), "c6b")

        # Constraint (7): starting time of milling next job on the same machine is constraint by ending time of previous job
        for job1 in jobs:
            for job2 in jobs:
                if job1 != job2:
                    for machine in td.machines:
                        addCons = model.addConstr(s[job2] + (horizon * (1 - betaM[job1,job2,machine])) >= e[job1], "c7")
                        consName = str(job1.id) + ' - ' + str(job2.id) + ' | ' + str(machine)
                        constrDict['c7'].append((consName, addCons))

        # Constraint (8): ending time of milling job 1 is constrained by its own starting time and processing time
        for job in jobs:     
            addCons = model.addConstr(e[job] == s[job] + job.cycle, "c8")
            consName = str(job.id)
            constrDict['c8'].append((consName, addCons))

        # Constraint (9): start time of loading job is constrained by unloading time of preceding job
        for job1 in jobs:  
            for job2 in jobs:
                if job1 != job2:  
                    precedingOperation = job2.precedingOperation
                    if (precedingOperation != None) and (precedingOperation == job1.id):
                        model.addConstr(u[job1] <= ls[job2], "c9")
        
        # Constraint (10): times per activity should be in chronological order; loading, start milling, end milling, unloading
        for job in jobs:      
            addCons = model.addConstr(u[job] >= e[job], "c10a")
            consName = str(job.id)
            constrDict['c10a'].append((consName, addCons))
            addCons = model.addConstr(e[job] >= s[job], "c10b")
            consName = str(job.id)
            constrDict['c10b'].append((consName, addCons))
            addCons = model.addConstr(s[job] >= le[job], "c10c")
            consName = str(job.id)
            constrDict['c10c'].append((consName, addCons))

        # Constraint (11): loading of job should be greater or equal than unloading of previous job on that pallet
        for job1 in jobs:
            for job2 in jobs:
                if job1 != job2:
                    for pallet in tdm.pallets:
                        model.addConstr(ls[job1] + (horizon * ( 1 - betaP[job2,job1,pallet])) >= u[job2], "c11")    

        # Constraint (12): pallet reconfiguration is required for job when preceding job has different pallet
        for job1 in jobs:   
            for job2 in jobs:
                if job1 != job2:   
                    for pallet in tdm.pallets:
                        addCons = model.addConstr(z[job1,job2,pallet] + shopfloor.reconfigureMatrix[job1,job2] >= betaP[job1,job2,pallet], "c12")
                        consName = str(job1.id) + ' - ' + str(job2.id) + ' - ' + str(pallet)
                        constrDict['c12'].append((consName, addCons))

        # Constraint (13): loading end of job is constrained by load start and reconfigure delay
        for job2 in jobs:   
            model.addConstr(le[job2] == ls[job2] + (palletSetupTime * gp.quicksum(z[job1,job2,pallet] for job1 in jobs if job1 != job2 for pallet in tdm.pallets)), "c13")

        # Constraint (14): all tools should fit within the tool storage capacity
        for job in jobs:
            model.addConstr(gp.quicksum(x[job,tnumber] for tnumber in tdm.tools) <= toolCapacity, "c14")

        # Constraint (15): tool switch occurs when tool is not present in preceding job on that machine
        for job1 in jobs:   
            for job2 in jobs:  
                if (job1 != job2):
                    for machine in td.machines:
                        for tnumber in tdm.tools: 
                            model.addConstr(betaM[job1,job2,machine] + x[job2,tnumber] - x[job1,tnumber] <= y[job2,tnumber] + 1, "c15")

        # Constraint (16): all tools required for job must be present in machine
        for job in jobs:   
            for tnumber in job.ta:
                model.addConstr(x[job,tnumber] == 1, "c16")

        tU = 60 * (24 - supervisedShift)
        totalDay = 60 * 24

        # Constraint (17): tool switches can only occur during supervised shifts
        for job in jobs:   
            for tnumber in tdm.tools:
                model.addConstr(y[job,tnumber] <= 2 - (tsm[job] / (totalDay - tU)), "c17")

        # Constraint (18): pallet reconfigurations can only occur during supervised shifts
        for job in jobs:   
            model.addConstr(lsm[job] <= (totalDay - tU), "c18a")
            model.addConstr(lem[job] <= (totalDay - tU), "c18b")
            model.addConstr(um[job] <= (totalDay - tU), "c18c")

        # # Constraint (19): symmetry-breaking constraint
        for machine in range(1,cncCapacity):
            model.addConstr(gp.quicksum(alphaM[job,machine-1] for job in jobs) >= gp.quicksum(alphaM[job,machine] for job in jobs), "c19a")
        for pallet in range(1,palletCapacity):
            model.addConstr(gp.quicksum(alphaP[job,pallet-1] for job in jobs) >= gp.quicksum(alphaP[job,pallet] for job in jobs), "c19b")

        # # Constraint (20): Calculate module24 ==> NOT IN PAPER
        for job in jobs:   
            model.addConstr(ls[job] == (totalDay * lsd[job]) + lsm[job], 'c20a')
            model.addConstr(le[job] == (totalDay * led[job]) + lem[job], 'c20b')
            model.addConstr(s[job] == (totalDay * tsd[job]) + tsm[job], 'c20c')
            model.addConstr(u[job] == (totalDay * ud[job]) + um[job], 'c20d')
    
        presolved = model.presolve()
        print('Constraints added to model')
        print()
        presolved.printStats()

        model.write('mymodel.lp')
        # # Optimize model ##############################################################
        model.update()
        model.optimize()


        # Reporting results ###########################################################
        status = model.status

        # Objective value    
        if status == GRB.OPTIMAL:
            print('Optimal objective: {}'.format(model.objVal))
            measuresRuns['objs'].append(model.objVal)
            measuresRuns['termins'].append(model.Runtime)
            measuresRuns['jobs'].append(len(jobs))
            measuresRuns['m'].append(len(td.machines))
            measuresRuns['p'].append(len(tdm.pallets))
            measuresRuns['t'].append(len(tdm.tools))
            measuresRuns['T'].append(toolCapacity)
        elif status == GRB.INF_OR_UNBD:
            print('Model is infeasible or unbounded')
        elif status == GRB.INFEASIBLE:
            print('Model is infeasible')
        elif status == GRB.UNBOUNDED:
            print('Model is unbounded')
        elif status == GRB.Status.TIME_LIMIT:
            measuresRuns['objs'].append(model.objVal)
            measuresRuns['termins'].append(model.Runtime)
            measuresRuns['jobs'].append(len(jobs))
            measuresRuns['m'].append(len(td.machines))
            measuresRuns['p'].append(len(tdm.pallets))
            measuresRuns['t'].append(len(tdm.tools))
            measuresRuns['T'].append(toolCapacity)
            print('The model reaches time limit of '.format(str(ctMax)))
        else:
            print('Optimization ended with status {}'.format(status))
            
        try:    
            variables = {'Variable name' : [], 'Value' : []}
            lsVar = {'Variable name' : [], 'Value' : []} 
            leVar = {'Variable name' : [], 'Value' : []}
            sVar = {'Variable name' : [], 'Value' : []}
            eVar = {'Variable name' : [], 'Value' : []}
            uVar = {'Variable name' : [], 'Value' : []}
            alphaMVar = {'Variable name' : [], 'Value' : []}
            alphaPVar = {'Variable name' : [], 'Value' : []}
            betaMVar = {'Variable name' : [], 'Value' : []}
            betaPVar = {'Variable name' : [], 'Value' : []}
            xVar = {'Variable name' : [], 'Value' : []}
            yVar = {'Variable name' : [], 'Value' : []}
            zVar = {'Variable name' : [], 'Value' : []}
            schedules = {'jobId' : [], 'ls' : [], 'le' : [], 's' : [], 'e' : [], 'u' : [], 'p': [], 'pa': [], 'm' : [], 'cycle': []}
            
            for var in model.getVars():
                countAdd = 0          
                print('Check variable: {}'.format(var))
                variables['Variable name'].append(var.varName)
                variables['Value'].append(var.x)
                persistVar = round(var.x)
                if var.varName[:3] == 'ls:':
                    lsVar['Variable name'].append(var.varName)
                    lsVar['Value'].append(var.x)
                    jobId = var.varName[4:] 
                    jobObj = [job for job in jobs if job.id == jobId][0]
                    schedules['jobId'].append(jobId)
                    schedules['ls'].append(var.x)
                    schedules['cycle'].append([job for job in jobs if job.id == jobId][0].cycle)
                    schedules['pa'].append(jobObj.pa)
                    countAdd += 1
                if var.varName[:3] == 'le:':
                    leVar['Variable name'].append(var.varName)
                    leVar['Value'].append(var.x)
                    schedules['le'].append(var.x)
                    countAdd += 1
                if var.varName[:2] == 's:':
                    sVar['Variable name'].append(var.varName)
                    sVar['Value'].append(var.x)
                    schedules['s'].append(var.x)
                    countAdd += 1
                if var.varName[:2] == 'e:':
                    eVar['Variable name'].append(var.varName)
                    eVar['Value'].append(var.x)
                    schedules['e'].append(var.x)
                    countAdd += 1
                if var.varName[:2] == 'u:':
                    uVar['Variable name'].append(var.varName)
                    uVar['Value'].append(var.x)
                    schedules['u'].append(var.x)
                    countAdd += 1
                if (var.varName[:6] == 'alphaM') and (round(var.x) != 0):
                    alphaMVar['Variable name'].append(var.varName)
                    alphaMVar['Value'].append(persistVar)
                    if persistVar == 1:
                        numbers = re.findall('\d+', var.varName)  # finds all the numbers in the string
                        result = list(map(int, numbers))
                        for machineInt in result:
                            schedules['m'].append(machineInt)
                            break 
                    countAdd += 1
                if (var.varName[:6] == 'alphaP') and (round(var.x) != 0):
                    alphaPVar['Variable name'].append(var.varName)
                    alphaPVar['Value'].append(persistVar)
                    if persistVar == 1:
                        numbers = re.findall('\d+', var.varName)  # finds all the numbers in the string
                        result = list(map(int, numbers))
                        for palletInt in result:
                            schedules['p'].append(palletInt)
                            break 
                    countAdd += 1
                if (var.varName[:5] == 'betaM') and (round(var.x) != 0):
                    betaMVar['Variable name'].append(var.varName)
                    betaMVar['Value'].append(persistVar)
                    countAdd += 1
                if (var.varName[:5] == 'betaP') and (round(var.x) != 0):
                    betaPVar['Variable name'].append(var.varName)
                    betaPVar['Value'].append(persistVar)
                    countAdd += 1
                if (var.varName[0] == 'x') and (round(var.x) != 0):
                    xVar['Variable name'].append(var.varName)
                    xVar['Value'].append(persistVar)
                    countAdd += 1
                if (var.varName[0] == 'y') and (round(var.x) != 0):
                    yVar['Variable name'].append(var.varName)
                    yVar['Value'].append(persistVar)
                    countAdd += 1
                if (var.varName[0] == 'z') and (round(var.x) != 0):
                    zVar['Variable name'].append(var.varName)
                    zVar['Value'].append(persistVar) 
                    countAdd += 1   
                # print('Added {} variables'.format(countAdd))
                if countAdd > 1:
                    raise('cannot happen')

            toolSchedule = {'jobId': [], 's': [], 'e': [], 'm': [], 't': [], 'x': [], 'y': []}
            toolSwitches = 0
            for jobIdIndex in range(len(schedules['jobId'])):
                jobId = schedules['jobId'][jobIdIndex]
                startTime = schedules['s'][jobIdIndex]
                endTime = schedules['e'][jobIdIndex]
                machine = schedules['m'][jobIdIndex]
                for toolMillKey in x.keys():
                    if (toolMillKey[0].id == jobId) and (x[toolMillKey].x == 1):
                        tool = toolMillKey[1]
                        for toolSwitchKey in y.keys():
                            if (toolSwitchKey[0].id == jobId) and (toolSwitchKey[1] == tool):
                                toolVal = int(round(y[toolSwitchKey].x))
                                toolSchedule['jobId'].append(jobId)
                                toolSchedule['s'].append(startTime)
                                toolSchedule['e'].append(endTime)
                                toolSchedule['m'].append(machine)
                                toolSchedule['t'].append(tool)
                                toolSchedule['x'].append(1)
                                toolSchedule['y'].append(toolVal)
                                toolSwitches += toolVal

            print('[LP2] Tool switch times: ' + str(toolSwitches))
            palletReconfigurations = []
            for pallet in range(palletCapacity):
                palletReconfigurations.append([])
            for jobIdIndex in range(len(schedules['jobId'])):
                jobId = schedules['jobId'][jobIdIndex]
                for palletReconfigVarIndex in range(len(zVar['Variable name'])):
                    palletReoncfigVarName = zVar['Variable name'][palletReconfigVarIndex]
                    if jobId in palletReoncfigVarName:
                        if zVar['Value'][palletReconfigVarIndex] == 1:
                            pallet = schedules['p'][jobIdIndex]
                            print('p = ' + str(pallet))
                            palletReconfigurations[pallet].append(schedules['ls'][jobIdIndex])
                            break
            print('[LP2] Pallet reconfigurations: ' + str(palletReconfigurations))
            print('[LP2] The total number of jobs is: ' + str(len(jobs)))
            print('[LP2] The total number of unique tools is: ' + str(len(tdm.tools)))
            print('[LP2] The total set of unique tools is: ' + str(tdm.tools))
            print()
            
            variablesDf = pd.DataFrame.from_dict(variables)
            lsDf = pd.DataFrame.from_dict(lsVar)
            leDf = pd.DataFrame.from_dict(leVar)
            sDf = pd.DataFrame.from_dict(sVar)
            eDf = pd.DataFrame.from_dict(eVar)
            uDf = pd.DataFrame.from_dict(uVar)
            alphaMDf = pd.DataFrame.from_dict(alphaMVar)
            alphaPDf = pd.DataFrame.from_dict(alphaPVar)
            betaMDf = pd.DataFrame.from_dict(betaMVar)
            betaPDf = pd.DataFrame.from_dict(betaPVar)
            xDf = pd.DataFrame.from_dict(xVar)
            yDf = pd.DataFrame.from_dict(yVar)
            zDf = pd.DataFrame.from_dict(zVar)

            if e != {}:
                eMax = max([var.x for var in [v for k, v in e.items()]])
                print('Total processing time of operations = ' + str(round(eMax,2)) + ' minutes')   
                
            alphaMSum = 0    
            for alphaMachine in alphaMDf['Value']:
                if alphaMachine == 1:
                    alphaMSum += 1
                else:
                    print('ERROR BETA IS ZERO')
            print('Machine allocations values are positive count = ' + str(alphaMSum))
            betaMSum = 0
            for sequenceIndex in betaMVar['Value']:
                if sequenceIndex == 1:
                    betaMSum += 1
                else:
                    print('ERROR MACHINE SEQUENCE IS ZERO')
            print('Machine sequence count is positive = ' + str(betaMSum))
            
            alphaPSum = 0    
            for alphaPallet in alphaPDf['Value']:
                if alphaPallet == 1:
                    alphaPSum += 1
                else:
                    print('ERROR BETA PALLET IS ZERO')
            print('Pallet allocations values are positive count = ' + str(alphaPSum))
            betaPSum = 0
            for sequenceIndex in betaPVar['Value']:
                if sequenceIndex == 1:
                    betaPSum += 1
                else:
                    print('ERROR PALLET SEQUENCE IS ZERO')
            print('Pallet sequence count is positive = ' + str(betaPSum))

            toolPresentMachines = []
            for machine in range(cncCapacity):
                toolPresentMachines.append([])
                for jobIndex in range(len(jobs)):
                    toolPresentMachines[machine].append(0)
                    for toolPresentVar in xVar['Variable name']:               
                        if (('x: ' + str(jobs[jobIndex].id)) in toolPresentVar):
                            toolPresentMachines[machine][jobIndex] += 1
            
            print('Tools present count: ' + str(sum(list(sum(toolPresentMachines[machine]) for machine in range(cncCapacity)))))
            print('Tools per job count:')
            for machine in range(cncCapacity):
                print('m_' + str(machine) + ' = ' + str(toolPresentMachines[machine]))
            
            toolSwitchesCount = 0    
            for toolSwitchIndex in range(len(yVar['Variable name'])):
                if yVar['Value'][toolSwitchIndex] == 1:
                    toolSwitchesCount += 1
            print('Tool switches count: ' + str(toolSwitchesCount))

            palletConfigCount = 0    
            for palletConfigIndex in range(len(zVar['Variable name'])):
                if zVar['Value'][palletConfigIndex] == 1:
                    palletConfigCount += 1
            print('Pallet reconfiguration count: ' + str(palletConfigCount))
            
                
            if status == GRB.OPTIMAL:
                print('Optimal objective: %g' % model.objVal)
            print()
            print('Best objective = € ' + str(round(model.objVal,2)))
            print('Leadtime Cost  = € ' + str(cncDepreciationCost * cncCapacity) + ' * ' +  str(max([var.x for var in [v for k, v in u.items()]])) + ' > hourly rate * makespan')
            print('Tooling Cost   = € ' + str(toolSwitchCost) + ' * ' + str(toolSwitches) + ' >  switch cost * tool switches)')
            print(' Check 1: amount tool switches = ' + str(len([ts for ts in yVar['Value'] if ts == 1])))
            print(' Check 2: amount tool switches = ' + str(len([y[job, tnumber] for job in jobs for tnumber in tdm.tools if round(y[job, tnumber].x) == 1])))
            print('Pallet Cost    = € ' + str(palletSetupCost) + ' * ' + str(palletConfigCount) + ' ( = reconfiguration cost * pallet reconfigurations)')
            print(' Check 1: amount pallet reconfigurations = ' + str(len([pr for pr in zVar['Value'] if pr == 1])))
            print(' Check 2: amount pallet reconfigurations = ' + str(len([z[job1,job2,pallet] for job1 in jobs for job2 in jobs if job1 != job2 for pallet in tdm.pallets if round(z[job1,job2,pallet].x) == 1])))
            print()
            
            print('Model runtime = ' + str(round(model.Runtime,2)) + ' seconds')
            print('Real runtime  = ' + str(time.time() - startModel))


            if round(model.objVal,2) > bestObjective:
                bestObjective = round(model.objVal,2)
            
            ########################## Create schedule of figures #########################
                #Conversion of output data to appropriate input data for timeline (Gantt chart)
                # print('Final schedule: {}'.format(schedules))

                for i in schedules:
                    # print(i)
                    # print(len(schedules[i]))
                    print('[{}]: {}'.format(i, schedules[i]))

                # for constrType in constrDict.keys():
                #     for constrTuple in constrDict[constrType]:
                #         constrName = constrTuple[0]
                #         constr = constrTuple[1]
                #         LHS = model.getRow(constr).getValue()
                        # print('[{}] {}: LHS [{}] {} RHS [{}]'.format(constrType, constrName, LHS, constr.Sense, constr.RHS))
                
                schedulesDf = pd.DataFrame(schedules)
                toolScheduleDf = pd.DataFrame(toolSchedule)
                palletReconfigurationsDf = pd.DataFrame(palletReconfigurations)
                statisticsDf = pd.DataFrame([model.objVal])
                # with pd.ExcelWriter('Flexible_S_Test_' + str(demand_data_file[10:13]) + ' o_max=' + str(oper_max) +'.xlsx') as writer: 
                with pd.ExcelWriter('RQ4_02_MILP_Validate.xlsx') as writer: 
                    schedulesDf = schedulesDf.sort_values(['m', 's'], ascending=[True, True])
                    schedulesDf.to_excel(writer, sheet_name='Machine Schedule', index = False, columns=['jobId', 's', 'e', 'm', 'cycle'])
                    schedulesDf = schedulesDf.sort_values(['p', 'ls'], ascending=[True, True])
                    schedulesDf.to_excel(writer, sheet_name='Pallet schedule', index = False, columns=['jobId', 'ls', 'le', 'u', 'p', 'pa'])
                    schedulesDf = schedulesDf.sort_values(['jobId'], ascending=[True])
                    schedulesDf.to_excel(writer, sheet_name='Job schedule', index = False, columns=['jobId', 'ls', 'le', 'u', 'p', 's', 'e'])
                    toolScheduleDf = toolScheduleDf.sort_values(['m', 's'], ascending=[True, True])
                    toolScheduleDf.to_excel(writer, sheet_name='Tool schedule', index = False)
                    palletReconfigurationsDf.to_excel(writer, sheet_name='Pal. reconf.', index = False)
                    statisticsDf.to_excel(writer, sheet_name='Statistics', index = False)
                    variablesDf.to_excel(writer, sheet_name = 'Variables', index = False)
                    lsDf.to_excel(writer, sheet_name = 'ls', index = False)
                    leDf.to_excel(writer, sheet_name = 'le', index = False)
                    sDf.to_excel(writer, sheet_name = 's', index = False)
                    eDf.to_excel(writer, sheet_name = 'e', index = False)
                    uDf.to_excel(writer, sheet_name = 'u', index = False)
                    alphaMDf.to_excel(writer, sheet_name = 'aM', index = False)
                    alphaPDf.to_excel(writer, sheet_name = 'aP', index = False)
                    betaMDf.to_excel(writer, sheet_name = 'bM', index = False)
                    betaPDf.to_excel(writer, sheet_name = 'bP', index = False)
                    xDf.to_excel(writer, sheet_name = 'x', index = False)
                    yDf.to_excel(writer, sheet_name = 'y', index = False)
                    zDf.to_excel(writer, sheet_name = 'z', index = False)

                # print(schedulesDf) 
                # print() 

                schedulesGantt = schedules.copy()
                for i in range(len(schedulesGantt['ls'])):

                    schedulesGantt['ls'][i] = datetime(2021, 1, 1, 0, 0) + timedelta(minutes = int(schedulesGantt['ls'][i]))
                    schedulesGantt['le'][i] = datetime(2021, 1, 1, 0, 0) + timedelta(minutes = int(schedulesGantt['le'][i]))
                    schedulesGantt['s'][i] = datetime(2021, 1, 1, 0, 0) + timedelta(minutes = int(schedulesGantt['s'][i]))
                    schedulesGantt['e'][i] = datetime(2021, 1, 1, 0, 0) + timedelta(minutes = int(schedulesGantt['e'][i]))
                    schedulesGantt['u'][i] = datetime(2021, 1, 1, 0, 0) + timedelta(minutes = int(schedulesGantt['u'][i]))

                # schedulesGanttDf = pd.DataFrame(schedulesGantt)  
                # print(schedulesGanttDf)    
                # print()
            
        # Error handling ##############################################################
        except gp.GurobiError as e:
            print('Error code ' + str(e.errno) + ': ' + str(e))

        except AttributeError:
            print('Encountered an attribute error')
        
    objAvg = round(mean(measuresRuns['objs'], 2))
    objStd = round(stdev(measuresRuns['objs'], 2))
    termAvg = round(mean(measuresRuns['termins'], 2))
    termStd = round(mean(measuresRuns['termins'], 2))

    measuresRunDf = pd.DataFrame(measuresRuns)

    dateAct = time.time()
    dateSave = time.strftime('%Y%m%d%H%M', time.localtime(dateAct))

    filename = 'Run_MILP_' + str(dateSave) +'.xlsx'
    
    with pd.ExcelWriter(filename) as writer: 
        measuresRunDf.to_excel(writer, sheet_name='Measures', index = False)

    return measuresRuns['objs'], measuresRuns['termins'], objAvg, objStd, termAvg, termStd        

if __name__ == '__main__':

    statisticsExp = {'objMean': [], 'objStD': [], 'terminMean': [], 'terminStD': []}
    measuresExp = {'obj': [], 'term': []}

    checkSimModel = True
    runs = 1

    supervisedShift = 18

    cncCapacity = 2
    toolCapacity = 3
    palletMachine = 1.5
    palletCapacity = int(round(cncCapacity * palletMachine, 0))

    simDays = 5
    workload = (60 * 24 * simDays * cncCapacity)
    operMax = 10
    toolMax = 3

    cncDepreciationCost = 30
    toolSwitchCost = 1
    palletSetupCost = 50 * 4
    palletSetupTime = 60 * 4
    inputParameters = {'cncCapacity': cncCapacity, 'cncDepreciationCost': cncDepreciationCost, 'palletSetupTime': palletSetupTime, 'palletSetupCost': palletSetupCost, 'toolSwitchCost': toolSwitchCost, 'toolCapacity': toolCapacity, 'palletCapacity': palletCapacity, 'supervisedShift': supervisedShift, 'operMax': operMax, 'toolMax': toolMax}

    portfolio, ncDatabase = RQ4_05_DataInput.GetProductData()
    toolStorageAct = RQ4_05_DataInput.getEmpiricalData()

    jobList, xrefJobOperation, xrefJobPrecedence, xrefJobNc = RQ4_05_DataInput.GenerateJobs(portfolio, ncDatabase)
    initialData = RQ4_05_DataInput.ClusterInitialData(jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, 'B', 1, toolStorageAct)

    objList, terminList, objAvg, objStd, termAvg, termStd = MilpCalcFitness(initialData, inputParameters, runs)

    measuresExp['obj'].append(objList)
    measuresExp['term'].append(terminList)

    statisticsExp['objMean'].append(objAvg)
    statisticsExp['objStD'].append(objStd)
    statisticsExp['terminMean'].append(termAvg)
    statisticsExp['terminStD'].append(termStd)

    statisticsExpDf = pd.DataFrame(statisticsExp)
    measuresExpDf = pd.DataFrame(measuresExp)

    dateAct = time.time()
    dateSave = time.strftime('%Y%m%d%H%M', time.localtime(dateAct))

    filename = 'Exp_MILP_' + str(dateSave) +'.xlsx'
    
    with pd.ExcelWriter(filename) as writer: 
        statisticsExpDf.to_excel(writer, sheet_name='Statistics', index = False)
        measuresExpDf.to_excel(writer, sheet_name='Measures', index = False)
        # input_df_df.to_excel(writer, sheet_name='input', index = False)

    # print('')
    # print('Finished with objective function {}'.format(sumValue))