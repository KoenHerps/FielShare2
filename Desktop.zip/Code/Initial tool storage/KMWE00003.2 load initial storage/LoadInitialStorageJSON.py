from random import random
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import csv
import json

testval = random()
print(testval)

sheets = 5

machines = ['1733', '2107', '10052']

toolStorageMax = 80

combinedFiles = {}

follow = 0
for m in range(len(machines)):
    for sheet in range(sheets):
        follow += 1
        print('read: {}'.format(follow))
        sheetname = 'Sheet' + str(sheet+1)
        machine = machines[m]
        filename = machine + '-' + sheetname
        writefile = pd.read_excel(r'' + machine + '.xlsx', engine='openpyxl', sheet_name=sheetname)
        if m not in combinedFiles.keys():
            combinedFiles[m] = {}
        combinedFiles[m][filename] = writefile

initialStorage = {}
for m in combinedFiles.keys():
    if m not in initialStorage.keys():
        initialStorage[m] = {}
    count = {}
    for dataEntry in combinedFiles[m].values():
        activeTools = dataEntry['Name'].values
        for tool in activeTools:
            if tool not in count.keys():
                count[tool] = 1
            else:
                count[tool] += 1
    probabilityStorage = []
    for tool in count.keys():
        if isinstance(tool, str):
            continue
        appearances = count.get(tool, 0)
        InitiallyActive = appearances // sheets
        probabilityExtra = appearances % sheets + (InitiallyActive)
        probabilityStorage.append((tool, probabilityExtra))
    
    probabilityStorage.sort(key=lambda x: x[1], reverse=False)
    probabilityStorage = [x[0] for x in probabilityStorage]
    while len(initialStorage[m].keys()) < toolStorageMax:
        addTool = probabilityStorage.pop(0)
        toolLifetime = 0
        while (toolLifetime < 0.05) or (toolLifetime > 1):
            toolLifetime = random()
        initialStorage[m][addTool] = toolLifetime

for x in range(len(initialStorage.keys())):
    print(len(initialStorage[x].keys()))
    print(initialStorage[x])

with open("InitialMachineStorage.json", "w") as outfile:
    json.dump(initialStorage, outfile)