import json


json_toolstorage_file = open("InitialMachineStorage.json")
json_toolstorage = json_toolstorage_file.read()
toolStorageRaw = json.loads(json_toolstorage)
toolStorageOld = {outer_k: {inner_k: float(inner_v) for inner_k, inner_v in outer_v.items()} for outer_k, outer_v in toolStorageRaw.items()}
toolStorageNew = {}

for outer_k, outer_v in toolStorageOld.items():
    counterPerMachine = 0
    if outer_k not in toolStorageNew.keys():
        toolStorageNew[outer_k] = {}
    for inner_k, inner_v in outer_v.items():
        getTool = inner_k
        getToolLifetime = inner_v
        getMachine = outer_k
        print('M:{}, Tool: {}, Tool lifetime: {}'.format(getMachine, getTool, getToolLifetime))
        print('')
        toolStorageNew[outer_k][counterPerMachine] = {getTool: getToolLifetime}
        counterPerMachine += 1

print(toolStorageNew)
