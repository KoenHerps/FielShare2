# from concurrent.futures import process
# from datetime import time
from numpy.core.numeric import False_
import pandas as pd
# import simpy
import numpy as np
import random
import math
# import threading
# import sys
# import matplotlib.pyplot as plt
# from simpy import AllOf, Event
# from itertools import count
# from statistics import mean, stdev
import json
import time as timeDouble
# from RQ4_06_Functions import calculateSimilarity

def GetProductData(workload):

    print('Get {} jobs!'.format(workload))

    minCycle = 30
    maxCycle = (60 * 8)

    exportCptJson = False
    exportPortJson = False

    ## Build cpt Dictionary > Cutting time Per Tool
    try:
        json_cpt_file = open("RQ4_13_CPT_" + str(workload) + ".json")
        json_cpt_read = json_cpt_file.read()
        json_cpt_data = json.loads(json_cpt_read)
        print('CPT already provided. {} Entries available'.format(len(json_cpt_data)))
        cpt = {outer_k: {inner_k: float(inner_v) for inner_k, inner_v in outer_v.items()} for outer_k, outer_v in json_cpt_data.items()}
    except:
        json_cpt_file = open("RQ4_13_CPT.json")
        json_cpt_read = json_cpt_file.read()
        json_cpt_data = json.loads(json_cpt_read)
        cpt = {outer_k: {inner_k: float(inner_v) for inner_k, inner_v in outer_v.items()} for outer_k, outer_v in json_cpt_data.items()}
        exportCptJson = True

    ## Build portfolio Dictionary
    try:
        json_portfolio_file = open("RQ4_14_Portfolio_" + str(workload) + ".json")
        json_portfolio_read = json_portfolio_file.read()
        json_portfolio_data = json.loads(json_portfolio_read)        
        print('Portfolio already provided. {} Entries available'.format(len(json_portfolio_data)))
    except:
        json_portfolio_file = open("RQ4_14_Portfolio.json")
        json_portfolio_read = json_portfolio_file.read()
        json_portfolio_data = json.loads(json_portfolio_read)
        exportPortJson = True
    
    portfolio = {}
    ncDatabase = {}
    totalItems = 0

    allCycles = []

    jsonDumpCpt = {}
    jsonDumpPort = []

    addedNcs = 0
    
    print('Create jobs based on portfolio entries')

    for _entry in json_portfolio_data:
        ## overall values
        _itemkey = _entry['item']
        description = _entry['description']
        wc = _entry['wc']
        mfgItem = _entry['mfgItem']
        ## nc specific values
        nc = _entry['nc']
        pa = _entry['pa']
        cycle = _entry['cycle']

        multiplier = 1
        denominator = 1.1

        cycle *= 1.2

        while cycle < minCycle:
            cycle *= (minCycle // cycle) + multiplier
            multiplier += 1
            if multiplier > 16:
                multiplier = 1
        
        while cycle > maxCycle:
            cycle /= denominator

        allCycles.append(cycle)
        
        ## if tool per job not available, do not add to portfolio
        if nc not in cpt.keys():    ## tpt also referenced to nc instead of TL
            print('CPT not available: {}'.format(nc))
            continue
        else:
            if nc not in ncDatabase:
                addedNcs += 1
                print('Add NC {} to database -- {} total'.format(nc, addedNcs))
                ncDatabase[nc] = {'cycle': cycle, 'pa': pa, 'ta': [x for x in cpt[nc].keys()], 'jobs': []}
                for ta in [x for x in cpt[nc].keys()]:
                    taCycletime = 1
                    if nc not in jsonDumpCpt:
                        jsonDumpCpt[nc] = {}
                    jsonDumpCpt[nc][ta] = taCycletime
            else:
                print('NC [{}] already in database'.format(nc))
        if _itemkey not in portfolio.keys():
            portfolio[_itemkey] = {'description': description, 'wc': wc, 'mfgItem': mfgItem, 'nc': [nc]}
            totalItems += 1
        else:
            portfolio[_itemkey]['nc'].append(nc)

        jsonDumpPort.append({'item': _itemkey, 'description': description, 'mfgItem': mfgItem, 'nc': nc, 'cycle': cycle, 'wc': wc, 'pa': pa})

    print('list unused cpt files')

    unusedNc = []
    for nc in cpt.keys():
        if nc not in ncDatabase.keys():
            print('NC {} not used'.format(nc))
            unusedNc.append(nc)

    print('Check and consolidate portfolio')

    allTools = []
    uniqueTools = []
    uniquePallets = []
    uniqueNc = []
    uniqueJobs = 0
    listToolQty = []
    listProcessingTimes = []
    for item in portfolio:
        for nc in range(len(portfolio[item]['nc'])):
            uniqueJobs += 1
            actualNc = portfolio[item]['nc'][nc]
            if actualNc not in uniqueNc:
                uniqueNc.append(actualNc)
            pa = ncDatabase[portfolio[item]['nc'][nc]]['pa']
            if ncDatabase[portfolio[item]['nc'][nc]]['pa'] not in uniquePallets:
                uniquePallets.append(pa)
            for tool in ncDatabase[portfolio[item]['nc'][nc]]['ta']:
                allTools.append(tool)
                if tool not in uniqueTools:
                    uniqueTools.append(tool)
            listToolQty.append(len(ncDatabase[portfolio[item]['nc'][nc]]['ta']))
            listProcessingTimes.append(ncDatabase[portfolio[item]['nc'][nc]]['cycle'])
    if uniqueJobs < workload:
        print('Jobs {} < Workload {}'.format(uniqueJobs, workload))
        allToolsOccurences = [(x, allTools.count(x)) for x in allTools]
        allToolsOccurences.sort(key=lambda x: (x[1], x[0]))
        allTools = [x[0] for x in allToolsOccurences]
        listToolQty.sort()
        listProcessingTimes.sort()
    # print('Pallet differentiation: {}'.format(len(uniquePallets) / len(uniqueNc)))
    # print('Tool   differentiation: {}'.format(len(uniqueTools) / len(uniqueNc)))
    # print('Unique tools: {}'.format(len(uniqueTools)))

    print('Create additional tools (if necessary)')

    toolsPerNc = len(uniqueTools) / uniqueJobs
    extraRequiredTools = int((workload * toolsPerNc) - len(uniqueTools))
    print('{} extra unique tools required: ({} * {}) - {}'.format(extraRequiredTools, workload, toolsPerNc, len(uniqueTools)))
    if (workload - uniqueJobs) == 0:
        print('Workload = {}, unique jobs {}'.format(workload, uniqueJobs))
        uniqueToolsPerNewJob = 0
    else:
        uniqueToolsPerNewJob = extraRequiredTools / (workload - uniqueJobs)
    toolId = 1
    addedTools = []
    for extraTool in range(extraRequiredTools):
        if toolId < 10:
            toolIdNew = "TA0000" + str(toolId)
        elif toolId < 100:
            toolIdNew = "TA000" + str(toolId)
        elif toolId < 1000:
            toolIdNew = "TA00" + str(toolId)
        elif toolId < 10000:
            toolIdNew = "TA0" + str(toolId)
        else:
            toolIdNew = "TA" + str(toolId)
        uniqueTools.append(toolIdNew)
        addedTools.append(toolIdNew)
        toolId += 1

    print('Create artificial jobs (if necessary)')

    itemId = 0
    setups = [2, 3]
    jobSegment = 0
    jobSegmentTotal = 10
    toolSegment = 0
    toolSegmentTotal = 50
    setupIndex = 0
    while uniqueJobs < workload:
        print("Unique Jobs != Workload -- {} != {}".format(uniqueJobs, workload))
        itemIdStr = "ArtItem-" + str(itemId) 
        description = "DescItem-" + str(itemId)
        wc = "WcItem-" + str(itemId)
        mfgItem = "MfgItem-" + str(itemId)
        for setup in range(setups[setupIndex]):
            lengthJobSegment = uniqueJobs // jobSegmentTotal
            addTools = True
            if len(unusedNc) != 0:
                nc = unusedNc.pop(0)
                pa = 'Overwritten_In_GeneratePalletNc'
                listToolQty.append(len(cpt[nc]))
                addTools = False
            else:
                nc = 'NcItem-' + str(itemId) + '-S' + str(setup+1)
                pa = 'Overwritten_In_GeneratePalletNc'
                pickToolQtySegment = listToolQty[(jobSegment * lengthJobSegment):((jobSegment+1) * lengthJobSegment)]
                taQty = int((min(pickToolQtySegment) + max(pickToolQtySegment)) / 2)
                listToolQty.append(taQty)
                listToolQty.sort()
            pickProcessingTimeSegment = listProcessingTimes[(jobSegment * lengthJobSegment):((jobSegment+1) * lengthJobSegment)]
            cycle = (min(pickProcessingTimeSegment) + max(pickProcessingTimeSegment)) / 2
            listProcessingTimes.append(cycle)
            listProcessingTimes.sort()
            jobSegment += 1
            if jobSegment == jobSegmentTotal:
                jobSegment = 0
            
            ## allocate tools
            if addTools:
                ta  = []
                addedUniqueTools = 0
                for newTa in range(taQty):
                    lengthToolSegment = len(allTools) // toolSegmentTotal
                    if (addedUniqueTools < uniqueToolsPerNewJob) and (len(addedTools) != 0):
                        newTool = addedTools.pop(0)
                        addedUniqueTools += 1
                    else:
                        newTool = allTools[(toolSegment * lengthToolSegment):((toolSegment+1) * lengthToolSegment)][0]
                    ta.append(newTool)
                    ## store in json
                    taCycletime = 1
                    if nc not in jsonDumpCpt:
                        jsonDumpCpt[nc] = {}
                    jsonDumpCpt[nc][newTool] = 1
                    ## update lists
                    allTools.append(newTool)
                    allToolsOccurences = [(x, allTools.count(x)) for x in allTools]
                    allToolsOccurences.sort(key=lambda x: (x[1], x[0]))
                    allTools = [x[0] for x in allToolsOccurences]
                    ##increment tool segment to continuously pick other segments
                    toolSegment += 1
                    if toolSegment == toolSegmentTotal:
                        toolSegment = 0
            else:
                ta = [x for x in cpt[nc].keys()]
                for newTool in ta:
                    allTools.append(newTool)

            if nc not in ncDatabase.keys():
                ncDatabase[nc] = {'cycle': cycle, 'pa': pa, 'ta': ta, 'jobs': []}
            if itemIdStr not in portfolio.keys():
                portfolio[itemIdStr] = {'description': description, 'wc': wc, 'mfgItem': mfgItem, 'nc': [nc]}
                totalItems += 1
            else:
                portfolio[itemIdStr]['nc'].append(nc)
            
            jsonDumpPort.append({'item': itemIdStr, 'description': description, 'mfgItem': mfgItem, 'nc': nc, 'cycle': cycle, 'wc': wc, 'pa': pa})

            uniqueJobs += 1
            if uniqueJobs == workload:
                break

        itemId += 1

        ## change between 2 or 3 setups dynamically
        if setupIndex == 1:
            setupIndex = 0
        else:
            setupIndex += 1

    print('Jobs created and portfolio + cpt files altered')

    if exportCptJson:
        with open('RQ4_13_CPT_' + str(workload) + '.json', 'w') as fp:
            json.dump(jsonDumpCpt, fp, indent=4, sort_keys=True)

    if exportPortJson:
        with open('RQ4_14_Portfolio_' + str(workload) + '.json', 'w') as fp:
            json.dump(jsonDumpPort, fp, indent=4, sort_keys=True)

    return portfolio, ncDatabase

def GenerateJobs(portfolio, ncDatabase, workload):
    ## generate a random joblist based on sensitivity parameters

    # print('Create workload for {} jobs'.format(workload))

    woNumber = 300000

    woListExport = []
    jobListExport = []

    itemList = [x for x in portfolio]
    i = 0

    ## First generate workorders to meet workload requirements

    woList = []
    woDict = {}
    jobList = []
    jobFamily = {}
    xrefJobOperation = {}
    xrefJobPrecedence = {}
    xrefJobSuccession = {}
    xrefJobNc = {}

    previousJobWoId = None

    print('Create jobs')

    while len(jobList) < workload:

        print('Get extra job, workload not reached (jobs {} versus workload {})'.format(len(jobList), workload))

        previousJob = None

        item = itemList[i]
        i += 1
        if i >= len(itemList):
            i = 0
        number = str(woNumber)
        description = portfolio[item]['description'] 
        woNumber += 1
    
        ## and add to list and dict

        woId = str(number)
        woList.append(woId)
        setups = int(len(portfolio[item]['nc']))
        woDict[woId] = {'wo': woId, 'item': item, 'setups': setups}
        woListExport.append({'number': number, 'item': item, 'description': description, 'setups': setups})
        jobFamily[woId] = []

        for _setup in range(setups):
            sId = str('-S') + str(_setup + 1)
            job = woId + sId
            jobFamily[woId].append(job)
            jobList.append(job)
            nc = portfolio[item]['nc'][_setup]
            if job not in xrefJobNc.keys():
                xrefJobNc[job] = nc
            if woId not in xrefJobOperation.keys():
                xrefJobOperation[woId] = [job]
            else:
                xrefJobOperation[woId].append(job)

            xrefJobPrecedence[job] = previousJob
            if previousJob != None:
                xrefJobSuccession[previousJob] = job
            if _setup == (setups - 1): ## if it is the final setup, mark job in succession None
                xrefJobSuccession[job] = None
                        
            processTimeNc = ncDatabase[nc]['cycle']
            jobListExport.append({'wo': woId, 's': sId, 'item': item, 'cycle': processTimeNc,})
            if len(jobList) == workload:
                xrefJobSuccession[job] = None
                break

            previousJob = job
            previousJobWoId = woId

    print('Jobs created, export to json')

    # toolSimilarity = calculateSimilarity(jobList, ncDatabase, xrefJobNc, 'ta')
    # print(toolSimilarity)

    with open('RQ4_05_DataInput_Workorderlist.json', 'w') as fp:
        json.dump(woListExport, fp, indent=4, sort_keys=True)

    with open('RQ4_05_DataInput_Joblist.json', 'w') as fp:
        json.dump(jobListExport, fp, indent=4, sort_keys=True)
            
    return jobList, jobFamily, xrefJobOperation, xrefJobPrecedence, xrefJobNc, xrefJobSuccession

def GeneratePalletNc(jobList, ncDatabase, xrefJobNc, expParameters):

    reassignJobs = jobList.copy()
    gPalSimN = int(math.ceil(len(jobList) / int(expParameters['Pallet'][0])))
    gPalList = [x+1 for x in range(gPalSimN)]
    sPalSimN = int(math.ceil(len(jobList) / int(expParameters['Pallet'][1])))
    sPalList = [x+1 for x in range(sPalSimN)]
    gPallet = 0
    sPallet = 0
    while reassignJobs != []:
        job = reassignJobs[0]
        if job.endswith("1"):
            assignPallet = gPalList[gPallet]
            gPallet += 1
            if gPallet > (len(gPalList)-1):
                gPallet = 0
            firstSetup = True
        else:
            assignPallet = sPalList[sPallet]
            sPallet += 1
            if sPallet > (len(sPalList)-1):
                sPallet = 0
            firstSetup = False
        nc = xrefJobNc[job]
        jobsNc = [job for job in reassignJobs if xrefJobNc[job] == nc]
        for job in jobsNc:
            reassignJobs.remove(job)
        lengthStr = len(str(assignPallet))
        if firstSetup:
            if lengthStr < 10:
                palletId = 'GP0000' + str(assignPallet)
            elif lengthStr < 100:
                palletId = 'GP000' + str(assignPallet)
            elif lengthStr < 1000:
                palletId = 'GP00' + str(assignPallet)
        else:
            if lengthStr < 10:
                palletId = 'SP0000' + str(assignPallet)
            elif lengthStr < 100:
                palletId = 'SP000' + str(assignPallet)
            elif lengthStr < 1000:
                palletId = 'SP00' + str(assignPallet)
        ncDatabase[nc]['pa'] = palletId

    exportInput = pd.DataFrame(ncDatabase)
    filenameDate = timeDouble.time()
    filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
    write = 'Input_Run_' + filenameDateAct + '.xlsx'
    with pd.ExcelWriter(write) as writer:
        exportInput.to_excel(writer, sheet_name = 'Input', index = False)
    
    # if len(jobList) != len(ncDatabase): ## if there are more jobs than unique nc programs ==> adjust tool similarity ratio
    #     orgJobNcTuple = [('DUMMY-' + str(x), x) for x in ncDatabase.keys()]
    #     orgJobList = [x[0] for x in orgJobNcTuple]
    #     orgNcDatabase = [x[1] for x in orgJobNcTuple]
    #     orgxRefJobNc = {job: nc for job, nc in zip(orgJobList, orgNcDatabase)}
    #     tarToolSim = calculateSimilarity(orgJobList, ncDatabase, orgxRefJobNc, 'ta')
    #     actToolSim = calculateSimilarity(jobList, ncDatabase, xrefJobNc, 'ta')
    #     uniqueTools = list(set([tool for tool in ncDatabase[nc]['ta'] for nc in ncDatabase.keys()]))
    #     uniqueRatio = len(uniqueTools) / len(ncDatabase)
    #     requiredUniqueTools = int(round(len(jobList) * uniqueRatio))
    #     uniqueToolsNew = [str(toolId) for toolId in range(len(uniqueTools) + requiredUniqueTools)]
    #     toolIdNew = 1
    #     if (actToolSim < tarToolSim):
    #         a = 'koen'
    #     elif (actToolSim > tarToolSim):
    #         while actToolSim > tarToolSim:
    #             allToolsUniqueJobs = [tool for tool in ncDatabase[xrefJobNc[job]]['ta'] for job in jobList]
                
    #             raise('remove from one nc')
    #             raise('prob 1 or 0 if new tool is added or replaced with less occuring one')
    #             raise('to do, select probability')

    return ncDatabase

def ChangeNcDatabases(jobList, ncDatabase, portfolio, sensitivityMethod, sensitivityParam, expParameters):

    if sensitivityMethod == 'TH':
        listTools = []
        listUniqueTools = []
        for nc in ncDatabase:
            ta = ncDatabase[nc]['ta']
            for ncta in ta:
                listTools.append(ncta)

        allToolsOccurences = [(x, listTools.count(x)) for x in listTools]
        allToolsOccurences.sort(key=lambda x: (x[1], x[0]))
        print("Tool occurences: \n{}".format(allToolsOccurences))
        listTools = [x[0] for x in allToolsOccurences]
        print('Len(ListTools) = {}'.format(len(listTools)))

        for tool in listTools:
            if tool not in listUniqueTools:
                listUniqueTools.append(tool)

        print("Len(listUniqueTools) = {}".format(len(listUniqueTools)))

        targetAmount = sensitivityParam * len(listUniqueTools)
        ##  90          0.9                 100
        if sensitivityParam < 1:
            print('Reduce amount of tools')
            indexReplaceWith = -1
            while len(listUniqueTools) > targetAmount:
                print("List unique Tools = {} vs. TargetAmount {}".format(len(listUniqueTools), targetAmount))
                ## get the least required tool
                replaceTool = listUniqueTools.pop(0)
                ## replace for most required tool
                replaceWithTool = listUniqueTools[indexReplaceWith]
                print('Replace Tool {} with Tool {}'.format(replaceTool, replaceWithTool))
                for nc in ncDatabase:
                    tl = ncDatabase[nc]['ta']
                    newTl = []
                    for ta in tl:
                        if ta == replaceTool:
                            newTa = replaceWithTool
                        else:
                            newTa = ta
                        newTl.append(newTa)
                    ncDatabase[nc]['ta'] = newTl
                ## next time get the next most required tools (otherwise they are all replaced with the same tool)
                indexReplaceWith -= 1
        else: #sensitivityParam > 1
            print('Increase amount of tools')
            idReplacedTool = 1
            replaceToolWithIndex = 0
            divideToolbyX = 25
            newUniqueTools = []
            while (len(listUniqueTools) + len(newUniqueTools)) < targetAmount:
                replaceTool = listUniqueTools.pop(-1)
                for nc in ncDatabase:
                    tl = ncDatabase[nc]['ta']
                    newTl = []
                    ## replace tool with divideToolbyX instances
                    idReplacedToolAct = int(idReplacedTool + replaceToolWithIndex)
                    if idReplacedToolAct < 10:
                        replaceWithTool = 'RTA000' + str(idReplacedToolAct)
                    elif idReplacedToolAct < 100:
                        replaceWithTool = 'RTA00' + str(idReplacedToolAct)
                    elif idReplacedToolAct < 1000:
                        replaceWithTool = 'RTA0' + str(idReplacedToolAct)
                    else:
                        replaceWithTool = 'RTA' + str(idReplacedToolAct)
                    for ta in tl:
                        if ta == replaceTool:
                            newTa = replaceWithTool
                        else:
                            newTa = ta   
                        newTl.append(newTa)
                    ncDatabase[nc]['ta'] = newTl
                    if replaceWithTool not in newUniqueTools:
                        newUniqueTools.append(replaceWithTool)
                    replaceToolWithIndex += 1
                    if replaceToolWithIndex == divideToolbyX:
                        replaceToolWithIndex = 0
                    # print('Replace tool {} with {}'.format(replaceTool, replaceWithTool))
                idReplacedTool += divideToolbyX
        
        listTools = []
        for nc in ncDatabase:
            ta = ncDatabase[nc]['ta']
            for ncta in ta:
                listTools.append(ncta)
                if ncta not in listUniqueTools:
                    listUniqueTools.append(ncta)
        print('Len(ListTools) = {}'.format(len(listTools)))
        print('Len(listUniqueTools) = {}'.format(len(listUniqueTools)))

        allToolsOccurences = [(x, listTools.count(x)) for x in listTools]
        allToolsOccurences.sort(key=lambda x: (x[1], x[0]))
        print("Tool occurences: \n{}".format(allToolsOccurences))

    if sensitivityMethod == 'AM':
        amountOperationsAffected = int(len(portfolio) * sensitivityParam)
        nthOperation = int((1 / sensitivityParam))
        listofitems = [item for item in portfolio]

        sPalSimN = int(math.ceil(len(jobList) / int(expParameters['Pallet'][1])))
        sPalList = [x+1 for x in range(sPalSimN)]
        sPallet = 0

        for affectOperationIndex in range(amountOperationsAffected):
            indexOperation = int((nthOperation * affectOperationIndex))
            affectedOperation = listofitems[indexOperation]
            affectedJobs = portfolio[affectedOperation]['nc']
            for nc in affectedJobs:
                ## change cycle time
                ncDatabase[nc]['cycle'] / 10
                ## change pallet to specific pallet
                assignPallet = sPalList[sPallet]
                sPallet += 1
                if sPallet > (len(sPalList)-1):
                    sPallet = 0
                lengthStr = len(str(assignPallet))
                if lengthStr < 10:
                    palletId = 'SP0000' + str(assignPallet)
                elif lengthStr < 100:
                    palletId = 'SP000' + str(assignPallet)
                elif lengthStr < 1000:
                    palletId = 'SP00' + str(assignPallet)
                ncDatabase[nc]['pa'] = palletId

    return portfolio, ncDatabase

def getEmpiricalData():

    json_toolstorage_file = open("RQ4_12_InitialToolStorage.json")
    json_toolstorage = json_toolstorage_file.read()
    toolStorageRaw = json.loads(json_toolstorage)
    toolStorageAct = {outer_k: {inner_k: float(inner_v) for inner_k, inner_v in outer_v.items()} for outer_k, outer_v in toolStorageRaw.items()}

    return toolStorageAct

def ClusterInitialData(jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, experiment, expParameter, actToolStorage, jobFamily, xrefJobSuccession):
    initialData = [jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, actToolStorage, jobFamily, xrefJobSuccession]

    exportData = []

    for job in jobList:
        exportData.append([job, xrefJobNc[job], ncDatabase[xrefJobNc[job]]['cycle'], len(ncDatabase[xrefJobNc[job]]['ta']), len(np.unique(ncDatabase[xrefJobNc[job]]['ta']))])

    # dfInputData = pd.DataFrame(exportData, columns=['operation', 'nc', 'cycle', 'qtyTools', 'uniqueTools'])
    # filenameDate = timeDouble.time()
    # filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
    # write = 'InputData_' + str(experiment) + '_' + str(expParameter) + '_' + filenameDateAct + '.xlsx'
    # with pd.ExcelWriter(write) as writer:
    #     dfInputData.to_excel(writer, sheet_name = 'Input', index = False)

    ncOverview = {}
    ncToolOverview = {}
    toolOverview = {}
    toolStats = {}
    uniqueTools = []

    ncDf = pd.DataFrame.from_dict({i: ncOverview[i] for i in ncOverview.keys()}, orient='index')
    ncDf['NC'] = ncDf.index
    ncDf = ncDf.reset_index(drop=True)

    nctoolDf = pd.DataFrame.from_dict({i: ncToolOverview[i] for i in ncToolOverview.keys()}, orient='index')
    nctoolDf['NC'] = nctoolDf.index
    nctoolDf = nctoolDf.reset_index(drop=True)

    toolDf = pd.DataFrame.from_dict({i: toolOverview[i] for i in toolOverview.keys()}, orient='index')
    toolDf['Tool'] = toolDf.index
    toolDf = toolDf.reset_index(drop=True)

    filenameDate = timeDouble.time()
    filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
    write = 'InputData_Detailed_' + str(experiment) + '_' + str(expParameter) + '_' + filenameDateAct + '.xlsx'

    return initialData

def GetInitialVectors(jobList, cncCapacity, palletCapacity):
    sequenceVector = []
    machineVector = []
    palletVector = []
    openPositions = [x for x in range(len(jobList))]
    for job in jobList:
        getRandomInt = random.randint(0, len(openPositions) - 1)
        sequenceVector.append(openPositions.pop(getRandomInt))
        machineVector.append(random.randint(0, cncCapacity - 1))
        palletVector.append(random.randint(0, palletCapacity - 1))
    
    return sequenceVector, machineVector, palletVector

if __name__ == '__main__':
    cncCapacity = 2
    palletCapacity = cncCapacity * 8
    runUntil = (60*24*3) + 1
    productVariety = 1
    workload = 1
    operMax = 10
    portfolio, ncDatabase = GetProductData()
    jobList, xrefJobOperation, xrefJobPrecedence, xrefJobNc = GenerateJobs(portfolio, ncDatabase, 152)
    actToolStorage = getEmpiricalData()
    initialData = ClusterInitialData(jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, 'B', 1, actToolStorage)
    sequenceVector, machineVector, palletVector = GetInitialVectors(jobList, cncCapacity, palletCapacity)
