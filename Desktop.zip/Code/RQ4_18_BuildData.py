import datetime
from random import random
import time
import json
import pandas as pd
import numpy as np
import random
from statistics import mean, stdev

thresholdTools  = 80

ncOverview = {}
toolOverview = {}
ncToolOverview = {}

cptDict ={'CPT': []}
cptData = pd.read_excel(r'RQ4_20_EmpiricalCPTData.xlsx', engine='openpyxl')

for record in cptData.values:
    MachineId = record[1]
    MainPGM = record[2]
    Tnumber = record[3]
    cptMin = record[4]
    cptMax = record[5]
    cptAvg = record[6]
    cptMed = record[7]
    mfgItem = record[9]
    if (type(mfgItem) == str):
        add = {'MachineId': MachineId, 'MainPGM': MainPGM, 'Tnumber': Tnumber, 'Statistics': {'Min': cptMin, 'Max': cptMax, 'Avg': cptAvg, 'Med': cptMed}, 'MfgItem': mfgItem}
        cptDict['CPT'].append(add)

with open('RQ2_11_MachineDataNew.json', 'w') as fp:
    json.dump(cptDict, fp, indent=4, sort_keys=True)

machineData_raw = open("RQ2_11_MachineDataNew.json")
machineData_read = machineData_raw.read()
machineData = json.loads(machineData_read)

plmData = pd.read_excel(r'RQ4_10_PLM.xlsx', engine='openpyxl')

tptValues = [5, 10, 15, 20, 30, 40, 50, 75, 100, 125, 150]

xrefNcMfgItem = {}

cptDict = {}
evaluateOK = []
evaluateNOK = []

for record in range(len(machineData['CPT'])):
    nc = machineData['CPT'][record]['MainPGM']
    mfgItem = machineData['CPT'][record]['MfgItem']
    toolnumber = machineData['CPT'][record]['Tnumber']
    cptVal = int(machineData['CPT'][record]['Statistics']['Med']) / 1000 / 60    # from milliseconds to seconds to minutes
    while (cptVal > 60):               ## if a tool is required for more than 60 minutes, reduce the processing time
        cptVal /= 2
    if nc not in xrefNcMfgItem.keys():
        xrefNcMfgItem[nc] = mfgItem
    if nc not in cptDict:
        cptDict[nc] = {}
    if toolnumber in cptDict[nc]:
        cptDict[nc][toolnumber] += cptVal
    else:
        cptDict[nc][toolnumber] = cptVal

nrUniquePallets = [pa for pa in range(len(cptDict.keys()))]

uniqueTools = []
count = 0
max = 0

plmDict = []

toolStats = {}

for nc in xrefNcMfgItem:
    mfgItem = xrefNcMfgItem[nc]
    try:
        item = plmData.loc[plmData['Mfg Item'] == mfgItem, 'Item'].iloc[0]
        description = plmData.loc[plmData['Mfg Item'] == mfgItem, 'Description'].iloc[0]
    except:
        print('continue')
        continue
    count += 1
    qtyTools = len(cptDict[nc])
    if qtyTools > thresholdTools:
        raise ('Too many tools in nc')
    processTime = 0
    if qtyTools > max:
        max = qtyTools
    for toolnumber in cptDict[nc]:
        if toolnumber not in uniqueTools:
            uniqueTools.append(toolnumber)
        processTimeTool = cptDict[nc][toolnumber]
        processTime += processTimeTool
        if toolnumber not in toolStats.keys():
            toolStats[toolnumber] = [processTimeTool]
        else:
            toolStats[toolnumber].append(processTimeTool)
        if toolnumber not in toolOverview.keys():
            toolOverview[toolnumber] = {'n': 1, 'sum': processTimeTool, 'cpt avg': 0, 'cpt std': 0}
        else:
            toolOverview[toolnumber]['n'] += 1
            toolOverview[toolnumber]['sum'] += processTimeTool
            toolOverview[toolnumber]['cpt avg'] = mean(toolStats[toolnumber])
            toolOverview[toolnumber]['cpt std'] = stdev(toolStats[toolnumber])

    if nc not in ncOverview:
        ncOverview[nc] = {'processtime': processTime, 'qtyTools' : qtyTools}
    pa = None
    while pa == None:
        for paID in nrUniquePallets:
            selectPA = random.choices([True, False], weights=[1/len(nrUniquePallets), (1 - (1/len(nrUniquePallets)))])[0]
            if selectPA:
                if paID < 10:
                    identifier = 'PA0000' + str(paID)
                elif paID < 100:
                    identifier = 'PA000' + str(paID)
                elif paID < 1000:
                    identifier = 'PA00' + str(paID)
                elif paID < 10000:
                    identifier = 'PA0' + str(paID)
                else:
                    identifier ='PA' + str(paID)
                pa = identifier
                break
    plmDict.append({'item': item, 'description': description, 'mfgItem': mfgItem, 'nc': nc, 'cycle': processTime, 'wc': '1200G350', 'pa': pa})

sheets = 5
machines = ['1733', '2107', '10052']
toolStorageMax = 80
combinedFiles = {}

for m in range(len(machines)):
    for sheet in range(sheets):
        sheetname = 'Sheet' + str(sheet+1)
        machine = machines[m]
        filename = machine + '-' + sheetname
        writefile = pd.read_excel(r'C:\Users\20180136\Documents\Code\python\KMWE00011.1 IPMTCFC\InitialToolStorage\\' + machine + '.xlsx', engine='openpyxl', sheet_name=sheetname)
        if m not in combinedFiles.keys():
            combinedFiles[m] = {}
        combinedFiles[m][filename] = writefile

initialStorage = {}
for m in combinedFiles.keys():
    if m not in initialStorage.keys():
        initialStorage[m] = {}
    count = {}
    for dataEntry in combinedFiles[m].values():
        activeTools = dataEntry['Name'].values
        for tool in activeTools:
            if tool not in count.keys():
                count[tool] = 1
            else:
                count[tool] += 1
    probabilityStorage = []
    for tool in count.keys():
        if isinstance(tool, str):
            continue
        appearances = count.get(tool, 0)
        InitiallyActive = appearances // sheets
        probabilityExtra = appearances % sheets + (InitiallyActive)
        probabilityStorage.append((tool, probabilityExtra))
    
    probabilityStorage.sort(key=lambda x: x[1], reverse=False)
    probabilityStorage = [x[0] for x in probabilityStorage]
    while len(initialStorage[m].keys()) < toolStorageMax:
        addTool = probabilityStorage.pop(0)
        toolLifetime = 0
        while (toolLifetime < 0.05) or (toolLifetime > 1):
            toolLifetime = random.random()
        initialStorage[m][addTool] = toolLifetime

with open("RQ4_12_InitialToolStorage.json", "w") as outfile:
    json.dump(initialStorage, outfile)

with open('RQ4_13_CPT.json', 'w') as fp:
    json.dump(cptDict, fp, indent=4, sort_keys=True)

with open('RQ4_14_Portfolio.json', 'w') as fp:
    json.dump(plmDict, fp, indent=4, sort_keys=True)

#######################################################################################################


ncDf = pd.DataFrame.from_dict({i: ncOverview[i] for i in ncOverview.keys()}, orient='index')
ncDf['NC'] = ncDf.index
ncDf = ncDf.reset_index(drop=True)

nctoolDf = pd.DataFrame.from_dict({i: ncToolOverview[i] for i in ncToolOverview.keys()}, orient='index')
nctoolDf['NC'] = nctoolDf.index
nctoolDf = nctoolDf.reset_index(drop=True)

toolDf = pd.DataFrame.from_dict({i: toolOverview[i] for i in toolOverview.keys()}, orient='index')
toolDf['Tool'] = toolDf.index
toolDf = toolDf.reset_index(drop=True)

write = 'RQ4_19_Check_Data.xlsx'

with pd.ExcelWriter(write) as writer:
    ncDf.to_excel(writer, sheet_name='Check_Nc')
    nctoolDf.to_excel(writer, sheet_name='Check_NcTool')
    toolDf.to_excel(writer, sheet_name='Check_Tool')