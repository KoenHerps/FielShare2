 # 0. python file,   1. problem file,    2. generations  3. optimal, 4. population size
import numpy as np
import itertools
import json
import os
import pandas as pd
import time as timeDouble

from RQ4_06_Functions import calculateChangeIndex

# class RLA():

#     def __init__(self, epMax, epIterMax, alpha, gamma, epsilon, div, cProbLen, mMethodLen, mProbLen, conversionReached):
#         ##################################################################################################################
#         #------------------------------------------------ Hyperparameters ------------------------------------------------
#         # the learning rate
#         self.alpha = alpha

#         # the discount rate
#         self.gamma = gamma

#         # the exploration rate
#         self.epsilon = epsilon

#         # learnign controller
#         self.conversionReached = conversionReached
#         self.nStates = 0
#         self.nActions = 0
    
#         ##################################################################################################################
#         #--------------------------------------- action, state, and reward spaces ----------------------------------------
#         # get all combinations of crossover and mutation probabilites and convert it to a list 
#         self.stateSpace = []
#         stateExport = []
#         for ux in range(0, div+1):
#             for ox in range(0, div+1):
#                 for pmx in range(0, div+1):
#                     for xx in range(0, div+1):
#                         for cProb in range(cProbLen):
#                             for mMethod in range(mMethodLen):
#                                 for mProb in range(mProbLen):
#                                     if (ux + ox + pmx + xx) != 0:
#                                         self.stateSpace.append([ux, ox, pmx, xx, cProb, mMethod, mProb])
#                                         stateExport.append({'state': len(self.stateSpace)-1, 'ux': ux, 'ox': ox, 'pmx': pmx, 'xx': xx, 'cProb': cProb, 'mMethod': mMethod, 'mProb': mProb})
#                                         # print('State [{}]: {}'.format(len(self.stateSpace)-1, [ux, ox, pmx, xx, cProb, mMethod, mProb]))
#                                         self.nStates += 1

#         with open('RQ4_08_RLA_States.json', 'w') as fp:
#             json.dump(stateExport, fp, indent=4, sort_keys=True)

#         # a list of all possible actions
#         self.actionSpace = []
#         for uxChange in range(-1, 2):
#             for oxChange in range(-1, 2):
#                 for pmxChange in range(-1, 2):
#                     for xxChange in range(-1, 2):
#                         for cProbChange in range(-1, 2):
#                             for mProbChange in range(-1, 2):
#                                 for mMethodChange in range(-1, 2):
#                                     actions = [uxChange, oxChange, pmxChange, xxChange, cProbChange, mProbChange, mMethodChange]
#                                     if (len([x for x in actions if x == 0]) == 6):
#                                         self.actionSpace.append(actions)
#                                         # print('Action [{}]: {}'.format(len(self.actionSpace)-1, actions))

#         self.stateActions = {}
#         totalAllowedActions = 0
#         for state in self.stateSpace:
#             stateId = self.stateSpace.index(state)
#             for action in self.actionSpace:
#                 actionId = self.actionSpace.index(action)
#                 idx = [idx for idx, val in enumerate(action) if val != 0][0]
#                 newState = state.copy()
#                 change = action[idx]
#                 newState[idx] += change
#                 cWeights = newState[0] + newState[1] + newState[2] + newState[3]
#                 if cWeights != 0:
#                     cProb = newState[4]
#                     if (cProb >= 0) and (cProb < cProbLen):
#                         mMethod = newState[5]
#                         if (mMethod >= 0) and (mMethod < mMethodLen):
#                             mProb = newState[6]
#                             if (mProb >= 0) and (mProb < mProbLen):
#                                 if newState in self.stateSpace:
#                                     if stateId not in self.stateActions.keys():
#                                         self.stateActions[stateId] = [actionId]
#                                     else:
#                                         self.stateActions[stateId].append(actionId)        
#                                     totalAllowedActions +=1
#                                     self.nActions +=1

#         # get the rewards table
#         self.rewardSpace = {'(++, HD)': 150, '(++, MD)':100, '(++, LD)':50,  
#                            '(+, HD)' :100,'(+, MD)':62.5, '(+, LD)':25,
#                             '(0, HD)':50, '(0, MD)':25, '(0, LD)':0,
#                             '(-, HD)':0, '(-, MD)':-12.5, '(-, LD)':-25}

#         # initilize the Q-table
#         self.Q = np.zeros([len(self.stateSpace), len(self.actionSpace)])

#         ##################################################################################################################
#         # ----------------------------------------------- initialization  ------------------------------------------------
#         # variables keeping track of the current episode
#         self.kGaGenerations = 0                                         ## to track the amount of times the GA processed an generations
#         self.kEpIter = 0                                                ## to track the number of iterations within an episode
#         self.kEpIterMax = epIterMax                                     ## maximum number of iterations until the episode is done
#         self.kEp = 0                                                    ## to track the number of episodes
#         self.kEpMax = epMax                                             ## the maximum amount of allowed episodes
#         self.overallIter = 0
#         # self.epsilonStep = (self.epsilon - 0.05) / self.kEpMax
#         # self.alphaStep = (self.alpha - 0.05) / self.kEpMax
        
#         ## recalculate avg numbe of actions to propose conversion
#         self.nActionsAvg = self.nActions / self.nStates

#         # a variable keeping track og hum many times the RL agent is iterared
#         # self.iterRL = 0
#         # self.iterGA = 0
        
#         # a variable keeping track of how much rewards it has recieved
#         self.collected  = 0

#         # create an array to keep count how often each action was taken
#         self.actionCount = np.zeros(len(self.actionSpace))
#         self.qAction = None
#         self.greedy = False
#         self.choice = []

#         # the previous population is set to an empty list
#         self.generations = []

#         # the previous fitness variable is initilized with a verh high cost
#         self.prevFitness = float('inf')
        
#         # the current fitness delta
#         self.fitness = 0
#         self.fitnessBest = 0
#         self.fitnessAvg = 0
#         self.fitnessDeltas = []

#         # the current change index
#         self.changeIndex = 1
#         self.changeIndices = []
        
#         # the current reward awarded
#         self.immediateReward = 0

#         # initialize the first state (0,0,0,0,0.1,0,0.1)
#         self.currState = 0
#         self.nextState = 0
#         self.rewardState = '(0, MD)'

#         self.updateQ = 0

#         self.running = True

#         # the first stateAction are given
#         ## self.stateAction refers to the index of the action in the stateAction space > NOT in the self.actionSpace
#         self.stateAction = self.stateActions[self.currState][0]   ## take the first stateAction from the list of eligible actions

#         self.results = []

#         # # initialie the json file
#         # self.json = str(run) + '.json'
#         # with open(self.json, 'w') as f:
#         #     json.dump({}, f)

#     def initializeRL(self):

#         # print()
#         # print('\tInitialize RL')
#         # print()

#         self.actionCount = np.zeros(len(self.actionSpace))

#         self.qAction = self.stateActions[self.currState][self.stateAction]
#         self.actionCount[self.qAction] += 1

#         # print('\tInitial state:      {}'.format(self.stateSpace[self.currState]))
#         # print('\tInitial action:     {}'.format(self.actionSpace[self.qAction]))

#         self.nextState = self.__getNextState()

#         # print('\tInitial next state: {}'.format(self.stateSpace[self.nextState]))
#         # print()

#         return [self.stateSpace[self.nextState][0], self.stateSpace[self.nextState][1], self.stateSpace[self.nextState][2], self.stateSpace[self.nextState][3]], self.stateSpace[self.nextState][4], self.stateSpace[self.nextState][5], self.stateSpace[self.nextState][6]

#     def analyzeRL(self, generations):

#         # print('\tAnalyze previous state + action')
#         # print()

#         self.fitness = self.__getFitness(generations)
#         self.fitnessDeltas.append(self.fitness)
#         self.changeIndex = self.__getChangeIndex(generations)
#         self.changeIndices.append(self.changeIndex)

#         self.immediateReward = self.__getReward(self.fitness, self.changeIndex)
#         self.futureReward = self.__getMax(1, self.nextState)
#         self.collected += self.immediateReward

#         # print('\tQ(s, a):        {}'.format(self.stateSpace[self.currState]))
#         # print('\tA:              {}'.format(self.actionSpace[self.qAction]))
#         # print('\tR Q(s, a):      {}'.format(self.immediateReward))
#         # print('\tQ(s+1, a+1):    {}'.format(self.stateSpace[self.nextState]))
#         # print('\tyR Q(s+1, a+1): {}'.format(self.futureReward))
#         # print()

#         # print('\tFitness deltas: {}'.format([round(x, 3) for x in self.fitnessDeltas]))
#         # print('\tChange Indexes: {}'.format([round(x, 3) for x in self.changeIndices]))
#         # print()

#     def updateRL(self, gaK):

#         # print('\tUpdate RL and Q-table')
#         # print()

#         oldQ = self.Q[self.currState, self.qAction]

#         ## Bellman equation
#         # print('\tCurrent Q(s, a): {}'.format(self.Q[self.currState, self.qAction]))
#         self.updateQ = self.alpha * (self.immediateReward + self.gamma * self.futureReward - self.Q[self.currState, self.qAction])
#         # print('\tUpdate Q:        {}'.format(self.updateQ))
#         # print('\tUpdate value =   {} --- alpha {} * (R(s, a): {} + gamma {} * R(s+1, a+1): {} - Q(s, a): {})'.format((self.alpha * (self.immediateReward + self.gamma * self.futureReward - self.Q[self.currState, self.qAction])), self.alpha, self.immediateReward, self.gamma, self.futureReward, self.Q[self.currState, self.qAction]))
#         self.Q[self.currState, self.qAction] += self.updateQ
#         # print('\tNew Q(s, a):     {}'.format(self.Q[self.currState, self.qAction]))
#         # print()

#         self.__persistResults(oldQ, gaK)

#         self.kEpIter += 1
#         self.overallIter += 1
#         if self.kEpIter == self.kEpIterMax:     ## number of iterations within an episode done
#             self.kEp += 1
#             self.kEpIter = 0

#         if self.overallIter >= (self.nStates * self.nActionsAvg) / 2:
#             self.conversionReached = True
#             # self.alpha -= self.alphaStep
#             # self.epsilon -= self.epsilonStep

#     def iterateRL(self):

#         # print('\tIterate RL and define next action giving new state')
#         # print('\tEpisode [{}] - Next Iteration: {}'.format(self.kEp, self.kEpIter))
#         # print()

#         ## FIRST: STEP TO NEXT STATE
#         self.currState = self.nextState

#         ## SECOND: DECIDE THE NEXT STEP
#         if np.random.random() < self.epsilon:
#             self.stateAction = int(np.random.randint(low=0, high=len(self.stateActions[self.currState])))
#             self.greedy = False
#         else:
#             self.stateAction = int(self.__getMax(0, self.currState))
#             self.greedy = True
        
#         self.qAction = self.stateActions[self.currState][self.stateAction]
#         self.actionCount[self.qAction] += 1

#         ## THIRD: GET THE NEW NEXT STATE
#         self.nextState = self.__getNextState()

#         # print('\tCurr state: {}'.format(self.stateSpace[self.currState]))
#         # print('\tAction:     {}'.format(self.actionSpace[self.qAction]))
#         # print('\tNew state:  {}'.format(self.stateSpace[self.nextState]))

#         return [self.stateSpace[self.nextState][0], self.stateSpace[self.nextState][1], self.stateSpace[self.nextState][2], self.stateSpace[self.nextState][3]], self.stateSpace[self.nextState][4], self.stateSpace[self.nextState][5], self.stateSpace[self.nextState][6]

#     def __persistResults(self, oldQ, gaK):
        
#         action = self.actionSpace[self.qAction]
#         fitnessDelta = float(round(self.fitness, 3))
#         fitnessBest = float(round(self.fitnessBest, 3))
#         fitnessAvg = float(round(self.fitnessAvg, 3))
#         changeIndex = float(round(self.changeIndex, 3))
#         immReward = int(self.immediateReward)
#         futReward = int(self.futureReward)
#         newQ = self.Q[self.currState, self.qAction]
#         result = [self.currState, self.qAction, self.greedy, self.nextState, oldQ, fitnessDelta, fitnessBest, fitnessAvg, changeIndex, self.alpha, immReward, self.gamma, futReward, newQ, gaK, self.stateSpace[self.currState], self.actionSpace[self.qAction], self.stateSpace[self.nextState], self.choice]
        
#         self.results.append(result)

#     def __getMax(self, reqParameter, state):
#         ## reqParameter; 1 if value is required, 0 if index in row is required

#         stateActions = self.stateActions[state]
#         qValues = list(map(self.Q[self.currState].__getitem__, stateActions))
#         if reqParameter == 0:
#             self.choice = qValues


#         bests = []
#         best = float('inf')
#         for qIdx in range(len(qValues)):
#             qVal = qValues[qIdx]
#             if qVal < best:
#                 bests = []
#                 best = qVal
#                 bests.append([qIdx, qVal])
#             elif qVal == best:
#                 bests.append([qIdx, qVal])

#         arbitraryPick = np.random.choice(np.arange(len(bests)))

#         return bests[arbitraryPick][reqParameter]

#     def __getFitness(self, generations):
        
#         if len(generations) > 1:
#             currGeneration = generations[-1]
#             bmGeneration = generations[-2]
#             # fitnesses = [(generation, generation.bestGenerationResult) for generation in generations]
#             # bestFitness = min(fitnesses, key = lambda t: t[1])[1]
#             # delta = self.prevFitness - bestFitness
#             # deltaFitness = delta / self.prevFitness

#             # fitnesses = [(generation, generation.bestGenerationResult) for generation in generations]
#             # bestFitness = min(fitnesses, key = lambda t: t[1])[1]
#             deltaFitnessBest = (currGeneration.bestGenerationResult - bmGeneration.bestGenerationResult) / bmGeneration.bestGenerationResult
#             deltaFitnessAvg = (currGeneration.avgResult - bmGeneration.avgResult) / bmGeneration.avgResult
#             deltaFitness = ((2*deltaFitnessBest) + deltaFitnessAvg) / 3

#             self.fitnessBest = deltaFitnessBest
#             self.fitnessAvg = deltaFitnessAvg

#             return deltaFitness
    
#         else:
#             return 0

#     def __getChangeIndex(self, generations):

#         changeRatios = []
#         for generation in generations:
#             for chromosome in generation.population:
#                 if chromosome.parent1 != None:
#                     changeIndexMachine, changeIndexPallet = calculateChangeIndex(chromosome)
#                     changeRatio = (changeIndexMachine + changeIndexPallet) / 2
#                     changeRatios.append(changeRatio)
#                     # print('Change Ratios: {} - {} - {}'.format(changeRatioSeq, changeRatioMachine, changeRatioPallet))

#         totalChangeIndex = sum(changeRatios) / len(changeRatios)

#         # print('\tChange index:\t{}'.format(round(totalChangeIndex, 3)))

#         return totalChangeIndex

#     def __getReward(self, fitness, changeIndex):

#         if fitness < -0.015:
#             fState = '++'
#         elif fitness < -0.0025:
#             fState = '+'
#         elif fitness < 0.0125:
#             fState = '0'
#         else:
#             fState = '-'

#         if changeIndex < (0.7):
#             cState = 'LD'
#         elif changeIndex < (0.85):
#             cState = 'MD'
#         else:
#             cState = 'HD'

#         rewardState = '(' + fState + ', ' + cState + ')'
#         print()
#         print('Reinforcement Learning Agent')
#         print()
#         print('fitness: {}, change: {} -- reward = {}'.format(round(fitness,3), round(changeIndex,3), rewardState))
#         reward = self.rewardSpace[rewardState]
#         return reward

#     def __getNextState(self):
#         ## get current state list([x,x,x,...])
#         ## output: index of new state list([x,x,x,...]) in self.stateSpace

#         newState = self.stateSpace[self.currState].copy()
#         actionTuple = [(idx, val) for idx, val in enumerate(self.actionSpace[self.qAction]) if val != 0][0]
#         newState[actionTuple[0]] += actionTuple[1]

#         nextState = self.__findState(newState)

#         if type(nextState) != int:
#             print('ERROR in getting new nextState. nextState: {}. Build on newState: {}'.format(nextState, newState))

#         return nextState

#     def __findState(self, newState):
#         ## input:  newState = list([x, x, x,...]) that represents that actual values per state
#         ## output: the index of that given state in the self.stateSpace environment

#         if type(newState) != list:
#             print('ERROR in __findState. newState: {}'.format(newState))

#         for i in range(len(self.stateSpace)):
#             if self.stateSpace[i] == newState:
#                 return i
        
#         print('ERROR. No result in __findState. newState: {}'.format(newState))
#         raise('Check Error')

#     def exportResults(self, suffix):

#         exportQTable = pd.DataFrame(self.Q)
#         filenameDate = timeDouble.time()
#         filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
#         write = 'GRL_Qtable_' + suffix + '.xlsx'
#         with pd.ExcelWriter(write) as writer:
#             exportQTable.to_excel(writer, sheet_name = 'Q_Table', index = False)

#         dfExportRL = pd.DataFrame(self.results, columns=['stateIdx', 'actionIdx', 'greedy', 'nextIdx', 'oldQ', 'fitnessDelta', 'fitnessBest', 'fitnessAvg', 'changeIndex', 'alpha', 'immReward', 'gamma', 'futReward', 'newQ', 'gaK', 'state', 'action', 'next', 'q choices'])
#         filenameDate = timeDouble.time()
#         filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
#         write = 'RL_Process_' + suffix + '.xlsx'
#         with pd.ExcelWriter(write) as writer:
#             dfExportRL.to_excel(writer, sheet_name = 'Progress', index = False)

#     def loadQTable(self, QTable):

#         bestState = None
#         bestAction = None
#         maxStateAction = 0
#         for stateIndex in range(len(QTable)):
#             state = QTable[stateIndex]
#             for actionIndex in range(len(state)):
#                 actionVal = state[actionIndex]
#                 if actionVal > maxStateAction:
#                     maxStateAction = actionVal
#                     bestState = stateIndex
#                     bestAction = actionIndex
#         startStateAction = 0
#         for stateSpaceIndex in range(bestAction):
#             if stateSpaceIndex == bestAction:
#                 break
#             if stateSpaceIndex in self.stateActions[bestState]:
#                 startStateAction += 1

#         return bestState, startStateAction


## NEW CLASS RLA [16-10]

class RLA():

    def __init__(self, epMax, epIterMax, alpha, gamma, epsilon, div, cProbLen, mMethodLen, mProbLen, conversionReached):
        ##################################################################################################################
        #------------------------------------------------ Hyperparameters ------------------------------------------------
        # the learning rate
        self.alpha = alpha

        # the discount rate
        self.gamma = gamma

        # the exploration rate
        self.epsilon = epsilon

        # learnign controller
        self.conversionReached = conversionReached
        self.nStates = 0
        self.nActions = 0
    
        ##################################################################################################################
        #--------------------------------------- action, state, and reward spaces ----------------------------------------
        # get all combinations of crossover and mutation probabilites and convert it to a list 
        self.stateSpace = []
        stateExport = []
        for ux in range(0, div+1):
            for ox in range(0, div+1):
                for pmx in range(0, div+1):
                    for xx in range(0, div+1):
                        for cProb in range(cProbLen):
                            for mMethod in range(mMethodLen):
                                for mProb in range(mProbLen):
                                    if (ux + ox + pmx + xx) != 0:
                                        self.stateSpace.append([ux, ox, pmx, xx, cProb, mMethod, mProb])
                                        stateExport.append({'state': len(self.stateSpace)-1, 'ux': ux, 'ox': ox, 'pmx': pmx, 'xx': xx, 'cProb': cProb, 'mMethod': mMethod, 'mProb': mProb})
                                        print('State [{}]: {}'.format(len(self.stateSpace), [ux, ox, pmx, xx, cProb, mMethod, mProb]))
                                        self.nStates += 1

        with open('RQ4_08_RLA_States.json', 'w') as fp:
            json.dump(stateExport, fp, indent=4, sort_keys=True)

        # a list of all possible actions
        self.actionSpace = []
        for uxChange in range(-1, 2):
            for oxChange in range(-1, 2):
                for pmxChange in range(-1, 2):
                    for xxChange in range(-1, 2):
                        for cProbChange in range(-1, 2):
                            for mProbChange in range(-1, 2):
                                for mMethodChange in range(-1, 2):
                                    actions = [uxChange, oxChange, pmxChange, xxChange, cProbChange, mProbChange, mMethodChange]
                                    if (len([x for x in actions if x == 0]) == 6):
                                        self.actionSpace.append(actions)
                                        print('Action [{}]: {}'.format(len(self.actionSpace), actions))

        self.stateActions = {}
        totalAllowedActions = 0
        for state in self.stateSpace:
            stateId = self.stateSpace.index(state)
            for action in self.actionSpace:
                actionId = self.actionSpace.index(action)
                idx = [idx for idx, val in enumerate(action) if val != 0][0]
                newState = state.copy()
                change = action[idx]
                newState[idx] += change
                cWeights = newState[0] + newState[1] + newState[2] + newState[3]
                if cWeights != 0:
                    cProb = newState[4]
                    if (cProb >= 0) and (cProb < cProbLen):
                        mMethod = newState[5]
                        if (mMethod >= 0) and (mMethod < mMethodLen):
                            mProb = newState[6]
                            if (mProb >= 0) and (mProb < mProbLen):
                                if newState in self.stateSpace:
                                    if stateId not in self.stateActions.keys():
                                        self.stateActions[stateId] = [actionId]
                                    else:
                                        self.stateActions[stateId].append(actionId)        
                                    totalAllowedActions +=1
                                    self.nActions +=1

        # initilize the Q-table
        self.Q_best = {state: [0 for action in range(len(self.actionSpace))] for state in range(len(self.stateSpace))}
        self.Q_avg = {state: [0 for action in range(len(self.actionSpace))] for state in range(len(self.stateSpace))}
        self.Q_diff = {state: [0 for action in range(len(self.actionSpace))] for state in range(len(self.stateSpace))}

        ##################################################################################################################
        # ----------------------------------------------- initialization  ------------------------------------------------
        # variables keeping track of the current episode
        self.kGaGenerations = 0                                         ## to track the amount of times the GA processed an generations
        self.kEpIter = 0                                                ## to track the number of iterations within an episode
        self.kEpIterMax = epIterMax                                     ## maximum number of iterations until the episode is done
        self.kEp = 0                                                    ## to track the number of episodes
        self.kEpMax = epMax                                             ## the maximum amount of allowed episodes
        self.overallIter = 0
        # self.epsilonStep = (self.epsilon - 0.05) / self.kEpMax
        # self.alphaStep = (self.alpha - 0.05) / self.kEpMax
        
        ## recalculate avg numbe of actions to propose conversion
        self.nActionsAvg = self.nActions / self.nStates

        # a variable keeping track og hum many times the RL agent is iterared
        self.iterRL = 0
        self.iterGA = 0

        # create an array to keep count how often each action was taken
        self.actionCount = np.zeros(len(self.actionSpace))
        self.greedy = False
        self.choice = []

        # the previous population is set to an empty list
        self.generations = []

        # the previous fitness variable is initilized with a verh high cost
        self.prevFitness = float('inf')
        
        # the current fitness delta
        self.fitness = 0
        self.fitnessBest = 0
        self.fitnessAvg = 0

        # the current change index
        self.changeIndex = 1
        
        # the current reward awarded
        self.immediateReward_best = 0
        self.immediateReward_avg = 0
        self.immediateReward_diff = 0

        # the future reward awarded
        self.futureReward_best = 0
        self.futureReward_avg = 0
        self.futureReward_diff = 0

        # initialize the first state (0,0,0,0,0.1,0,0.1)
        self.currState = 0
        self.currAction = 0
        self.nextState = 0
        self.phase = 'diversify population'

        self.updateQ = 0

        self.running = True

        # the first stateAction are given
        ## self.stateAction refers to the index of the action in the stateAction space > NOT in the self.actionSpace
        # self.stateAction = self.stateActions[self.currState][0]   ## take the first stateAction from the list of eligible actions

        self.results = []

        # # initialie the json file
        # self.json = str(run) + '.json'
        # with open(self.json, 'w') as f:
        #     json.dump({}, f)

    def initializeRL(self, RLTuning):

        # print()
        # print('\tInitialize RL')
        # print()

        self.actionCount = np.zeros(len(self.actionSpace))

        if RLTuning:
            self.currAction = -1
            while self.currAction < 0:
                for initialAction in range(len(self.actionSpace)):
                    if initialAction in self.stateActions[self.currState]:
                        self.currAction = initialAction
        self.actionCount[self.currAction] += 1

        # print('\tInitial state:      {}'.format(self.stateSpace[self.currState]))
        # print('\tInitial action:     {}'.format(self.actionSpace[self.currAction]))

        self.nextState = self.__getNextState()

        # print('\tInitial next state: {}'.format(self.stateSpace[self.nextState]))
        # print()

        return [self.stateSpace[self.nextState][0], self.stateSpace[self.nextState][1], self.stateSpace[self.nextState][2], self.stateSpace[self.nextState][3]], self.stateSpace[self.nextState][4], self.stateSpace[self.nextState][5], self.stateSpace[self.nextState][6]

    def analyzeRL(self, generations, k, kMax):

        # print('\tAnalyze previous state + action')
        # print()

        self.fitnessBest, self.fitnessAvg = self.__getFitness(generations)
        self.changeIndex = self.__getChangeIndex(generations)

        self.immediateReward_best, self.immediateReward_avg, self.immediateReward_diff = self.__getReward(self.fitnessBest, self.fitnessAvg, self.changeIndex)
        self.futureReward_best = self.__getMax(1, self.nextState, self.Q_best)
        self.futureReward_avg = self.__getMax(1, self.nextState, self.Q_avg)
        self.futureReward_diff = self.__getMax(1, self.nextState, self.Q_diff)

        # print('\tQ(s, a):        {}'.format(self.stateSpace[self.currState]))
        # print('\tA:              {}'.format(self.actionSpace[self.currAction]))
        # print('\tR Q(s, a):      {}'.format(self.immediateReward))
        # print('\tQ(s+1, a+1):    {}'.format(self.stateSpace[self.nextState]))
        # print('\tyR Q(s+1, a+1): {}'.format(self.futureReward))
        # print()

        # print()

    def updateRL(self, gaK):

        # print('\tUpdate RL and Q-table')
        # print()

        oldQ_best = self.Q_best[self.currState][self.currAction]
        oldQ_avg = self.Q_avg[self.currState][self.currAction]
        oldQ_diff = self.Q_diff[self.currState][self.currAction]

        ## Bellman equation
        # print('\tCurrent Q(s, a): {}'.format(self.Q[self.currState, self.currAction]))
        self.updateQ_best = self.alpha * (self.immediateReward_best + self.gamma * self.futureReward_best - self.Q_best[self.currState][self.currAction])
        self.updateQ_avg = self.alpha * (self.immediateReward_avg + self.gamma * self.futureReward_avg - self.Q_avg[self.currState][self.currAction])
        self.updateQ_diff = self.alpha * (self.immediateReward_diff + self.gamma * self.futureReward_diff - self.Q_diff[self.currState][self.currAction])
        # print('\tUpdate Q:        {}'.format(self.updateQ))
        # print('\tUpdate value =   {} --- alpha {} * (R(s, a): {} + gamma {} * R(s+1, a+1): {} - Q(s, a): {})'.format((self.alpha * (self.immediateReward + self.gamma * self.futureReward - self.Q[self.currState, self.qAction])), self.alpha, self.immediateReward, self.gamma, self.futureReward, self.Q[self.currState, self.qAction]))
        self.Q_best[self.currState][self.currAction] += self.updateQ_best
        self.Q_avg[self.currState][self.currAction] += self.updateQ_avg
        self.Q_diff[self.currState][self.currAction] += self.updateQ_diff
        # print('\tNew Q(s, a):     {}'.format(self.Q[self.currState, self.currAction]))
        # print()

        self.__persistResults(oldQ_best, oldQ_avg, oldQ_diff, gaK)

        self.kEpIter += 1
        self.overallIter += 1
        if self.kEpIter == self.kEpIterMax:     ## number of iterations within an episode done
            self.kEp += 1
            self.kEpIter = 0

        if self.overallIter >= (self.nStates * self.nActionsAvg) / 2:
            self.conversionReached = True
            # self.alpha -= self.alphaStep
            # self.epsilon -= self.epsilonStep

    def iterateRL(self, k, kMax):

        # print('\tIterate RL and define next action giving new state')
        # print('\tEpisode [{}] - Next Iteration: {}'.format(self.kEp, self.kEpIter))
        # print()

        ## FIRST: STEP TO NEXT STATE
        self.currState = self.nextState

        ## SECOND: DECIDE ON WHICH PARAMETER WE WOULD LIKE TO TAKE THE ACTION
        phase = self.getPhase(k, kMax)
        self.phase = phase
        if phase == 'diversify population':
            q_table = self.Q_diff
        elif phase == 'average population':
            q_table = self.Q_avg
        else:
            q_table = self.Q_best

        ## SECOND: DECIDE THE NEXT STEP
        self.currAction = -1
        if np.random.random() < self.epsilon:
            while self.currAction < 0:
                candidateAction = int(np.random.randint(low=0, high=len(self.actionSpace)))
                if candidateAction in self.stateActions[self.currState]:
                    self.currAction = candidateAction
            # self.stateAction = int(np.random.randint(low=0, high=len(self.stateActions[self.currState])))
            self.greedy = False
        else:
            self.currAction = int(self.__getMax(0, self.currState, q_table))
            self.greedy = True
        
        self.actionCount[self.currAction] += 1

        ## THIRD: GET THE NEW NEXT STATE
        self.nextState = self.__getNextState()

        print('\tCurr state: {}'.format(self.stateSpace[self.currState]))
        print('\tAction:     {}'.format(self.actionSpace[self.currAction]))
        print('\tNew state:  {}'.format(self.stateSpace[self.nextState]))
        print()

        return [self.stateSpace[self.nextState][0], self.stateSpace[self.nextState][1], self.stateSpace[self.nextState][2], self.stateSpace[self.nextState][3]], self.stateSpace[self.nextState][4], self.stateSpace[self.nextState][5], self.stateSpace[self.nextState][6]

    def getPhase(self, k, kMax):

        if (k / kMax) <= (1/3) :
            phase = 'diversify population'
        elif (k / kMax) <= (2/3):
            phase = 'average population'
        else:
            phase = 'best individual'

        print('{} / {} = {}, phase = {}'.format(k, kMax, (k/kMax), phase))
        print()

        return phase

    def __persistResults(self, oldQ_best, oldQ_avg, oldQ_diff, gaK):
        
        action = self.actionSpace[self.currAction]
        fitnessBest = float(round(self.fitnessBest, 3))
        fitnessAvg = float(round(self.fitnessAvg, 3))
        changeIndex = float(round(self.changeIndex, 3))
        immReward_best = int(self.immediateReward_best)
        immReward_avg = int(self.immediateReward_avg)
        immReward_diff = int(self.immediateReward_diff)
        futReward_best = int(self.futureReward_best)
        futReward_avg = int(self.futureReward_avg)
        futReward_diff = int(self.futureReward_diff)
        newQ_best = self.Q_best[self.currState][self.currAction]
        newQ_avg = self.Q_best[self.currState][self.currAction]
        newQ_diff = self.Q_best[self.currState][self.currAction]
        result = [self.currState, self.currAction, self.greedy, self.nextState, oldQ_best, oldQ_avg, oldQ_diff, fitnessBest, fitnessAvg, changeIndex, self.alpha, immReward_best, immReward_avg, immReward_diff, self.gamma, futReward_best, futReward_avg, futReward_diff, newQ_best, newQ_avg, newQ_diff, gaK, self.stateSpace[self.currState], action, self.stateSpace[self.nextState], self.choice]
        
        self.results.append(result)

    def __getMax(self, reqParameter, state, q_table):
        ## reqParameter; 1 if value is required, 0 if index in row is required

        qValues = q_table[self.currState]
        stateActions = self.stateActions[state]
        if reqParameter == 0:
            self.choice = qValues


        bests = []
        best = float('inf')
        for qIdx in range(len(qValues)):
            if qIdx in stateActions:
                qVal = qValues[qIdx]
                if qVal < best:
                    bests = []
                    best = qVal
                    bests.append([qIdx, qVal])
                elif qVal == best:
                    bests.append([qIdx, qVal])

        arbitraryPick = np.random.choice(np.arange(len(bests)))

        return bests[arbitraryPick][reqParameter]

    def __getFitness(self, generations):
        
        if len(generations) > 1:
            currGeneration = generations[-1]
            bmGeneration = generations[-2]
            # fitnesses = [(generation, generation.bestGenerationResult) for generation in generations]
            # bestFitness = min(fitnesses, key = lambda t: t[1])[1]
            # delta = self.prevFitness - bestFitness
            # deltaFitness = delta / self.prevFitness

            # fitnesses = [(generation, generation.bestGenerationResult) for generation in generations]
            # bestFitness = min(fitnesses, key = lambda t: t[1])[1]
            deltaFitnessBest = (currGeneration.bestGenerationResult - bmGeneration.bestGenerationResult) / bmGeneration.bestGenerationResult
            deltaFitnessAvg = (currGeneration.avgResult - bmGeneration.avgResult) / bmGeneration.avgResult

            return deltaFitnessBest, deltaFitnessAvg
    
        else:
            return 0, 0

    def __getChangeIndex(self, generations):

        changeRatios = []
        generation = generations[-1]
        for chromosome in generation.population:
            if chromosome.parent1 != None:
                changeIndexMachine, changeIndexPallet = calculateChangeIndex(chromosome)
                changeRatio = (changeIndexMachine + changeIndexPallet) / 2
                changeRatios.append(changeRatio)
                # print('Change Ratios: {} - {} - {}'.format(changeRatioSeq, changeRatioMachine, changeRatioPallet))

        totalChangeIndex = sum(changeRatios) / len(changeRatios)

        # print('\tChange index:\t{}'.format(round(totalChangeIndex, 3)))

        return totalChangeIndex

    def __getReward(self, fitness_best, fitness_avg, changeIndex):

        if fitness_best < -0.03:
            reward_best = 50
        elif fitness_best < -0.005:
            reward_best = 25
        elif fitness_best < 0.02:
            reward_best = 0
        else:
            reward_best = -25

        # fitness_avg = fitness_avg * changeIndex

        if fitness_avg < -0.05:
            reward_avg = 50
        elif fitness_avg < -0.005:
            reward_avg = 25
        elif fitness_avg < 0.05:
            reward_avg = 0
        else:
            reward_avg = -25

        if changeIndex > (0.8):
            reward_diff = 50
        elif changeIndex > (0.725):
            reward_diff = 25
        elif changeIndex > (0.625):
            reward_diff = 0
        else:
            reward_diff = -25

        
        print()
        print('Reinforcement Learning Agent')
        print()
        print('best: {}, avg: {}, change: {}'.format(round(reward_best,3), round(reward_avg,3), round(reward_diff,3)))
        return reward_best, reward_avg, reward_diff

    def __getNextState(self):
        ## get current state list([x,x,x,...])
        ## output: index of new state list([x,x,x,...]) in self.stateSpace

        newState = self.stateSpace[self.currState].copy()
        actionTuple = [(idx, val) for idx, val in enumerate(self.actionSpace[self.currAction]) if val != 0][0]
        ## actionTuple = (index of change int, value with which it increments/decrements) ==> take only tuple where value != 0
        newState[actionTuple[0]] += actionTuple[1]

        nextState = self.__findState(newState)

        if type(nextState) != int:
            print('ERROR in getting new nextState. nextState: {}. Build on newState: {}'.format(nextState, newState))

        return nextState

    def __findState(self, newState):
        ## input:  newState = list([x, x, x,...]) that represents that actual values per state
        ## output: the index of that given state in the self.stateSpace environment

        if type(newState) != list:
            print('ERROR in __findState. newState: {}'.format(newState))

        for i in range(len(self.stateSpace)):
            if self.stateSpace[i] == newState:
                return i
        
        print('ERROR. No result in __findState. newState: {}'.format(newState))
        raise('Check Error')

    def exportResults(self, suffix):

        exportQTable = pd.DataFrame.from_dict(self.Q_best, orient='index')
        filenameDate = timeDouble.time()
        filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
        write = 'GRL_Qtable_Best' + suffix + '.xlsx'
        with pd.ExcelWriter(write) as writer:
            exportQTable.to_excel(writer, sheet_name = 'Q_Table', index = False)

        exportQTable = pd.DataFrame.from_dict(self.Q_avg, orient='index')
        filenameDate = timeDouble.time()
        filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
        write = 'GRL_Qtable_Avg' + suffix + '.xlsx'
        with pd.ExcelWriter(write) as writer:
            exportQTable.to_excel(writer, sheet_name = 'Q_Table', index = False)

        exportQTable = pd.DataFrame.from_dict(self.Q_diff, orient='index')
        filenameDate = timeDouble.time()
        filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
        write = 'GRL_Qtable_Diff' + suffix + '.xlsx'
        with pd.ExcelWriter(write) as writer:
            exportQTable.to_excel(writer, sheet_name = 'Q_Table', index = False)
            
        dfExportRL = pd.DataFrame(self.results, columns=['stateIdx', 'actionIdx', 'greedy', 'nextIdx', 'oldQ_best', 'oldQ_avg', 'oldQ_diff', 'fitnessBest', 'fitnessAvg', 'changeIndex', 'alpha', 'immReward_best', 'immReward_avg', 'immReward_diff', 'gamma', 'futReward_best', 'futReward_avg', 'futReward_diff', 'newQ_best', 'newQ_avg', 'newQ_diff', 'gaK', 'state', 'action', 'next', 'q choices'])
        filenameDate = timeDouble.time()
        filenameDateAct = timeDouble.strftime('%Y%m%d%H%M', timeDouble.localtime(filenameDate))
        write = 'RL_Process_' + suffix + '.xlsx'
        with pd.ExcelWriter(write) as writer:
            dfExportRL.to_excel(writer, sheet_name = 'Progress', index = False)

    def loadQTable(self, QTable):

        bestState = None
        bestAction = None
        maxStateAction = 0
        for state in QTable.keys():
            actions = QTable[state]
            for actionIndex in range(len(actions)):
                actionVal = actions[actionIndex]
                if actionVal > maxStateAction:
                    maxStateAction = actionVal
                    bestState = state
                    bestAction = actionIndex

        # REMOVE 27-10
        # bestState = None
        # bestAction = None
        # maxStateAction = 0
        # for stateIndex in range(len(QTable)):
        #     state = QTable[stateIndex]
        #     for actionIndex in range(len(state)):
        #         actionVal = state[actionIndex]
        #         if actionVal > maxStateAction:
        #             maxStateAction = actionVal
        #             bestState = stateIndex
        #             bestAction = actionIndex
        # startStateAction = 0
        # for stateSpaceIndex in range(bestAction):
        #     if stateSpaceIndex == bestAction:
        #         break
        #     if stateSpaceIndex in self.stateActions[bestState]:
        #         startStateAction += 1

        return bestState, bestAction


if __name__ == '__main__':
    alpha = 0.7
    gamma = 0.1
    epsilon = 0.3
    print('checked')
