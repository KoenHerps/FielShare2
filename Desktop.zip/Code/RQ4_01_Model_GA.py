import datetime as dt
# from email.policy import EmailPolicy
# from json import tool
# from mimetypes import suffix_map
# from msilib import sequence
# from operator import index
# from pickle import NONE
# from platform import machine
# import time as timeDouble
# from os import cpu_count, error, removedirs
# from re import match
# from tkinter.ttk import Progressbar
# from typing import Match
# from xml.dom.minidom import parseString
# from matplotlib.style import available
# import matplotlib.pyplot as plt
# from numpy.core.fromnumeric import take
# from numpy.core.numeric import False_
# import statistics
# import pandas as pd
# from pytz import NonExistentTimeError
# import simpy
# import numpy as np
# import plotly.express as px
import random
import math
# import csv
# import threading
# import sys
# from simpy import AllOf, Event
# from itertools import count, cycle
# from simpy.events import AnyOf
import json

## import functions to do stand-alone validation

from RQ4_06_Functions import CalculateSupervisedTimes, TRM, determineChangeovers, determineCutpoints
from RQ4_05_DataInput import GetProductData, GenerateJobs, GeneratePalletNc, getEmpiricalData, ClusterInitialData, GetInitialVectors
from RQ4_02_Model_PH import PhBuildSequences

class Generation():

    def __init__(self, currExperiment):
        currExperiment.currentK += 1
        self.k = currExperiment.currentK
        self.kId = 0
        self.experiment = currExperiment
        self.fromElitism = []
        self.fromTournament = []
        self.matingPool = []
        self.population = []
        self.bestGenerationResult = 9999999
        self.bestChromosome = None

        self.allResults = []
        self.avgResult = 9999999

        currExperiment.generations.append(self)

class Chromosome():

    id = 0
    allChromosomes = []
    allScores = []
    
    def __init__(self, currExperiment, generation, sequenceVector, machineVector, palletVector, cMethod, mMethod, p1, p2, fromCrossover):
        Chromosome.id += 1
        self.id = Chromosome.id
        self.sequenceVector = sequenceVector
        self.machineVector = machineVector
        self.palletVector = palletVector
        if type(p1) != str:
            self.parent1 = p1.id
            self.parent2 = p2.id
        else:
            self.parent1 = None
            self.parent2 = None
        self.parents = [p1, p2]
        jobVector = [[job, seq] for job, seq in zip(range(len(sequenceVector)), sequenceVector)]
        jobVector.sort(key=lambda job: job[1], reverse=False)
        jobVector = [job[0] for job in jobVector]
        self.changeoversMachine = determineChangeovers(machineVector, sequenceVector)
        self.changeoversPallet = determineChangeovers(palletVector, sequenceVector)
        self.cMethod = cMethod
        self.mMethod = mMethod
        self.obsolete = False
        self.generation = generation
        self.generation.kId += 1
        self.kId = self.generation.kId
        self.fitnessValue = None
        self.leadCost = None
        self.toolCost = None
        self.palletCost = None
        self.fromCrossover = fromCrossover
        Chromosome.allChromosomes.append(self)
        currExperiment.chromosomes.append(self)

def GaRandomChromosome(jobList, xrefJobPrecedence, currExperiment, cncCapacity, palletCapacity, currentGeneration, directInPopulation, tobeGenerated, fromCrossover):
    for x in range(tobeGenerated):
        sequenceVector, machineVector, palletVector = GetInitialVectors(jobList, cncCapacity, palletCapacity)
        repairedChromosome = GaSafeguard(jobList, xrefJobPrecedence, [sequenceVector, machineVector, palletVector])
        sequenceVector = repairedChromosome[0]
        machineVector = repairedChromosome[1] 
        palletVector = repairedChromosome[2]     
        newChromosome = Chromosome(currExperiment, currentGeneration, sequenceVector, machineVector, palletVector, 'Random', 'Random', '-', '-', fromCrossover)
        if directInPopulation:
            currentGeneration.population.append(newChromosome)
        else:
            currentGeneration.matingPool.append(newChromosome)

def GaSelectParents(currentGeneration, method, tournamementSizeReq):
    parents = []
    while len(parents) < 2:
        if method == 'Tournament Selection':
            tournamentSize = 0
            tournamentChromosomes = []
            counter = 0
            if len(currentGeneration.matingPool) > tournamementSizeReq:
                while tournamentSize < (tournamementSizeReq):
                    counter += 1
                    indexParent = random.randint(0, (len(currentGeneration.matingPool) - 1))
                    selectedContestant = currentGeneration.matingPool[indexParent]
                    if (selectedContestant not in tournamentChromosomes) and (selectedContestant not in parents):
                        tournamentSize += 1
                        if selectedContestant.fitnessValue == None:
                            try:
                                selectedContestant.fitnessValue = random.randint(min([x.fitnessValue for x in currentGeneration.matingPool])-1, max([x.fitnessValue for x in currentGeneration.matingPool])+1)  ## how to determine the correct fitness value for immigrants????
                            except:
                                selectedContestant.fitnessValue = random.randint(0, 500000)
                        tournamentChromosomes.append(selectedContestant)
                        # print('[PARENTS SELECTION 02] - [TOURNAMENT 02] we select contestant {} with a fitness value of {}'.format(selectedContestant, selectedContestant.fitnessValue))
                        # print('[PARENTS SELECTION 02] - [TOURNAMENT 03] our mating pool consists of {} parents. Our tournament of {} contestants'.format(len(currentGeneration.matingPool), len(tournamentChromosomes)))
                    # else:
                        # print('[PARENTS SELECTION 02] - [TOURNAMENT 04] Selected chromosome {} in tournament {} or in parents {}'.format(selectedContestant, (selectedContestant in tournamentChromosomes), (selectedContestant in parents)))
                    if counter > 1000:
                        raise('Too many iterations to get the sufficient amount of contestants')
                # tournamentChromosomes.sort(key=lambda x: x.fitnessValue, reverse=False)
                currentRound = tournamentChromosomes
                currentGame = []
                nextRound = []
                winner = None
                # print('[PARENTS SELECTION 02] - [TOURNAMENT 05] Start the tournament, let the best contestant win')
                while (winner == None):
                    # print('[PARENTS SELECTION 02] - [TOURNAMENT 06] Start round')
                    while len(currentRound) != 0:
                        # print('[PARENTS SELECTION 02] - [TOURNAMENT 07] Start game')
                        if len(currentRound) == 1:
                            winner = currentRound.pop(0)
                            # print('[PARENTS SELECTION 02] - [TOURNAMENT 08] Contestant {} won the tournament with a fitness value of {}.'.format(winner, winner.fitnessValue))
                            break
                        else:
                            while len(currentGame) < 2:
                                selectRandomIndex = random.randint(0, len(currentRound) - 1)
                                selectedContestant = currentRound.pop(selectRandomIndex)
                                currentGame.append(selectedContestant)
                            # print('[PARENTS SELECTION 02] - [TOURNAMENT 09] Let\'s fight! Contestants are {}'.format(currentGame))
                            currentGame.sort(key=lambda x: x.fitnessValue, reverse=False)
                            toNextRound = currentGame.pop(0)
                            nextRound.append(toNextRound)
                            currentGame = []
                            # print('[PARENTS SELECTION 02] - [TOURNAMENT 10] Contestant {} won the game'.format(selectedContestant))
                    currentRound = nextRound
                parents.append(winner)
            else:
                method = 'Random'
        elif method == 'Random':
            selectParent = None
            while selectParent == None:
                selectRandomIndex = random.randint(0, len(currentGeneration.matingPool) - 1)
                selectParent = currentGeneration.matingPool[selectRandomIndex]
                if selectParent in parents:
                    selectParent = None
            parents.append(selectParent)
        else:
            raise ('parent selection method not incorporated')

    return parents

def GaUX(curGen, curExp, parents, cMethod, cProb, fromCrossover, createChromosome):

    p1 = parents[0]
    p2 = parents[1]
    nJobs = len(p1.sequenceVector)
    
    if createChromosome:
        child1 = Chromosome(curExp, curGen, p1.sequenceVector.copy(), p1.machineVector.copy(), p1.palletVector.copy(), cMethod, '-', p1, p2, fromCrossover)
        child2 = Chromosome(curExp, curGen, p2.sequenceVector.copy(), p2.machineVector.copy(), p2.palletVector.copy(), cMethod, '-', p1, p2, fromCrossover)
    else:
        child1 = p1
        child1.orgMachineVector = child1.machineVector
        child1.orgPalletVector = child1.palletVector
        child2 = p2
        child2.orgMachineVector = child2.machineVector
        child2.orgPalletVector = child2.palletVector

    crosses = 0
    crossGenes = []
    selectedGenes = []
    for gene in range(nJobs):
        probUX = random.uniform(0, 1)
        if probUX < cProb:
            selectedGenes.append(gene)
            crosses += 1
            if cMethod == 'UX':
                c1Sequence = child1.sequenceVector[gene]
                c2Sequence = child2.sequenceVector[gene]
                for index in child1.sequenceVector:
                    if (gene != index) and (child1.sequenceVector[index] == c2Sequence):
                        child1.sequenceVector[index] = c1Sequence
                for index in child2.sequenceVector:
                    if (gene != index) and (child2.sequenceVector[index] == c1Sequence):
                        child2.sequenceVector[index] = c2Sequence
                child1.sequenceVector[gene] = c2Sequence
                child2.sequenceVector[gene] = c1Sequence
                if c1Sequence != c2Sequence:
                    crossGenes.append((gene, c1Sequence, c2Sequence))
            c1Machine = child1.machineVector[gene]
            c2Machine = child2.machineVector[gene]
            child1.machineVector[gene] = c2Machine
            child2.machineVector[gene] = c1Machine
            c1Pallet = child1.palletVector[gene]
            c2Pallet = child2.palletVector[gene]
            child1.palletVector[gene] = c2Pallet
            child2.palletVector[gene] = c1Pallet

    # if cMethod == 'UX':
    #     if (child1.sequenceVector == p1.sequenceVector) and (child2.sequenceVector == p2.sequenceVector) and (len(crossGenes) != 0) and (len(selectedGenes) != 0):
    #         print()
    #         print('Total crosses: {}'.format(crosses))
    #         print('Overall Crosses: {}'.format(crossGenes))
    #         print('Total selected genes: {}'.format(selectedGenes))
    #         print()
    #         print('Child 1:  {}'.format(child1.sequenceVector))
    #         print('Parent 1: {}'.format(p1.sequenceVector))
    #         print('Child 2:  {}'.format(child2.sequenceVector))
    #         print('Parent 2: {}'.format(p2.sequenceVector))
    #         print()
    #         raise('no changes made in sequenceVector!')

    offspring = [child1, child2]

    return offspring

def GaOX(curGen, curExp, parents, cMethod, cProb, fromCrossover, createChromosome):

    p1 = parents[0]
    p2 = parents[1]
    nJobs = len(p1.sequenceVector)

    v1Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(len(p1.sequenceVector)), p1.sequenceVector, p1.machineVector, p1.palletVector)}
    v2Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(len(p2.sequenceVector)), p2.sequenceVector, p2.machineVector, p2.palletVector)}

    cutPoints = determineCutpoints(cProb, nJobs)

    ## 1. construct Job+Seq genes
    ## 2. sort according to sequence
    ## 3. construct job vector
    v1Gene = [[job, sequence] for job, sequence in zip(range(len(p1.sequenceVector)), p1.sequenceVector)]
    v1Gene.sort(key=lambda seq: seq[1], reverse=False)
    v1JobVector = [x[0] for x in v1Gene]
    v2Gene = [[job, sequence] for job, sequence in zip(range(len(p2.sequenceVector)), p2.sequenceVector)]
    v2Gene.sort(key=lambda seq: seq[1], reverse=False)
    v2JobVector = [x[0] for x in v2Gene]

    ## 7. identify segments
    c1p2OX1, c1p2OX2 = [], []
    c1p2OXS = v2JobVector[cutPoints[0]:cutPoints[1]]
    c2p1OX1, c2p1OX2 = [], []
    c2p1OXS = v1JobVector[cutPoints[0]:cutPoints[1]]
   
    ## 8. apply crossover and track new vector
    offspring = []
    for recOX1, recOXS, recOX2, donorVec, vMapping, par in zip([c1p2OX1, c2p1OX1], [c1p2OXS, c2p1OXS], [c1p2OX2, c2p1OX2], [v1JobVector, v2JobVector], [v1Mapping, v2Mapping], [p1, p2]):
        requiredLength = len(donorVec)
        donorVec = [gene for gene in donorVec if gene not in recOXS]
        while len(recOX1) < cutPoints[0]:
            for donorGeneIndex in range(len(donorVec)):
                newGene = donorVec.pop(donorGeneIndex)
                recOX1.append(newGene)
                break
        donorVec = [gene for gene in donorVec if gene not in [recOX1 + recOXS]]
        while len(recOX1 + recOXS + recOX2) != requiredLength:
            for donorGeneIndex in range(len(donorVec)):
                newGene = donorVec.pop(donorGeneIndex)
                recOX2.append(newGene)
                break
        ## remap to sequence values
        jobVector = recOX1 + recOXS + recOX2
        seqVector = [x for x in range(requiredLength)]
        # if (cMethod == 'OX-C') or (cMethod == 'PMX-C'):
        macVector = [vMapping[job]['m'] for job in jobVector]
        palVector = [vMapping[job]['p'] for job in jobVector]
        # else:
        #     vVector = [(gene['s'], gene['m'], gene['p']) for k, gene in vMapping.items()]
        #     vVector.sort(key=lambda gene: gene[0], reverse=False)
        #     macVector = [x[1] for x in vVector]
        #     palVector = [x[2] for x in vVector]
    
        childJob = [(job, sequence, machine, pallet) for job, sequence, machine, pallet in zip(jobVector, seqVector, macVector, palVector)]
        childJob.sort(key=lambda gene: gene[0], reverse=False)
        
        if createChromosome:
            child = Chromosome(curExp, curGen, [x[1] for x in childJob], [x[2] for x in childJob], [x[3] for x in childJob], cMethod, '-', p1, p2, fromCrossover)
        else:
            child = par
            child.sequenceVector = [x[1] for x in childJob]
            child.machineVector = [x[2] for x in childJob]
            child.palletVector = [x[3] for x in childJob]
        
        offspring.append(child)
    
    return offspring

def GaPMX(curGen, curExp, parents, cMethod, cProb, fromCrossover, createChromosome):

    p1 = parents[0]
    p2 = parents[1]
    nJobs = len(p1.sequenceVector)

    v1Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(nJobs), p1.sequenceVector, p1.machineVector, p1.palletVector)}
    v2Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(nJobs), p2.sequenceVector, p2.machineVector, p2.palletVector)}

    cutPoints = determineCutpoints(cProb, nJobs)

    ## 1. construct Job+Seq genes
    ## 2. sort according to sequence
    ## 3. construct job vector
    v1Gene = [[job, sequence] for job, sequence in zip(range(nJobs), p1.sequenceVector)]
    v1Gene.sort(key=lambda seq: seq[1], reverse=False)
    v1JobVector = [x[0] for x in v1Gene]
    v2Gene = [[job, sequence] for job, sequence in zip(range(nJobs), p2.sequenceVector)]
    v2Gene.sort(key=lambda seq: seq[1], reverse=False)
    v2JobVector = [x[0] for x in v2Gene]

    ## 7. identify segments
    c1PMXS = v2JobVector[cutPoints[0]:cutPoints[1]]
    c2PMXS = v1JobVector[cutPoints[0]:cutPoints[1]]

    ## 8. apply crossover and track new vector
    offspring = []
    for recPMX, donorPMXS, discPMXS, vMapping, par in zip([v1JobVector, v2JobVector], [c1PMXS, c2PMXS], [c2PMXS, c1PMXS], [v1Mapping, v2Mapping], [p1, p2]):
        posPMXS = 0
        for donorGene, discGene in zip(donorPMXS, discPMXS):
            ## if the received gene is not in the to-be-replaced recipient vector, find its index in remaining recipient vector
            if donorGene in list(set(recPMX) - set(discPMXS)): ## if the received gene is not in the to be changed sequence, find where it is
                posRecGene = recPMX.index(donorGene)
                recPMX[posRecGene] = discGene
            recPMX[cutPoints[0] + posPMXS] = donorGene
            posPMXS += 1

        ## remap to sequence values
        jobVector = recPMX
        seqVector = [x for x in range(len(jobVector))]
        # if (cMethod == 'OX-C') or (cMethod == 'PMX-C'):
        macVector = [vMapping[job]['m'] for job in jobVector]
        palVector = [vMapping[job]['p'] for job in jobVector]
        # else:
        #     vVector = [(gene['s'], gene['m'], gene['p']) for k, gene in vMapping.items()]
        #     vVector.sort(key=lambda gene: gene[0], reverse=False)
        #     macVector = [x[1] for x in vVector]
        #     palVector = [x[2] for x in vVector]

        childJob = [(job, sequence, machine, pallet) for job, sequence, machine, pallet in zip(jobVector, seqVector, macVector, palVector)]
        childJob.sort(key=lambda gene: gene[0], reverse=False)
       
        if createChromosome:
            child = Chromosome(curExp, curGen, [x[1] for x in childJob], [x[2] for x in childJob], [x[3] for x in childJob], cMethod, '-', p1, p2, fromCrossover)
        else:
            child = par
            child.sequenceVector = [x[1] for x in childJob]
            child.machineVector = [x[2] for x in childJob]
            child.palletVector = [x[3] for x in childJob]
        
        offspring.append(child)
    
    return offspring

def GaMSwap(offspring, mMethod, mProb):

    mutateOffspring = []
    for child in offspring:
        nJobs = len(child.sequenceVector)
        for gene in child.sequenceVector:
            probSwap = random.uniform(0, 1)
            if probSwap < (mProb / 2):
                otherGene = gene
                while (otherGene == gene):
                    otherGene = random.randint(0, nJobs-1)
                seq, mach, pal = child.sequenceVector.copy(), child.machineVector.copy(), child.palletVector.copy()
                seqG1, machG1, palG1 = seq[gene], mach[gene], pal[gene]
                seqG2, machG2, palG2 = seq[otherGene], mach[otherGene], pal[otherGene]
                seq[gene], seq[otherGene] = seqG2, seqG1
                mach[gene], mach[otherGene] = machG2, machG1
                pal[gene], pal[otherGene] = palG2, palG1
                child.sequenceVector, child.machineVector, child.palletVector = seq, mach, pal
        child.mMethod = mMethod
        mutateOffspring.append(child)
    
    return mutateOffspring

def GaMInv(offspring, mMethod, mProb):
        
    mutateOffspring = []

    for child in offspring:
        nJobs = len(child.sequenceVector)
        cutPoints = determineCutpoints(mProb, nJobs)

        chromosomeVector = [[job, seq, mach, pal] for job, seq, mach, pal in zip(range(len(child.sequenceVector)), child.sequenceVector.copy(), child.machineVector.copy(), child.palletVector.copy())]
        chromosomeVector.sort(key=lambda gene: gene[1], reverse=False)
        mutateVector = chromosomeVector[cutPoints[0]: cutPoints[1]]
        mutateVector.sort(key=lambda gene: gene[1], reverse=True)
        for gene, lotus in zip(mutateVector, range(cutPoints[0], cutPoints[1])):
            chromosomeVector[lotus] = gene
        for gene, newSeq in zip(chromosomeVector, range(len(child.sequenceVector))):
            gene[1] = newSeq
        chromosomeVector.sort(key=lambda gene: gene[0])

        child.sequenceVector = [vector[1] for vector in chromosomeVector]
        child.machineVector = [vector[2] for vector in chromosomeVector]
        child.palletVector = [vector[3] for vector in chromosomeVector]
        child.mMethod = mMethod

        mutateOffspring.append(child)
        
    return mutateOffspring

def GaMIns(offspring, mMethod, mProb):
    
    mutateOffspring = []

    for child in offspring:
        mKPo = []
        while len(mKPo) < 2:
            kPo = random.randint(0, len(child.sequenceVector)-1)
            if kPo not in mKPo:
                mKPo.append(kPo)
        
        chromosomeVector = [[job, sequence, machine, pallet] for job, sequence, machine, pallet in zip(range(len(child.sequenceVector)), child.sequenceVector.copy(), child.machineVector.copy(), child.palletVector.copy())]
        chromosomeVector.sort(key=lambda gene: gene[1], reverse=False)
        mutateVector = [[x[0], x[1], x[2], x[3]] for x in chromosomeVector]
        mutateVector.insert(mKPo[0]+1, mutateVector.pop(mKPo[1]))

        for gene, newSeq in zip(mutateVector, range(len(child.sequenceVector))):
            gene[1] = newSeq
        mutateVector.sort(key=lambda gene: gene[0])
        
        child.sequenceVector = [vector[1] for vector in mutateVector]
        child.machineVector = [vector[2] for vector in mutateVector]
        child.palletVector = [vector[3] for vector in mutateVector]
        child.mMethod = mMethod

        mutateOffspring.append(child)

    return mutateOffspring

def GaSelectMatingPool(currentGeneration, previousGeneration, currExperiment, elitismRate, tournamentRate, defTournamentSize, populationSize):
    previousPopulation = [x for x in previousGeneration.population]
    previousPopulation.sort(key=lambda x: x.fitnessValue, reverse=False)    ## reverse False means smallest first
    while len(currentGeneration.matingPool) < int(math.ceil(elitismRate * populationSize)):
        while True:
            ## if the mating pool is empty, take the top chromosome
            if len(currentGeneration.matingPool) == 0:
                selectNewParent = currExperiment.topChromosomes[0]
            ## if the mating pool is already filled, take a random chromosome from the rest
            else:
                indexParent = random.randint(0, (len(currExperiment.topChromosomes) - 1))
                selectNewParent = currExperiment.topChromosomes[indexParent]
            if selectNewParent not in currentGeneration.matingPool:
                if selectNewParent in previousPopulation:
                    previousPopulation.remove(selectNewParent)
                break
        currentGeneration.matingPool.append(selectNewParent)
        currentGeneration.fromElitism.append(selectNewParent)
    parentsRequired = int(math.ceil(populationSize - (elitismRate * populationSize)))
    reqTournamentContestants = int(math.ceil(parentsRequired * tournamentRate))
    while (len(currentGeneration.fromTournament)) < (reqTournamentContestants):
        actTournamentSize = 0
        tournamentChromosomes = []
        selectedContestants = []
        reqTournamentSize = defTournamentSize
        while len(previousPopulation) < reqTournamentSize:
            reqTournamentSize /= 2
        counter = 0
        if len(previousPopulation) >= reqTournamentSize:
            while actTournamentSize < (reqTournamentSize):
                counter += 1
                indexParent = random.randint(0, (len(previousPopulation) - 1))
                selectedContestant = previousPopulation[indexParent]
                if (selectedContestant not in tournamentChromosomes) and (selectedContestant not in currentGeneration.matingPool):
                    actTournamentSize += 1
                    tournamentChromosomes.append(selectedContestant)
                if counter > (populationSize * 5):
                    raise('Too many iterations to get the sufficient amount of contestants')
            currentRound = tournamentChromosomes
            currentGame = []
            nextRound = []
            winner = None
            while (winner == None):
                while len(currentRound) != 0:
                    if len(currentRound) == 1:
                        winner = currentRound.pop(0)
                        selectedContestants.append(winner)
                        break
                    else:
                        while len(currentGame) < 2:
                            selectRandomIndex = random.randint(0, len(currentRound) - 1)
                            selectedContestant = currentRound.pop(selectRandomIndex)
                            currentGame.append(selectedContestant)
                        currentGame.sort(key=lambda x: x.fitnessValue, reverse=False)
                        toNextRound = currentGame.pop(0)
                        nextRound.append(toNextRound)
                        currentGame = []
                currentRound = nextRound
            currentGeneration.matingPool.append(winner)
            currentGeneration.fromTournament.append(winner)
            previousPopulation.remove(winner)
        else:
            raise ('population not large enough for tournament')

def GaSafeguard(operationList, precedingConstraints, geneRepresentation):
    sequenceVector = geneRepresentation[0]
    machineVector = geneRepresentation[1]
    palletVector = geneRepresentation[2]

    printSeq = sequenceVector

    orgSequenceVector = sequenceVector
    orgJoblist = operationList
    orgPrintJobListSeq = [(job, seq) for job, seq in zip(operationList, orgSequenceVector)]
    orgPrintJobListSeq.sort(key=lambda job: job[1], reverse=False)

    check = False
    totalIterations = 0
    ## start repairing to satisfy the precedence constraints
    while check == False:
        totalIterations += 1
        countChanges = 0
        for x in range(len(operationList)):
            operation = operationList[x]                            # get the current operation from the operationList
            SequenceNr = sequenceVector[x]                          # get the current sequence value for that operation
            machineNr = machineVector[x]
            palletNr = palletVector[x]
            precedingOperation = precedingConstraints[operation]    # get the preceding operation
            if precedingOperation != None:                          # no preceding operation found > no constraints
                precedingOperationIndex = operationList.index(precedingOperation)       # if found, get the preceding operations ID
                precedingSequenceNr = sequenceVector[precedingOperationIndex]
                if (SequenceNr < precedingSequenceNr):
                    # print('Job -1 ({}): {}\t -- \tJob 0 ({}): {}'.format(precedingOperation, precedingSequenceNr, operation, SequenceNr))
                    countChanges += 1
                    indexOper1 = sequenceVector.index(SequenceNr)
                    indexOper2 = sequenceVector.index(precedingSequenceNr)
                    sequenceVector.pop(indexOper1)
                    sequenceVector.insert(indexOper1, precedingSequenceNr)
                    sequenceVector.pop(indexOper2)
                    sequenceVector.insert(indexOper2, SequenceNr)
        if countChanges == 0:
            check = True
        if totalIterations == len(sequenceVector):
            print('JobList: {}'.format(orgPrintJobListSeq))
            print('precedingConstraints: {}'.format(precedingConstraints))
            for x in range(len(operationList)):
                operation = operationList[x]                            # get the current operation from the operationList
                SequenceNr = sequenceVector[x]                          # get the current sequence value for that operation
                machineNr = machineVector[x]
                palletNr = palletVector[x]
                precedingOperation = precedingConstraints[operation]    # get the preceding operation
                if precedingOperation != None:                          # no preceding operation found > no constraints
                    precedingOperationIndex = operationList.index(precedingOperation)       # if found, get the preceding operations ID
                    precedingSequenceNr = sequenceVector[precedingOperationIndex]
                    if precedingSequenceNr > SequenceNr:
                        print('Job -1 ({}): {}\t -- \tJob 0 ({}): {}'.format(precedingOperation, precedingSequenceNr, operation, SequenceNr))
            
            printSeq.sort()
            print('Sorted sequences [{}]: {}'.format(len(printSeq), printSeq))

            raise('ERROR: safeguard does not work')
           
    geneRepresentation = [sequenceVector, machineVector, palletVector]

    return geneRepresentation

def GaCalcFitness(initialData, chromosomeID, geneRepresentation, returnDict, inputParameters, runFrom):
    # initialData = [jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, cncCapacity, operNcXref, actToolStorage]

    sequenceVector = geneRepresentation[0]
    machineVector = geneRepresentation[1]
    palletVector = geneRepresentation[2]

    jobList = initialData[0]
    ncDatabase = initialData[1]
    xrefJobPrecedence = initialData[3]
    xrefJobNc = initialData[4]
    toolStorageAct = initialData[6]

    # print('Joblist: {}'.format(jobList))
    # print('xrefJobNc: {}'.format(xrefJobNc))
    # print('NC Database: {}'.format(ncDatabase))
    # print('Job - NC x-ref: {}'.format(xrefJobPrecedence))

    cncCapacity = inputParameters['cncCapacity']
    cncDepreciationCost = inputParameters['cncDepreciationCost']
    palletSetupCost = inputParameters['palletSetupCost']
    palletSetupTime = inputParameters['palletSetupTime']
    toolSwitchCost = inputParameters['toolSwitchCost']

    palletCapacity = inputParameters['palletCapacity']
    toolCapacity = inputParameters['toolCapacity']
    supervisedShift = inputParameters['supervisedShift']

    startSim = dt.datetime.now()

    xrefJobUID = {}
    xrefUIDJob = {}
    uidJob = 0

    toolStorageStartSim = {}
    
    jobDatabase = {}
    jobListOpen = []            ## all jobs that need to be manufactured
    jobListPallet = {palletIndex: {'queue': [], 'pending': None, 'ready': None, 'complete': []} for palletIndex in range(palletCapacity)}
    jobListMachine = {machineIndex: {'queue': [], 'active': [], 'done': []} for machineIndex in range(cncCapacity)}

    ## initiate tool storage at the beginning of the simulation

    for machineId in toolStorageAct.keys():
        toolStorageStartSim[int(machineId)] = [x for x in toolStorageAct[machineId].keys()]

    ## initiate time variables

    finishedAt = 0

    ## generate jobDatabase
    for jobIndex in range(len(jobList)):
        jobID = jobList[jobIndex]
        xrefJobUID[jobID] = uidJob
        xrefUIDJob[uidJob] = jobID
        nc = xrefJobNc[jobID]
        cycleTime = ncDatabase[nc]['cycle']
        sequenceGene = sequenceVector[jobIndex]
        machineGene = machineVector[jobIndex]
        palletGene = palletVector[jobIndex]
        nextEvent = None
        precedingJob = None
        if (xrefJobPrecedence[jobID] == None):
            nextEvent = 0
        else:
            precedingJob = xrefJobPrecedence[jobID]
        succeedingJob = None
        succeedingJobList = [k for k, v in xrefJobPrecedence.items() if v == jobID]
        if len(succeedingJobList) > 0:
            succeedingJob = succeedingJobList[0]
        jobDatabase[uidJob] = {'jobID': jobID, 'nc': nc, 'cycle': cycleTime, 'sequence': sequenceGene, 'machine': machineGene, 'pallet': palletGene, 'nextEvent': nextEvent, 'ls': 0, 'le': 0, 's': 0, 'e': 0, 'u': 0, 'done': False, 'reconfigure': False, 'toolStorage': [], 'toolSwitches': [], 'precedingJob': precedingJob, 'succeedingJob': succeedingJob}
        jobListOpen.append((uidJob, sequenceGene))
        jobListPallet[palletGene]['queue'].append(uidJob)
        jobListMachine[machineGene]['queue'].append(uidJob)
        uidJob += 1
   
    jobListOpen.sort(key=lambda x: x[1], reverse=False)
    jobListOpen = [x[0] for x in jobListOpen]

    p = 0
    while p < (palletCapacity):
        jobListPallet[p]['queue'].sort(key=lambda job: jobDatabase[job]['sequence'], reverse=False)
        p += 1

    for m in range(cncCapacity):
        jobListMachine[m]['queue'].sort(key=lambda job: jobDatabase[job]['sequence'], reverse=False)

    iteration = 1

    loadCounter = 0
    millCounter = 0
    doneCounter = 0

    taskManager = {'machines': [], 'pallets': [], 'tasks': []}
    taskDatabase = []

    invalidRun = False

    while len(jobListOpen) != 0:

        ##  [1] Get all tasks that are required per pallet

        # print()
        # print('--------------------------------- Iteration {} ---------------------------------'.format(iteration))

        for pallet in [p for p in jobListPallet if p not in taskManager['pallets']]:
            # get all pallets that need to be unloaded
            if (jobListPallet[pallet]['ready'] is not None):                                        ## if the pallet is currently active
                uidJobFinish = jobListPallet[pallet]['ready']                                       ## get the job that needs to be unloaded
                taskManager['tasks'].append((uidJobFinish, jobDatabase[uidJobFinish]['nextEvent'], 'DONE'))
                taskManager['pallets'].append(pallet)
            # get all pallets that need to be loaded
            elif (jobListPallet[pallet]['queue']) and (jobListPallet[pallet]['pending'] is None):
                uidJobLoad = jobListPallet[pallet]['queue'][0]                                      ## get first job that needs to be loaded
                if (jobDatabase[uidJobLoad]['nextEvent'] is not None):
                    taskManager['tasks'].append((uidJobLoad, jobDatabase[uidJobLoad]['nextEvent'], 'LOAD'))
                    taskManager['pallets'].append(pallet)

        ##  [2] Get all tasks that are required per machine 

        for machine in [m for m in jobListMachine if m not in taskManager['machines']]:
            if (jobListMachine[machine]['active']):                                                 ## if there exists a queue and the pallet is free
                uidJobMill = jobListMachine[machine]['active'][0]
                taskManager['tasks'].append((uidJobMill, jobDatabase[uidJobMill]['nextEvent'], 'MILL'))     ## append to the jobListLoad queue
                taskManager['machines'].append(machine)

        printTaskList = [(jobList[task[0]], task[1], task[2]) for task in taskManager['tasks']]
        # print('Current task list: {}'.format(printTaskList))
        for machine in [m for m in jobListMachine if m in taskManager['machines']]:
            jobListMachine[machine]['active'].sort(key=lambda job: jobDatabase[job]['sequence'])
            priorityJob = jobListMachine[machine]['active'][0]
            # print('Prio Job: {}'.format(jobList[priorityJob]))
            millTasks = [task for task in taskManager['tasks'] if (jobDatabase[task[0]]['machine'] == machine) if (task[2] == 'MILL')]
            for task in millTasks:
                if task[0] != priorityJob:
                    # print('Current Task [{}] != Piority Job [{}]'.format(task[0], priorityJob))
                    taskManager['tasks'][taskManager['tasks'].index(task)] = (priorityJob, jobDatabase[priorityJob]['nextEvent'], 'MILL')

        ##  [3] sort outstanding tasks and sort on sequence available moment

        taskManager['tasks'].sort(key=lambda task: task[1], reverse=False)

        if len(taskManager['tasks']) == 0:
            raise("Task Manager empty while still jobs need to be processed")
            for pallet in [p for p in jobListPallet if p not in taskManager['pallets']]:
                # get all pallets that need to be unloaded
                if (jobListPallet[pallet]['ready'] is not None):                                        ## if the pallet is currently active
                    uidJobFinish = jobListPallet[pallet]['ready']                                       ## get the job that needs to be unloaded
                    # print('Pallet [{}] is ready, add unload task for job [{}]'.format(pallet, uidJobFinish))
                    taskManager['tasks'].append((uidJobFinish, jobDatabase[uidJobFinish]['nextEvent'], 'DONE'))
                    taskManager['pallets'].append(pallet)
                # get all pallets that need to be loaded
                elif (jobListPallet[pallet]['queue']) and (jobListPallet[pallet]['pending'] is not None):
                    # print('Queue available: {}\t Pending Job on Pallet: {}'.format((jobListPallet[pallet]['queue']), (not jobListPallet[pallet]['pending'])))
                    # print('Pending job: {}'.format(jobListPallet[pallet]['pending']))
                    uidJobLoad = jobListPallet[pallet]['queue'][0]                                      ## get first job that needs to be loaded
                    # print('Pallet [{}] is idle, add job [{}] to start manufacturing'.format(pallet, uidJobLoad))
                    if (jobDatabase[uidJobLoad]['nextEvent'] is not None):
                        taskManager['tasks'].append((uidJobLoad, jobDatabase[uidJobLoad]['nextEvent'], 'LOAD'))
                        taskManager['pallets'].append(pallet)
                    else:
                        jobId = xrefUIDJob[uidJobLoad]
                        precedingJob = xrefJobPrecedence[jobId]
                        uidPrecedingJob = xrefJobUID[precedingJob]
                        # print('Pallet [{}] - Job {} is not eligible yet!'.format(pallet, jobListPallet[pallet]['queue'][0]))
                        # print('Pallet [{}] -         preceding Job [{}]'.format(pallet, uidPrecedingJob))
            
            # for pallet in range(palletCapacity):
            #     print('[{}] Current Queue: {}'.format(pallet, jobListPallet[pallet]['queue']))


        task = taskManager['tasks'].pop(0)
        taskJob = task[0]
        taskTime = task[1]
        taskType = task[2]
        jobPallet = jobDatabase[taskJob]['pallet']
        jobMachine = jobDatabase[taskJob]['machine']
        jobNc = jobDatabase[taskJob]['nc']

        # print('Time [{}]: ------- JOB: {} -- {} ---------'.format(taskTime, jobList[taskJob], taskType))

        if (taskType == 'LOAD') or (taskType == 'DONE'):
            
            taskManager['pallets'].remove(jobPallet)
            
            if (taskType == 'LOAD'):
                loadCounter += 1
                # remove job to load from queue
                jobListPallet[jobPallet]['queue'].remove(taskJob)
                jobListPallet[jobPallet]['pending'] = taskJob
                # add job to load to pending jobs of machine, sort joblist of the machine on sequence numbers
                jobListMachine[jobMachine]['queue'].remove(taskJob)
                jobListMachine[jobMachine]['active'].append(taskJob)
                jobListMachine[jobMachine]['active'].sort(key=lambda job: jobDatabase[job]['sequence'])

                loadStart = max(0, taskTime)
                timeRemaining, start2 = 0, 0
                reconfigure = True
                if (jobListPallet[jobPallet]['complete']):
                    previousPalletJob = jobListPallet[jobPallet]['complete'][-1]
                    previousPalletJobNc = jobDatabase[previousPalletJob]['nc']
                    if ncDatabase[jobNc]['pa'] == ncDatabase[previousPalletJobNc]['pa']:
                        reconfigure = False
                    loadStart, timeRemaining, start2 = CalculateSupervisedTimes(taskTime, supervisedShift)

                jobDatabase[taskJob]['ls'] = loadStart
                loadEnd = loadStart
                jobDatabase[taskJob]['reconfigure'] = reconfigure
                if (reconfigure):
                    if (timeRemaining > 0):                                                 ## [1] if reconfiguration start in supervised shift
                        if (palletSetupTime < timeRemaining):                         ##  [2] if pallet reconfiguration can be done within remaining time
                            loadEnd = loadStart + palletSetupTime
                            # print('\tCompletely Done within supervised: end at start {} + reconfig {} = {}'.format(loadStart, palletSetupTime, loadEnd))
                        else:
                            loadEnd = start2 + (palletSetupTime - timeRemaining)      ##  [2] else remaining time is processed from start2
                            # print('\tRemaining Done at start of supervised: end at start {} + reconfig {} = {}'.format(start2, (palletSetupTime - timeRemaining), loadEnd))
                    else:
                        loadEnd = start2 + palletSetupTime                            ## [1] else reconfiguration start at start shift next day
                        # print('\tCompletely Done at start of supervised: end at start {} + reconfig {} = {}'.format(start2, palletSetupTime, loadEnd))
                jobDatabase[taskJob]['le'] = loadEnd
                jobDatabase[taskJob]['nextEvent'] = loadEnd
            
                taskDatabase.append({'Job': taskJob, 'Start': loadStart, 'End': loadEnd, 'Resource': 'P' + str(jobPallet), 'Task': taskType})

                # print('\tJOB [{}] Reconfiguration: {}'.format(jobList[taskJob], reconfigure))

            if (taskType == 'DONE'):

                doneCounter += 1
                unloadTime, remainingTime, start2 = CalculateSupervisedTimes(taskTime, supervisedShift)            ## defined after milling when pallet can be removed

                ## make next job of same operation eligible
                succeedingOperationJob = jobDatabase[taskJob]['succeedingJob']
                if (succeedingOperationJob):
                    uidSucceedingOperationJob = xrefJobUID[succeedingOperationJob]
                    jobDatabase[uidSucceedingOperationJob]['nextEvent'] = unloadTime

                ## make next pallet job available
                if (jobListPallet[jobPallet]['queue']):
                    uidNextPalletJob = jobListPallet[jobPallet]['queue'][0]
                    ## IF already available from previous preceding operation job
                    if jobDatabase[uidNextPalletJob]['nextEvent'] != None:
                        jobDatabase[uidNextPalletJob]['nextEvent'] = unloadTime

                jobDatabase[taskJob]['u'] = unloadTime

                # remove job to unload from ready
                jobListPallet[jobPallet]['pending'] = None
                jobListPallet[jobPallet]['ready'] = None
                # add job to load to list of completed jobs of the pallet (to get the )
                jobListPallet[jobPallet]['complete'].append(taskJob)
                jobDatabase[taskJob]['done'] = True
                jobDatabase[taskJob]['nextEvent'] = None
                jobListOpen.remove(taskJob)

                if finishedAt < jobDatabase[taskJob]['u']:
                    finishedAt = jobDatabase[taskJob]['u']
        
                taskDatabase.append({'Job': taskJob, 'Start': unloadTime, 'End': unloadTime, 'Resource': 'P' + str(jobPallet), 'Task': taskType})

        if (taskType == 'MILL'):

            millCounter +=1
            taskManager['machines'].remove(jobMachine)

            millStart = jobDatabase[taskJob]['nextEvent']

            resourceFree = 0
            if (jobListMachine[jobMachine]['done']):
                previousMachineJob = jobListMachine[jobMachine]['done'][-1]
                toolStorage = jobDatabase[previousMachineJob]['toolStorage']
                resourceFree = jobDatabase[previousMachineJob]['e']
            else:
                previousMachineJob = None
                toolStorage = toolStorageStartSim[jobMachine]

            requireTools = ncDatabase[jobNc]['ta']
            missingTools = []

            millStart = max(millStart, resourceFree)

            ## [5]:     Get the actual tool storage and check if the job needs to be delayed because of missing tools

            toolSwitchInstance = False
            toolStorage.sort()
            requireTools.sort()
            for toolNumber in requireTools:
                if toolNumber not in toolStorage:
                    missingTools.append(toolNumber)
                    toolSwitchInstance = True
            if (toolSwitchInstance):
                millStart, remainingMinutes, remainingStartAt = CalculateSupervisedTimes(millStart, supervisedShift)

            millEnd = millStart + ncDatabase[jobNc]['cycle']

            ## [6]:     Update the tool storage

            toolSwitches = 0

            evaluateToolStorage = toolStorage + missingTools
            evaluateToolStorage.sort()
            if len(evaluateToolStorage) > toolCapacity:
                jobListTemp = [job for job in jobListMachine[jobMachine]['active'] if job != taskJob] + [job for job in jobListMachine[jobMachine]['queue']]
                jobListTemp.sort(key=lambda job: jobDatabase[job]['sequence'], reverse=False)
                jobListTemp = [taskJob] + jobListTemp
                toolStorageTemp = evaluateToolStorage.copy()
                toolRemovalList = TRM(toolStorageTemp, jobListTemp, jobDatabase, ncDatabase, toolCapacity)
                while len(evaluateToolStorage) > toolCapacity:
                    uidToolRemove = toolRemovalList.pop(0)
                    if uidToolRemove in requireTools:
                        # print('JOB [{}] - TA Requirements: {}'.format(taskJob, requireTools))
                        raise('[ERROR] try to remove tool [{}] that is required!'.format(uidToolRemove))
                    evaluateToolStorage.remove(uidToolRemove)
                    toolSwitches += 1           

            toolStorage = evaluateToolStorage.copy()
            
            ## update statistics

            unloadTime, timeRemaining, start2 = CalculateSupervisedTimes(taskTime, supervisedShift)

            jobDatabase[taskJob]['s'] = millStart
            jobDatabase[taskJob]['e'] = millEnd
            jobDatabase[taskJob]['toolStorage'] = toolStorage
            jobDatabase[taskJob]['toolSwitches'] = toolSwitches
            jobDatabase[taskJob]['nextEvent'] = millEnd

            jobListMachine[jobMachine]['active'].remove(taskJob)
            jobListMachine[jobMachine]['done'].append(taskJob)
            jobListPallet[jobPallet]['ready'] = taskJob

            taskDatabase.append({'Job': taskJob, 'Start': millStart, 'End': millEnd, 'Resource': 'M' + str(jobMachine), 'Task': taskType})
            taskDatabase.append({'Job': taskJob, 'Start': millStart, 'End': millEnd, 'Resource': 'P' + str(jobPallet), 'Task': taskType})

            # print('\tJOB [{}] Tool Switches:   {}'.format(jobList[taskJob], toolSwitches))

        # print()

        iteration += 1

    # printJobListOpen = [x for x in jobListOpen]
    # printJobListOpen.sort(key=lambda j: jobDatabase[j]['sequence'])
    # print('Joblist OPEN: {}'.format(printJobListOpen))
    # for p in range(palletCapacity):
    #     printPalletJobListQueue = [x for x in jobListPallet[p]['queue']]
    #     printPalletJobListQueue.sort(key=lambda j: jobDatabase[j]['sequence'])
    #     printPalletJobListReady = [x for x in jobListPallet[p]['complete']]
    #     printPalletJobListReady.sort(key=lambda j: jobDatabase[j]['sequence'])
        # print('Pallet [{}]: Ready: {}\tActive: {}\tNext: {}\tQueue: {}'.format(p, printPalletJobListReady, jobListPallet[p]['active'], jobListPallet[p]['next'], printPalletJobListQueue))

    endSim = dt.datetime.now()

    ## JOB TIMES

    for job in jobDatabase:
        # check if precedence constraints are upheld
        if jobDatabase[job]['succeedingJob']:
            uidSucceedingJob = xrefJobUID[jobDatabase[job]['succeedingJob']]
            if jobDatabase[uidSucceedingJob]['ls'] < jobDatabase[job]['u']:
                invalidRun = True
                # print('Preceding job:  {} / {}'.format(job, jobDatabase[job]['jobID']))
                # print('Succeeding job: {} / {}'.format(uidSucceedingJob, jobDatabase[uidSucceedingJob]['jobID']))
                # print('Job: {}\t\t\tU: {}\nSucceeding Job: {}\tL: {}'.format(job, jobDatabase[job]['u'], uidSucceedingJob, jobDatabase[uidSucceedingJob]['ls']))
                # raise('[ERROR] Times don\'t match, precedence constraints not upheld!')
            # else:
            #     print('JOB [{}] -- {} < {} -- JOB [{}]'.format(job, jobDatabase[job]['u'], jobDatabase[uidSucceedingJob]['ls'], uidSucceedingJob))
        # check if pallet is loaded in unsupervised time
        loadingStart = jobDatabase[job]['ls']
        loadingEnd = jobDatabase[job]['le']
        iterIndex = 0
        for time in [loadingStart, loadingEnd]:
            if iterIndex == 0:
                text = 'Load Start'
            else:
                text = 'Load End'
            # print('{} - {}'.format(text, time))
            timeDaysAct = (time // (24 * 60))
            timeMinuteAct = time - (timeDaysAct * 24 * 60)                                       ## get the complete days by //-operator. Sub reduce loadTime with full days
            if (timeMinuteAct > ((supervisedShift * 60) * (timeDaysAct + 1))):
                # print('TimeMinuteAct: {} vs. Comp.: {}'.format(timeMinuteAct, ((supervisedShift * 60) * (timeDaysAct + 1))))
                # print('Days: {}'.format(timeDaysAct))
                # print('Supervised shift: {}'.format(supervisedShift * 60))
                # print('   with days: {}'.format(((supervisedShift * 60) * timeDaysAct)))
                # print('Job [{}] -- Time: {}'.format(job, timeMinuteAct))
                invalidRun = True
                raise('[ERROR] Loading times of Job [{}] are in unsupervised shift [{}]'.format(job, timeMinuteAct))
            iterIndex += 1
            
    ## check times of machine joblsit
    # for machine in range(cncCapacity):
    #     actualJobList = jobListMachine[machine]['done']
    #     while len(actualJobList):
    #         uidJob = actualJobList.pop(0)
    #         startJob = jobDatabase[uidJob]['s']
    #         endJob = jobDatabase[uidJob]['e']
    #         for otherJob in actualJobList:
    #             startJob2 = jobDatabase[otherJob]['s']
    #             endJob2 = jobDatabase[otherJob]['e']
    #             if (startJob < startJob2) and (endJob > startJob2):
    #                 invalidRun = True
    #                 raise('[ERROR] Job [{}] and Job [{}] have conflicting production times'.format(uidJob, otherJob))
    #             if (startJob > startJob2) and (endJob < endJob2):
    #                 invalidRun = True
    #                 raise('[ERROR] Job [{}] and Job [{}] have conflicting production times'.format(uidJob, otherJob))
    #             if (startJob < endJob2) and (endJob > endJob2):
    #                 invalidRun = True
    #                 raise('[ERROR] Job [{}] and Job [{}] have conflicting production times'.format(uidJob, otherJob))
    #             if (startJob < startJob2) and (endJob > endJob2):
    #                 invalidRun = True
    #                 raise('[ERROR] Job [{}] and Job [{}] have conflicting production times'.format(uidJob, otherJob))
                

    # print(jobDatabase)

    # checkSimModel = False
    # if (checkSimModel):

    #     today = dt.datetime.now()
    #     startDate = dt.datetime(today.year, today.month, today.day, 0, 0, 0)

    #     dfExport = pd.DataFrame(taskDatabase)
    #     # dfExport['Start'] = dfExport['Start'].apply(lambda x: startDate + dt.timedelta(minutes=x))
    #     # dfExport['End'] = dfExport['End'].apply(lambda x: startDate + dt.timedelta(minutes=x))
    #     dfExport['Delta'] = dfExport['End'] - dfExport['Start']
    #     # print(dfExport)
    #     # fig = px.timeline(dfExport, x_start="Start", x_end="End", y="Resource", color="Task")
    #     fig = px.timeline(dfExport, x_start="Start", x_end="End", y="Resource", color='Task')
    #     fig.update_xaxes(type='linear', dtick=(6*60))
    #     for d in fig.data:
    #         filt = dfExport['Task'] == d.name
    #         d.x = dfExport[filt]['Delta'].tolist()
    #     fig.show()

    #     exportResultsDf = pd.DataFrame.from_dict(jobDatabase, orient='index')
    #     write = 'CheckSimModel.xlsx'
    #     with pd.ExcelWriter(write) as writer:
    #         exportResultsDf.to_excel(writer, sheet_name = 'Trace', index = False)

    
    durationSim = endSim.timestamp() - startSim.timestamp()
    durationSimPrint = round(durationSim, 1)


    leadtimeTotal = finishedAt / 60
    obj_leadtimeCost = leadtimeTotal * cncDepreciationCost * cncCapacity
    toolSwitchesTotal = sum([jobDatabase[j]['toolSwitches'] for j in jobDatabase])
    obj_toolSwitchCost = toolSwitchesTotal * toolSwitchCost
    palletSetups = len([j for j in jobDatabase if (jobDatabase[j]['reconfigure'])])
    obj_palletSetupsCost = palletSetups * palletSetupCost

    # print('Total Makespan:        {} days'.format(round(leadtimeTotal / 60, 2)))
    # print('Total Tool switches:   {} instances'.format(toolSwitchesTotal))
    # print('Total Reconfiguration: {} instances'.format(palletSetups))
    # print()

    if invalidRun:
        obj_leadtimeCost = sum([jobDatabase[job]['cycle'] for job in jobDatabase]) * cncDepreciationCost * cncCapacity
        obj_toolSwitchCost = len(jobDatabase) * toolCapacity * toolSwitchCost
        obj_palletSetupsCost = len(jobDatabase) * palletSetupCost

    obj_functionValue = obj_leadtimeCost + obj_toolSwitchCost + obj_palletSetupsCost

    if chromosomeID < 10:
        identifier = '0000' + str(chromosomeID)
    elif chromosomeID < 100:
        identifier = '000' + str(chromosomeID)
    elif chromosomeID < 1000:
        identifier = '00' + str(chromosomeID)
    elif chromosomeID < 10000:
        identifier = '0' + str(chromosomeID)
    else:
        identifier = str(chromosomeID)

    # print('# of iterations: {}'.format(iteration))
    # print('{} \t ID: {}. Done in: {} seconds. \t OBJ. VALUE = {} (LEAD: {}, TOOL: {}, PALLET: {})'.format(runFrom, identifier, durationSimPrint, round(obj_functionValue, 0), round(obj_leadtimeCost, 0), round(obj_toolSwitchCost, 0), round(obj_palletSetupsCost, 0)))

    return obj_functionValue, obj_leadtimeCost, obj_toolSwitchCost, obj_palletSetupsCost, invalidRun

if __name__ == '__main__':

    runUntil = (60*24*3) + 1 # +1 to end last day and get final report in terminal
    checkSimModel = True

    cncCapacity = 2
    toolCapacity = 80
    palletMachine = 4
    palletCapacity = cncCapacity * palletMachine

    cncDepreciationCost = 100
    toolSwitchCost = 1
    palletSetupCost = 100
    palletSetupTime = 60 * 4
    inputParameters = {'palletSetupCost': palletSetupCost, 'cncDepreciationCost': cncDepreciationCost, 'toolSwitchCost': toolSwitchCost, 'palletSetupTime': palletSetupTime, 'cncCapacity': cncCapacity, 'toolCapacity': toolCapacity, 'palletCapacity': palletCapacity, 'supervisedShift': 18}

    productVariety = 1
    toolConsumption = 1
    simDays = 3
    workload = (60 * 24 * simDays * cncCapacity)

    portfolio, ncDatabase = GetProductData()
    jobIdList, xrefJobOperation, xrefJobPrecedence, xrefJobNc = GenerateJobs(portfolio, ncDatabase, 152)
    toolStorageAct = getEmpiricalData()
    initialData = ClusterInitialData(jobIdList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, 'B', 1, toolStorageAct)

    sequenceVector, machineVector, palletVector = GetInitialVectors(jobIdList, cncCapacity, palletCapacity)
    sequenceVectorOLD = sequenceVector.copy
    machineVectorOLD = machineVector.copy
    palletVectorOLD = palletVector.copy
    geneRepresentation = GaSafeguard(jobIdList, xrefJobPrecedence, [sequenceVector, machineVector, palletVector])
    sequenceVector = geneRepresentation[0]
    if sequenceVector == sequenceVectorOLD:
        raise ('no changes made!')
    machineVector = geneRepresentation[1]
    if machineVector == machineVectorOLD:
        raise ('no changes made!')
    palletVector = geneRepresentation[2]
    if palletVector == palletVectorOLD:
        raise ('no changes made!')
    with open('RQ2_03_Debug_Chromosome_sequenceVector.json', 'r') as fp:
        sequenceVector = json.load(fp)
    with open('RQ2_03_Debug_Chromosome_machineVector.json', 'r') as fp:
        machineVector = json.load(fp)
    with open('RQ2_03_Debug_Chromosome_palletVector.json', 'r') as fp:
        palletVector = json.load(fp)
    returnDict = dict()
    sumValue = GaCalcFitness(initialData, 1, geneRepresentation, returnDict, inputParameters, 'Single')