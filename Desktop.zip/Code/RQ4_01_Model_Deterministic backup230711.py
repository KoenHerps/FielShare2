from datetime import datetime, time
from email.policy import EmailPolicy
from json import tool
from mimetypes import suffix_map
from msilib import sequence
from operator import index
from pickle import NONE
from platform import machine
import time as timeDouble
from os import cpu_count, error, removedirs
from re import match
from tkinter.ttk import Progressbar
from typing import Match
from xml.dom.minidom import parseString
# from numpy.core.fromnumeric import take
# from numpy.core.numeric import False_
import statistics
import pandas as pd
from pytz import NonExistentTimeError
import numpy as np
import plotly.express as px
import random
import math
import csv
# import threading
# import sys
from itertools import count, cycle
import json

## import functions to do stand-alone validation

import RQ2_06_Functions
from RQ2_06_Functions import CalculateStartSupervised, TRM
import RQ2_05_DataInput

## create random simulation variables

def calculate_fitness_value(initialData, chromosomeID, geneRepresentation, returnDict, inputParameters, runFrom):
    # initialData = [jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, cncCapacity, operNcXref, actToolStorage]

    sequenceVector = geneRepresentation[0]
    machineVector = geneRepresentation[1]
    palletVector = geneRepresentation[2]

    jobList = initialData[0]
    ncDatabase = initialData[1]
    xrefJobPrecedence = initialData[3]
    xrefJobNc = initialData[4]
    toolStorageAct = initialData[6]

    cncCapacity = inputParameters['cncCapacity']
    palletCapacity = inputParameters['palletCapacity']
    toolStorageCapacity = inputParameters['toolStorageCapacity']
    toolSwitchDelay = inputParameters['toolSwitchDelay']
    leadtimeCost = inputParameters['leadtimeCost']

    supervisedShift = inputParameters['supervisedShift']

    startSim = datetime.now()

    xrefJobUID = {}
    xrefUIDJob = {}
    uidJob = 0
    uidTool = 0

    toolStorageStartSim = {}
    
    jobDatabase = {}
    jobListOpen = []            ## all jobs that need to be loaded
    jobListLoad = []
    jobListActive = []          ## all current active jobs in the system
    jobListPallet = {palletIndex: {'queue': [], 'next': None, 'active': None, 'ready': []} for palletIndex in range(palletCapacity)}
    jobListMachine = {machineIndex: {'active': [], 'ready': []} for machineIndex in range(cncCapacity)}

    jobListPalletNew = {palletIndex: {'queue': [], 'next': None, 'active': None, 'ready': []} for palletIndex in range(palletCapacity)}
    nextPalletReady = [0 for p in range(palletCapacity)]
    jobListMachineNew = {palletIndex: {'queue': [], 'ready': []} for palletIndex in range(cncCapacity)}
    nextMachineReady = [0 for m in range(cncCapacity)]

    ## initiate tool storage at the beginning of the simulation

    for machineId in toolStorageAct.keys():
        toolStorageStartSim[int(machineId)] = [x for x in toolStorageAct[machineId].keys()]

    ## initiate time variables

    finishedAt = 0

    ## generate jobDatabase
    for jobIndex in range(len(jobList)):
        jobID = jobList[jobIndex]
        xrefJobUID[jobID] = uidJob
        xrefUIDJob[uidJob] = jobID
        nc = xrefJobNc[jobID]
        cycleTime = ncDatabase[nc]['cycle']
        sequenceGene = sequenceVector[jobIndex]
        machineGene = machineVector[jobIndex]
        palletGene = palletVector[jobIndex]
        availableAt = None
        precedingJob = None
        if (xrefJobPrecedence[jobID] == None):
            availableAt = 0
        else:
            precedingJob = xrefJobPrecedence[jobID]
        succeedingJob = None
        succeedingJobList = [k for k, v in xrefJobPrecedence.items() if v == jobID]
        if len(succeedingJobList) > 0:
            succeedingJob = succeedingJobList[0]
        jobDatabase[uidJob] = {'jobID': jobID, 'nc': nc, 'cycle': cycleTime, 'sequence': sequenceGene, 'machine': machineGene, 'pallet': palletGene, 'a': availableAt, 'l': 0, 's': 0, 'e': 0, 'u': 0, 'scheduled': False, 'reconfigure': False, 'toolStorage': [], 'toolSwitches': [], 'precedingJob': precedingJob, 'succeedingJob': succeedingJob}
        printDict = {'jobID': jobID, 'nc': nc, 'cycle': cycleTime, 'sequence': sequenceGene, 'machine': machineGene, 'pallet': palletGene, 'a': availableAt, 'l': 0, 's': 0, 'e': 0, 'u': 0, 'prec. Job': precedingJob, 'succ. Job': succeedingJob}
        print('[{}]: {}'.format(uidJob, printDict))
        jobListOpen.append((uidJob, sequenceGene))
        jobListPallet[palletGene]['queue'].append(uidJob)
        uidJob += 1
   
    jobListOpen.sort(key=lambda x: x[1], reverse=False)
    jobListOpen = [x[0] for x in jobListOpen]

    p = 0
    while p < (palletCapacity):
        print('[{}] JobList'.format(p))
        for job in jobListOpen:
            if jobDatabase[job]['pallet'] == p:
                jobListPallet[p]['next'] = jobListPallet[p]['queue'].pop(jobListPallet[p]['queue'].index(job))
                break
        jobListPallet[p]['queue'].sort(key=lambda job: jobDatabase[job]['sequence'], reverse=False)
        print('Next: {}\tSeq. {}'.format(job, jobDatabase[job]['sequence']))
        for job in range(len(jobListPallet[p]['queue'])):
            print('Queue [{}]: {}\tSeq. {}'.format(job, jobListPallet[p]['queue'][job], jobDatabase[jobListPallet[p]['queue'][job]]['sequence']))
        p += 1

    iteration = 1

    while len(jobListOpen) != 0:

        ## get all jobs that are next in line at the pallet, and made eligible by preceding jobs
        
        jobListLoad = [(job, jobDatabase[job]['pallet'], jobDatabase[job]['a']) for job in [jobListPallet[pallet]['next'] for pallet in jobListPallet if jobListPallet[pallet]['next'] != None] if (type(jobDatabase[job]['a']) == float) or (type(jobDatabase[job]['a']) == int)]
        # jobListUnload = [(job, jobDatabase[job]['pallet'], jobDatabase[job]['u']) for job in [jobListPallet[pallet]['active'] for pallet in jobListPallet]]

        # if len(jobListLoad):
        #     potJobLoad = min(jobListLoad, key=lambda j: j[2])
        # if len(jobListUnload):
        #     potJobUnload =  min(jobListUnload, key=lambda j: j[2])

        # print('JobList NEXT')
        for job in [x for x in [jobListPallet[pallet]['next'] for pallet in jobListPallet if (jobListPallet[pallet]['next'] != None)]]:
            if len(str(job)) < 3:
                addToPrint = '  '
            else:
                addToPrint = ''
            # print(job)
            if len(str(jobDatabase[job]['sequence'])) > 1:
                addToSeq = ''
            else:
                addToSeq = ' '
            if type(jobDatabase[job]['a']) != int:
                precedingJob = xrefJobPrecedence[xrefUIDJob[job]]
                # print('Pallet\t[{}]\tJob: {}{}\tSeq.: {}{}\tAvail.: {}\tWait: Y'.format(jobDatabase[job]['pallet'], job, addToPrint, addToSeq, jobDatabase[job]['sequence'], jobDatabase[job]['a']))
                if precedingJob != None:
                    uidPrecedingJob = xrefJobUID[precedingJob]
            #         print('- Pallet [{}]\tJob: {}{}\tSeq.: {}\tU.: {}'.format(jobDatabase[uidPrecedingJob]['pallet'], uidPrecedingJob, addToPrint, jobDatabase[uidPrecedingJob]['sequence'], jobDatabase[uidPrecedingJob]['u']))
            # else:
            #     print('Pallet\t[{}]\tJob: {}{}\tSeq.: {}{}\tAvail.: {}\tWait: N.A.'.format(jobDatabase[job]['pallet'], job, addToPrint, addToSeq, jobDatabase[job]['sequence'], jobDatabase[job]['a']))

        print('Start Selection')
        # print('JobList Load: {}'.format(jobListLoad))

        tupleJobLoad = min(jobListLoad, key=lambda j: j[2])
        uidJobLoad = tupleJobLoad[0]
        availableJobLoad = tupleJobLoad[2]
        palletJobLoad = jobDatabase[uidJobLoad]['pallet']
        machineJobLoad = jobDatabase[uidJobLoad]['machine']
        sequenceJobLoad = jobDatabase[uidJobLoad]['sequence']
        ncJobLoad = jobDatabase[uidJobLoad]['nc']

        print('----------------------------------------------------------START SCHEDULE JOB: [{}] ({}/{}) - M[{}] / P[{}] ----------------------------------------------'.format(uidJobLoad, iteration, len(jobDatabase), machineJobLoad, palletJobLoad))

        ## Update all jobs that are still in the system and unloaded before the load of the new job

        jobListPrint = [(x, jobDatabase[x]['pallet']) for x in jobListActive]
        jobListPrint.sort(key=lambda j: j[1], reverse=False)
        # print('Time = [{}] JobList Active at Load: {}'.format(availableJobLoad, jobListPrint))

        for job in jobListActive:
            # print('Consider Job {} -- Unload at: {}\t Unload now: {}'.format(job, jobDatabase[job]['u'], jobDatabase[job]['u'] <= availableJobLoad))
            if jobDatabase[job]['u'] <= availableJobLoad:
                palletUnloadJob = jobDatabase[job]['pallet']
                # print('Job: {}'.format(job))
                # print('JobListActive: {}'.format(jobListActive))
                # print('Index of job {} at {}'.format(job, jobListActive.index(job)))
                jobListActive.remove(job)
                jobListPallet[palletUnloadJob]['ready'].append(job)
                machineJobUnload = jobDatabase[job]['machine']
                jobListMachine[machineJobUnload]['ready'].append(jobListMachine[machineJobUnload]['active'].pop(jobListMachine[machineJobUnload]['active'].index(job)))
        # print('New JobList Active: {}'.format(jobListActive))

        ## [1]:     Get reconfigure requirements

        reconfigure = True
        if type(jobListPallet[palletJobLoad]['active']) == int:
            uidPreviousPalletJob = jobListPallet[palletJobLoad]['active']
            loadTime = CalculateStartSupervised(availableJobLoad, supervisedShift)
            if ncDatabase[ncJobLoad]['pa'] == ncDatabase[jobDatabase[uidPreviousPalletJob]['nc']]['pa']:
                reconfigure = False
        else:
            loadTime = 0

        # update statistics after loading of job


        print('JOB [{}] - L: {}'.format(uidJobLoad, loadTime))

        jobDatabase[uidJobLoad]['l'] = loadTime
        jobDatabase[uidJobLoad]['reconfigure'] = reconfigure
        jobListActive.append(uidJobLoad)
        # print('Append {} to jobListActive: {}'.format(uidJobLoad, jobListActive))
        jobListPallet[palletJobLoad]['active'] = jobListPallet[palletJobLoad]['next']
        if (jobListPallet[palletJobLoad]['queue']):
            jobListPallet[palletJobLoad]['next'] = jobListPallet[palletJobLoad]['queue'].pop(0)
        else:
            jobListPallet[palletJobLoad]['next'] = None
        jobListMachine[machineJobLoad]['active'].append(uidJobLoad)
        jobListMachine[machineJobLoad]['active'].sort(key=lambda j: jobDatabase[j]['s'])
        print('JOB [{}] - Active joblist of machine {}: {}'.format(uidJobLoad, machineJobLoad, jobListMachine[machineJobLoad]['active']))

        ## [2]:     Reconsider active jobs that are already loaded in the system

        # get all jobs that are currently loaded in the system (excluding the load job), use the same machine and are still pending
        pendingMachineJobs = [j for j in jobListMachine[machineJobLoad]['active'] if (j != uidJobLoad) if (jobDatabase[j]['s'] >= loadTime)]
        scheduleMachineJobs = [uidJobLoad]
        # if there are jobs with a higher sequence value, reschedule all jobs from endTimePreviousMachineJob to max(e)
        print('JOB [{}] - Re-evaluate jobs: {}'.format(uidJobLoad, pendingMachineJobs))
        for pendingMachineJob in pendingMachineJobs:
            print('\tJOB [{}]\tSequence: {} (w.r.t. {})'.format(pendingMachineJob, jobDatabase[pendingMachineJob]['sequence'], jobDatabase[uidJobLoad]['sequence']))
            # if jobs have a higher sequence number, schedule new loaded job first, than remaining of joblist of machine
            if (jobDatabase[pendingMachineJob]['sequence'] > sequenceJobLoad):
                # reconfigure the joblist that needs to be rescheduled
                scheduleMachineJobs.extend(pendingMachineJobs[pendingMachineJobs.index(pendingMachineJob):])
                # break because all subsequent jobs also need to be rescheduled (i.e., tool storage not up-to-date)
                print('\t\t [INFO] Stop iterating and add remaining re-evaluate jobs to reschedule jobs')
                break
            else:
                print('\t\t [INFO] pending job had higher priority than loaded job')
        scheduleMachineJobs.sort(key=lambda j: jobDatabase[j]['sequence'], reverse=False)
        print('JOB [{}]\t\tReschedule jobs: {}'.format(uidJobLoad, scheduleMachineJobs))

        # get the current status of fixed jobs on the machine, to get the last job
        queueJobsFixed = jobListMachine[machineJobLoad]['ready'] + [j for j in jobListMachine[machineJobLoad]['active'] if (j not in scheduleMachineJobs)]

        # print('Job: {}\t- Loaded jobs: {}'.format(uidJobLoad, scheduleMachineJobs))

        ## [3]:     Start (re)scheduling the jobs that are already in the system on the machine

        for uidJobSchedule in scheduleMachineJobs:
            sequenceJobSchedule = jobDatabase[uidJobSchedule]['sequence']
            machineJobSchedule = jobDatabase[uidJobSchedule]['machine']
            palletJobSchedule = jobDatabase[uidJobSchedule]['pallet']
            ncJobSchedule = jobDatabase[uidJobSchedule]['nc']

            ## [4]:     Get end time of previous machine job
        
            if (queueJobsFixed):
                uidPreviousMachineJob = queueJobsFixed[-1]
                toolStorage = jobDatabase[uidPreviousMachineJob]['toolStorage']
                resourceFree = jobDatabase[uidPreviousMachineJob]['e']
            else:
                uidPreviousMachineJob = None
                toolStorage = toolStorageStartSim[machineJobSchedule]
                resourceFree = jobDatabase[uidJobSchedule]['l']
        
            ## [5]:     Get the actual tool storage and check if the job needs to be delayed because of missing tools

            requireTools = ncDatabase[ncJobSchedule]['ta']
            missingTools = []

            startTime = max(resourceFree, jobDatabase[uidJobSchedule]['l'])
            # print('\tJob: {}\t- Start Time {}'.format(uidJobSchedule, startTime))
            toolSwitchInstance = False
            for toolNumber in requireTools:
                if toolNumber not in toolStorage:
                    missingTools.append(toolNumber)
                    toolSwitchInstance = True
            if (toolSwitchInstance):
                startTime = CalculateStartSupervised(startTime, supervisedShift)
                # print('\tJob: {}\t- Re-evaluated Start Time {}'.format(uidJobSchedule, startTime))

            endTime = startTime + ncDatabase[ncJobSchedule]['cycle']

            # print('\tJob: {}\t- End Time {}'.format(uidJobSchedule, endTime))

            ## [6]:     Update the tool storage

            toolSwitches = 0

            evaluateToolStorage = list(set(toolStorage + missingTools))
            if len(evaluateToolStorage) > toolStorageCapacity:
                jobListTemp = jobListActive + jobListOpen
                jobListTemp = [j for j in jobListTemp if (j not in queueJobsFixed)]
                jobListTemp.sort(key=lambda j: jobDatabase[j]['sequence'])
                toolRemovalList = TRM(evaluateToolStorage, jobListTemp, jobDatabase, ncDatabase, toolStorageCapacity)
                toolStorage = evaluateToolStorage
                print('ToolStorage: {} - Capacity: {}'.format(len(toolStorage), toolStorageCapacity))
                while len(toolStorage) > toolStorageCapacity:
                    toolStorage.remove(toolRemovalList.pop(0))
                    toolSwitches += 1
                    print('ToolStorage: {} - TRM list: {}'.format(len(toolStorage), len(toolRemovalList)))

            ## [7]:     Set unloading time from system

            unloadTime = CalculateStartSupervised(endTime, supervisedShift)

            ## [8]:     Update jobDatabase and jobList statistics

            print('JOB [{}] - update statistics'.format(uidJobSchedule))

            # jobDatabase[uidJobSchedule]['l'] = loadTime > previously done, at load
            jobDatabase[uidJobSchedule]['s'] = startTime
            jobDatabase[uidJobSchedule]['e'] = endTime
            jobDatabase[uidJobSchedule]['u'] = unloadTime
            jobDatabase[uidJobSchedule]['scheduled'] = True
            # jobDatabase[uidJobSchedule]['reconfigure'] = reconfigure > previsoulsy done, at load
            jobDatabase[uidJobSchedule]['toolStorage'] = toolStorage
            jobDatabase[uidJobSchedule]['toolSwitches'] = toolSwitches
            succeedingJob = jobDatabase[uidJobSchedule]['succeedingJob']

            ## UPDATE: if the current job contains a subsequent job of the same order, release at current unloading time
            
            if (succeedingJob):
                uidSucceedingJob = xrefJobUID[succeedingJob]
                print('JOB [{}] - Succeeding Job [{}] of the same WORKORDER'.format(uidJobSchedule, uidSucceedingJob))
                if (uidSucceedingJob):
                    currentAvailability = jobDatabase[uidSucceedingJob]['a']
                    print('Current availability {} - Unload time {}'.format(currentAvailability, unloadTime))
                    jobDatabase[uidSucceedingJob]['a'] = max(currentAvailability, unloadTime)
                    print('JOB [{}] - Succeeding workorder job [{}], set availability to {}'.format(uidJobSchedule, uidSucceedingJob, jobDatabase[uidSucceedingJob]['a']))
            #         print('[Pallet {} / Job {}] Succ. Operat-Job [{}] Availability set to:\t{}'.format(jobDatabase[uidJobSchedule]['pallet'], uidJobSchedule, uidSucceedingJob, jobDatabase[uidSucceedingJob]['a']))
            # else:
            #     print('[Pallet {} / Job {}] No Succ. Operat-Job'.format(jobDatabase[uidJobSchedule]['pallet'], uidJobSchedule))
            
            ## UPDATE: if the current job containts subsequent jobs of the same pallet, release remaining jobs at later moment (if precedence constraint already satisfied)

            uidSucceedingPalletJob = jobListPallet[palletJobSchedule]['next']
            if (uidSucceedingPalletJob):
                print('JOB [{}] - Succeeding Job [{}] of the same PALLET'.format(uidJobSchedule, uidSucceedingPalletJob))
                precedingJob = jobDatabase[uidJobSchedule]['precedingJob']
                if (precedingJob):
                    uidPrecedingJob = xrefJobUID[precedingJob]
                    if jobDatabase[uidPrecedingJob]['scheduled']:
                        print('JOB [{}] - Preceding Job [{}] of Job [{}] scheduled: {}'.format(uidJobSchedule, uidPrecedingJob, uidSucceedingPalletJob, jobDatabase[uidPrecedingJob]['scheduled']))
                        jobDatabase[uidSucceedingPalletJob]['a'] = max(unloadTime, jobDatabase[uidPrecedingJob]['u'])
                        print('JOB [{}] - From preceding job [{}], Succeeding pallet job [{}], set availability to {}'.format(uidJobSchedule, uidPrecedingJob, uidSucceedingPalletJob, jobDatabase[uidSucceedingPalletJob]['a']))
                else:
                    previousPalletJobAvailable = jobDatabase[uidPrecedingJob]['u']
                
                jobDatabase[uidSucceedingPalletJob]['a'] = max(unloadTime, jobDatabase[uidPrecedingJob]['u'])
                    # raise('add clause to prevent changing availability when preceding job is not unloaded yet')
            #     print('[Pallet {} / Job {}] Succ. Pallet-Job [{}] Availability set to:\t{}'.format(jobDatabase[uidJobSchedule]['pallet'], uidJobSchedule, uidSucceedingPalletJob, jobDatabase[uidSucceedingPalletJob]['a']))
            # else:
            #     print('[Pallet {} / Job {}] No Succ. Pallet-Job'.format(jobDatabase[uidJobSchedule]['pallet'], uidJobSchedule))
            finishedAt = max(finishedAt, unloadTime)
            queueJobsFixed.append(uidJobSchedule)

            print('\tJOB [{}, seq. {}]\tL: {}, S: {}, E: {}, U: {}'.format(uidJobSchedule, jobDatabase[uidJobSchedule]['sequence'], jobDatabase[uidJobSchedule]['l'], startTime, endTime, unloadTime))

        # print('JobList ACTIVE')
        # for job in jobListActive:
        #     uidSucceedingPalletJob = jobListPallet[jobDatabase[job]['pallet']]['next']
        #     if (uidSucceedingPalletJob):
        #         print('Pallet [{}]: Job {}, Unload at {}, Next Job: {}, available at: {}'.format(jobDatabase[job]['pallet'], job, jobDatabase[job]['u'], uidSucceedingPalletJob, jobDatabase[uidSucceedingPalletJob]['a']))
        #     else:
        #         print('Pallet [{}]: Job {}, Unload at {}, Next Job: N.A.'.format(jobDatabase[job]['pallet'], job, jobDatabase[job]['u']))

        # print('Remove job {} - remaining jobs: {}\n{}\n{}'.format(uidJobLoad, len(jobListOpen), jobListOpen[:palletCapacity], jobListOpen[palletCapacity:]))

        jobListOpen.remove(uidJobLoad)
        iteration += 1

        printJobListOpen = [x for x in jobListOpen]
        printJobListOpen.sort(key=lambda j: jobDatabase[j]['sequence'])
        # print('Joblist OPEN: {}'.format(printJobListOpen))
        for p in range(palletCapacity):
            printPalletJobListQueue = [x for x in jobListPallet[p]['queue']]
            printPalletJobListQueue.sort(key=lambda j: jobDatabase[j]['sequence'])
            printPalletJobListReady = [x for x in jobListPallet[p]['ready']]
            printPalletJobListReady.sort(key=lambda j: jobDatabase[j]['sequence'])
            # print('Pallet [{}]: Ready: {}\tActive: {}\tNext: {}\tQueue: {}'.format(p, printPalletJobListReady, jobListPallet[p]['active'], jobListPallet[p]['next'], printPalletJobListQueue))

    endSim = datetime.now()

    ## solution 1
    # exportResults = []
    # for job in jobDatabase:
    #     jobID = jobDatabase[job]['jobID']
    #     nc = jobDatabase[job]['nc']
    #     cycle = jobDatabase[job]['cycle']
    #     sequence = 
    #     exportResults.append([jobID, nc, cycle, 'sequence': sequenceGene, 'machine': machineGene, 'pallet': palletGene, 'a': availableAt, 'l': 0, 's': 0, 'e': 0, 'u': 0, 'scheduled': False, 'reconfigure': False, 'toolStorage': [], 'toolSwitches': [], 'succeedingJob': succeedingJob])
    # exportResultsDf = pd.DataFrame(exportResults, columns=['valA', 'valB'])
    ## solution 2
    exportResultsDf = pd.DataFrame.from_dict(jobDatabase, orient='index')
    write = 'SimJobTrace.xlsx'
    with pd.ExcelWriter(write) as writer:
        exportResultsDf.to_excel(writer, sheet_name = 'Trace', index = False)


    for job in jobDatabase:
        if jobDatabase[job]['succeedingJob']:
            succeedingJob = xrefJobUID[jobDatabase[job]['succeedingJob']]
            if jobDatabase[succeedingJob]['l'] < jobDatabase[job]['u']:
                print('Preceding job:  {} / {}'.format(job, jobDatabase[job]['jobID']))
                print('Succeeding job: {} / {}'.format(succeedingJob, jobDatabase[succeedingJob]['jobID']))
                print('Job: {}\t\t\tU: {}\nSucceeding Job: {}\tL: {}'.format(job, jobDatabase[job]['u'], succeedingJob, jobDatabase[succeedingJob]['l']))
                raise('Times don\'t match, precedence constraints not upheld!')


    durationSim = endSim.timestamp() - startSim.timestamp()
    durationSimPrint = round(durationSim, 1)

    hourlyRate = 100
    makespanCost = finishedAt * hourlyRate
    toolSwitchRate = 5
    toolSwitchCost = sum([jobDatabase[j]['toolSwitches'] for j in jobDatabase]) * toolSwitchRate
    palletReconfigureRate = 50
    palletReconfigureCost = len([j for j in jobDatabase if (jobDatabase[j]['reconfigure'])]) * palletReconfigureRate

    objectiveFunctionValue = makespanCost + toolSwitchCost + palletReconfigureCost

    if chromosomeID < 10:
        identifier = '000000' + str(chromosomeID)
    elif chromosomeID < 100:
        identifier = '00000' + str(chromosomeID)
    elif chromosomeID < 1000:
        identifier = '0000' + str(chromosomeID)
    elif chromosomeID < 10000:
        identifier = '000' + str(chromosomeID)
    elif chromosomeID < 100000:
        identifier = '00' + str(chromosomeID)
    elif chromosomeID < 1000000:
        identifier = '0' + str(chromosomeID)
    else:
        identifier = str(chromosomeID)

    print('# of iterations: {}'.format(iteration))
    print('{} \t ID: {}. Done in: {} seconds. \t OBJ. VALUE = {} \t Oper. Cost: LEAD: {}, TOOL: {}, PALLET: {}'.format(runFrom, identifier, durationSimPrint, round(objectiveFunctionValue), round(makespanCost), round(toolSwitchCost), round(palletReconfigureCost)))

    return objectiveFunctionValue, makespanCost, toolSwitchCost, palletReconfigureCost

if __name__ == '__main__':

    runUntil = (60*24*3) + 1 # +1 to end last day and get final report in terminal

    cncCapacity = 3
    toolStorageCapacity = 80
    palletMachine = 8
    palletCapacity = cncCapacity * palletMachine

    toolDelayPenalty = 15
    toolVerifyPenalty = 60 * 4              ##  4 hours
    allowedToolDuplicates = 2
    leadtimeCost = 100
    toolSwitchPenalty = 1
    toolSwitchDelay = 1
    palletReconfigurationPenalty = 100
    inputParameters = {'leadtimeCost': leadtimeCost, 'toolSwitchPenalty': toolSwitchPenalty, 'toolSwitchDelay': toolSwitchDelay, 'palletReconfigurationPenalty': palletReconfigurationPenalty, 'cncCapacity': cncCapacity, 'toolStorageCapacity': toolStorageCapacity, 'palletCapacity': palletCapacity, 'supervisedShift': 12}

    productVariety = 1
    toolConsumption = 1
    simDays = 7
    workload = (60 * 24 * simDays * cncCapacity)

    portfolio, ncDatabase = RQ2_05_DataInput.GetProductData()
    jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc = RQ2_05_DataInput.GenerateJobs(portfolio, ncDatabase, workload)
    toolStorageAct = RQ2_05_DataInput.getEmpiricalData()
    initialData = RQ2_05_DataInput.ClusterInitialData(jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, 'B', 1, toolStorageAct)

    sequenceVector, machineVector, palletVector = RQ2_05_DataInput.GetInitialVectors(jobList, cncCapacity, palletCapacity)
    sequenceVectorOLD = sequenceVector.copy
    machineVectorOLD = machineVector.copy
    palletVectorOLD = palletVector.copy
    geneRepresentation = RQ2_02_Functions.Safeguard(jobList, xrefJobPrecedence, [sequenceVector, machineVector, palletVector])
    sequenceVector = geneRepresentation[0]
    if sequenceVector == sequenceVectorOLD:
        raise ('no changes made!')
    machineVector = geneRepresentation[1]
    if machineVector == machineVectorOLD:
        raise ('no changes made!')
    palletVector = geneRepresentation[2]
    if palletVector == palletVectorOLD:
        raise ('no changes made!')
    with open('RQ2_03_Debug_Chromosome_sequenceVector.json', 'r') as fp:
        sequenceVector = json.load(fp)
    with open('RQ2_03_Debug_Chromosome_machineVector.json', 'r') as fp:
        machineVector = json.load(fp)
    with open('RQ2_03_Debug_Chromosome_palletVector.json', 'r') as fp:
        palletVector = json.load(fp)
    returnDict = dict()
    sumValue = calculate_fitness_value(initialData, 1, geneRepresentation, returnDict, inputParameters, 'Single')

    # print('')
    # print('Finished with objective function {}'.format(sumValue))