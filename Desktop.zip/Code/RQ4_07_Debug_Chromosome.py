from datetime import time
import time as timeDouble
from lib2to3.pgen2.pgen import generate_grammar
from msilib import sequence
# from numpy.core.numeric import False
from multiprocessing import Pool
from multiprocessing import Process
import multiprocessing
import pandas as pd
import simpy
import numpy as np
import random
import math
import threading
import sys
import json
from simpy import AllOf, Event
from itertools import count
# import RQ2_01_Model_Operations
import RQ4_06_Functions
from RQ4_05_DataInput import GetProductData, GenerateJobs, MutateJobs, getEmpiricalData, ClusterInitialData
from RQ4_01_Model_GA import GaCalcFitness

## general data input
cncCapacity = 2
runUntil = 60 * 24 * 2
cncCtoolCapacity = 150
cuttingPointsTotal = 2
cuttingPointsRandom = True
y1 = 0.3                                            ## selection rate, this determines the subset of the population to select a parent from
y2 = 0.3                                            ## section to select chromosomes to populate the new generation

populationSize = 50                    # refers to the number of unique chromosomes in a generation
swapProbability = 0.01
mutationProbability = 0.01

startTime = timeDouble.time()
startTimePrint = timeDouble.strftime('%Y-%m-%d %H:%M:%S', timeDouble.localtime(startTime))
endTime = startTime + (60*2)            # second parameter is amount of minutes

class Chromosome():

    debugChromosome = []
    evaluatedChromosomes = []
    id = 0
    
    def __init__(self, sequenceVector, machineVector, palletVector):
        self.sequenceVector = sequenceVector
        self.machineVector = machineVector
        self.palletVector = palletVector
        self.fitnessValue = None
        Chromosome.id += 1
        self.id = Chromosome.id
        Chromosome.debugChromosome.append(self)

def GetDebugChromosome():
    with open('RQ2_03_Debug_Chromosome_sequenceVector.json', 'r') as fp:
        sequenceVector = json.load(fp)
    with open('RQ2_03_Debug_Chromosome_machineVector.json', 'r') as fp:
        machineVector = json.load(fp)
    with open('RQ2_03_Debug_Chromosome_palletVector.json', 'r') as fp:
        palletVector = json.load(fp)
    Chromosome(sequenceVector, machineVector, palletVector)

productRatio = 1
toolConsumption = 1
toolRatio = 1
stoppingCriteriaGa = False
stoppingCriteriaPopulation = 0
stoppingCriteriaOffspring = False

if __name__ == '__main__':

    portfolio, ncDatabase = GetProductData()
    jobList, xrefJobOperation, xrefJobPrecedence, xrefJobNc = GenerateJobs(portfolio, ncDatabase)
    toolStorageAct = getEmpiricalData()
    initialData = ClusterInitialData(jobList, ncDatabase, xrefJobOperation, xrefJobPrecedence, xrefJobNc, cncCapacity, 'B', 1, toolStorageAct)

    cncCapacity = 3
    toolCapacity = 80
    palletCapacity = cncCapacity * 8
    supervisedShift = 18

    operMax = 9999
    toolMax = toolCapacity

    cncDepreciationCost = 100
    toolSwitchCost = 1
    palletSetupTime = 60 * 4
    palletSetupCost = 100
    inputParameters = {'cncDepreciationCost': cncDepreciationCost, 'toolSwitchCost': toolSwitchCost, 'palletSetupTime': palletSetupTime, 'palletSetupCost': palletSetupCost, 'cncCapacity': cncCapacity, 'toolCapacity': toolCapacity, 'palletCapacity': palletCapacity, 'supervisedShift': supervisedShift, 'operMax': operMax, 'toolMax': toolMax}

    modelParameters = inputParameters

    GetDebugChromosome()
    manager = multiprocessing.Manager()
    returnDict = manager.dict()
    debugChromosomes = Chromosome.debugChromosome[0]

    manager = multiprocessing.Manager()
    returnDict = manager.dict()

    startSim = timeDouble.time()
    GaCalcFitness(initialData, 1, [debugChromosomes.sequenceVector, debugChromosomes.machineVector, debugChromosomes.palletVector], returnDict, modelParameters, 'Debug')

    duration = timeDouble.time() - startSim