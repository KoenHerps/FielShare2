import json
import random
from re import A
from numpy.lib.function_base import select
import pandas as pd
import multiprocessing
import time
import copy
import numpy as np
from datetime import datetime, timedelta
import math
import csv
import random
from time import sleep
import re
import os

import itertools

mynumpy = np.zeros([10, 10])

mynumpy[2,0] = 2
mynumpy[0,1] = 1

Q = dict([(key, [0 for x in range(13)]) for key in range(10)])

print(Q)


# s1 = [3,4,1,7,5,0,6,2] ## sequence, index is job
# m1 = [1,2,1,1,2,2,1,2]
# p1 = [1,2,3,1,2,3,1,2]

# s2 = [3,0,1,7,5,4,2,6] ## sequence, index is job
# m2 = [2,2,2,1,1,2,1,2]
# p2 = [3,2,1,2,2,1,1,3]

# mKPo = []
# while len(mKPo) < 2:
#     kPo = random.randint(0, len(s1)-1)
#     if (kPo not in mKPo): ## make sure that k-points are not next to eachother, swap doesnt do anything
#         if (len(mKPo) < 1):
#             mKPo.append(kPo)
#         elif (abs(kPo-mKPo[0]) > 1):
#             mKPo.append(kPo)

# mKPo.sort()
# print('mKpo: {}'.format(mKPo))

# vector = [[job, seq, mach, pal] for job, seq, mach, pal in zip(range(len(s1)), s1, m1, p1)]
# vector.sort(key=lambda gene: gene[1], reverse=False)
# invVector = vector[mKPo[0]: mKPo[1]]
# invVector.sort(key=lambda gene: gene[1], reverse=True)
# for gene, lotus in zip(invVector, range(mKPo[0], mKPo[1])):
#     vector[lotus] = gene
# for gene, newSeq in zip(vector, range(len(s1))):
#     gene[1] = newSeq
# vector.sort(key=lambda gene: gene[0])

# startVector = [(job, sequence, machine, pallet) for job, sequence, machine, pallet in zip(range(len(s1)), s1, m1, p1)]
# startVector.sort(key=lambda gene: gene[1], reverse=False)
# geneVector = [(x[0], x[1], x[2], x[3]) for x in startVector]

# print('Start J: {}'.format([x for x in range(0, len(s1))]))
# print('Start S: {}'.format(s1))
# print('Start M: {}'.format(m1))
# print('Start P: {}'.format(p1))

# geneVector.insert(mKPo[0]+1, geneVector.pop(mKPo[1]))






# p01 = [s1, m1, p1]
# p02 = [s2, m2, p2]

# combined = False
# cutPoint = 3

# v1Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(len(s1)), s1, m1, p1)}
# v2Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(len(s2)), s2, m2, p2)}

# ## 1. construct Job+Seq genes
# ## 2. sort according to sequence
# ## 3. construct job vector
# v1Gene = [[job, sequence] for job, sequence in zip(range(len(s1)), s1)]
# v1Gene.sort(key=lambda seq: seq[1], reverse=False)
# v1JobVector = [x[0] for x in v1Gene]
# v2Gene = [[job, sequence] for job, sequence in zip(range(len(s2)), s2)]
# v2Gene.sort(key=lambda seq: seq[1], reverse=False)
# v2JobVector = [x[0] for x in v2Gene]

# ## 7. identify segments
# c1p2OX1, c1p2OX2 = [], []
# c1p2OXS = v2JobVector[cutPoint:cutPoint + 3]
# c2p1OX1, c2p1OX2 = [], []
# c2p1OXS = v1JobVector[cutPoint:cutPoint + 3]

# ## 8. apply crossover and track new vector
# offspring = []
# for recOX1, recOXS, recOX2, donorVec, p, vMapping in zip([c1p2OX1, c2p1OX1], [c1p2OXS, c2p1OXS], [c1p2OX2, c2p1OX2], [v1JobVector, v2JobVector], [p01, p02], [v1Mapping, v2Mapping]):
#     requiredLength = len(donorVec)
#     donorVec = [gene for gene in donorVec if gene not in recOXS]
#     while len(recOX1) < cutPoint:
#         for donorGeneIndex in range(len(donorVec)):
#             newGene = donorVec.pop(donorGeneIndex)
#             recOX1.append(newGene)
#             break
#     donorVec = [gene for gene in donorVec if gene not in [recOX1 + recOXS]]
#     while len(recOX1 + recOXS + recOX2) != requiredLength:
#         for donorGeneIndex in range(len(donorVec)):
#             newGene = donorVec.pop(donorGeneIndex)
#             recOX2.append(newGene)
#             break
#     ## remap to sequence values
#     jobVector = recOX1 + recOXS + recOX2
#     seqVector = [x for x in range(requiredLength)]
#     if combined:
#         macVector = [vMapping[job]['m'] for job in jobVector]
#         palVector = [vMapping[job]['p'] for job in jobVector]
#     else:
#         vVector = [(gene['s'], gene['m'], gene['p']) for k, gene in vMapping.items()]
#         vVector.sort(key=lambda gene: gene[0], reverse=False)
#         macVector = [x[1] for x in vVector]
#         palVector = [x[2] for x in vVector]
#     childJob = [(job, sequence, machine, pallet) for job, sequence, machine, pallet in zip(jobVector, seqVector, macVector, palVector)]
#     childJob.sort(key=lambda gene: gene[0], reverse=False)
    
#     cJobVector = [x[0] for x in childJob]
#     cSeqVector = [x[1] for x in childJob]
#     cMacVector = [x[2] for x in childJob]
#     cPalVector = [x[3] for x in childJob]

#     print('Child')
#     print('Job:      {}'.format(cJobVector))
#     print('Sequence: {}'.format(cSeqVector))
#     print('Machine:  {}'.format(cMacVector))
#     print('Pallet:   {}'.format(cPalVector))





### CODE TEST PMX

# nJobs = len(s1)

# v1Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(len(s1)), s1, m1, p1)}
# v2Mapping = {jobIndex: {'s': sequence, 'm': machine, 'p': pallet} for jobIndex, sequence, machine, pallet in zip(range(len(s2)), s2, m2, p2)}

# cutPoint = 3

# ## 1. construct Job+Seq genes
# ## 2. sort according to sequence
# ## 3. construct job vector
# v1Gene = [[job, sequence] for job, sequence in zip(range(len(s1)), s1)]
# v1Gene.sort(key=lambda seq: seq[1], reverse=False)
# v1JobVector = [x[0] for x in v1Gene]
# v2Gene = [[job, sequence] for job, sequence in zip(range(len(s2)), s2)]
# v2Gene.sort(key=lambda seq: seq[1], reverse=False)
# v2JobVector = [x[0] for x in v2Gene]

# ## 7. identify segments
# c1PMXS = v2JobVector[cutPoint:cutPoint + 3]
# c2PMXS = v1JobVector[cutPoint:cutPoint + 3]

# ## 8. apply crossover and track new vector
# offspring = []
# for recPMX, donorPMXS, discPMXS, vMapping in zip([v1JobVector, v2JobVector], [c1PMXS, c2PMXS], [c2PMXS, c1PMXS], [v1Mapping, v2Mapping]):
#     posPMXS = 0
#     print()
#     print('Start Chromosome: {}'.format(recPMX))
#     print('Discard PMXS:     {}'.format(discPMXS))
#     print('Donor   PMXS:     {}'.format(donorPMXS))
#     for donorGene, discGene in zip(donorPMXS, discPMXS):
#         ## if the received gene is not in the to-be-replaced recipient vector, find its index in remaining recipient vector
#         print('Donor Gene: {}'.format(donorGene))
#         if donorGene in list(set(recPMX) - set(discPMXS)): ## if the received gene is not in the to be changed sequence, find where it is
#             print('Donor Gene in child vector')
#             posRecGene = recPMX.index(donorGene)
#             print('Gene on index: {}'.format(posRecGene))
#             recPMX[posRecGene] = discGene
#             print('Temp. new recipient child: {}'.format(recPMX))
#         recPMX[cutPoint + posPMXS] = donorGene
#         print('Add gene [{}] on position: {}'.format(donorGene, (cutPoint + posPMXS)))
#         print('New recipient child: {}'.format(recPMX))
#         posPMXS += 1

#     ## remap to sequence values
#     jobVector = recPMX
#     seqVector = [x for x in range(len(jobVector))]
#     if combined:
#         macVector = [vMapping[job]['m'] for job in jobVector]
#         palVector = [vMapping[job]['p'] for job in jobVector]
#     else:
#         vVector = [(gene['s'], gene['m'], gene['p']) for k, gene in vMapping.items()]
#         vVector.sort(key=lambda gene: gene[0], reverse=False)
#         macVector = [x[1] for x in vVector]
#         palVector = [x[2] for x in vVector]

#     print('Job vector:      {}'.format(jobVector))
#     print('Sequence vector: {}'.format(seqVector))

#     childJob = [(job, sequence, machine, pallet) for job, sequence, machine, pallet in zip(jobVector, seqVector, macVector, palVector)]
#     childJob.sort(key=lambda gene: gene[0], reverse=False)

#     jobVectorNew = [x[0] for x in childJob]
#     seqVectorNew = [x[1] for x in childJob]
#     macVectorNew = [x[2] for x in childJob]
#     palVectorNew = [x[3] for x in childJob]

#     print()
#     print('Child')
#     print('Job:      {}'.format(jobVectorNew))
#     print('Sequence: {}'.format(seqVectorNew))
#     print('Machine:  {}'.format(macVectorNew))
#     print('Pallet:   {}'.format(palVectorNew))


# # child = Chromosome(curExp, curGen, [x[1] for x in childJob], [x[2] for x in childJob], [x[3] for x in childJob], p1.id, p2.id, fromCrossover)

