 # 0. python file,   1. problem file,    2. generations  3. optimal, 4. population size
import numpy as np
import itertools
import json
import os
import pandas as pd

from RQ4_06_Functions import calculateChangeIndex

class RLA():
    def __init__(self, alpha, gamma, epsilon, div, run):
        ##################################################################################################################
        #------------------------------------------------ Hyperparameters ------------------------------------------------
        # the learning rate
        self.alpha = alpha

        # the discount rate
        self.gamma = gamma

        # the exploration rate
        self.epsilon = epsilon
    
        ##################################################################################################################
        #--------------------------------------- action, state, and reward spaces ----------------------------------------
        # get all combinations of crossover and mutation probabilites and convert it to a list 
        self.actionSpace = []
        for pUX in range(div+1):
            for pOX in range(div+1):
                for pPMX in range(div+1):
                    for pXX in range(div+1):
                        for mMethod in range(3):
                            if (pUX + pOX + pPMX + pXX) == div:
                                self.actionSpace.append((pUX, pOX, pPMX, pXX, mMethod))

        # get the rewards table
        self.rewardSpace = np.array([200,   150,   100,   50,    25,
                                     150,   113,   75,    38,    19,
                                     100,   75,    50,    25,    13,
                                     50,    38,    25,    113,   7,
                                     0,     0,    -10,   -20,   -30,
                                    -1000, -1500, -2000, -2500, -3000])
       
        # a dictionary of all possible states, where the state is the key, and the value is the index for the q table and rewards space
        self.stateSpace = { '(HH, VHD)': 0, '(HH, HD)':1,  '(HH, MD)':2,  '(HH, LD)':3,  '(HH, VLD)':4,
                            '(H, VHD)':5,   '(H, HD)':6,   '(H, MD)':7,   '(H, LD)':8,   '(H, VLD)':9,
                            '(L, VHD)':10,  '(L, HD)':11,  '(L, MD)':12,  '(L, LD)':13,  '(L, VLD)':14,
                            '(LL, VHD)':15, '(LL, HD)':16, '(LL, MD)':17, '(LL, LD)':18, '(LL, VLD)':19,
                            '(S, VHD)':20,  '(S, HD)':21,  '(S, MD)':22,  '(S, LD)':23,  '(S, VLD)':24,
                            '(I, VHD)':25,  '(I, HD)':26,  '(I, MD)':27,  '(I, LD)':28,  '(I, VLD)':29}

        # initilize the Q-table
        self.Q = np.zeros([len(self.stateSpace), len(self.actionSpace)])

        ##################################################################################################################
        # ----------------------------------------------- initialization  ------------------------------------------------
        # a variable keeping track og hum many times the RL agent is iterared
        self.iterRL = 0
        self.iterGA = 0
        
        # a variable keeping track of how much rewards it has recieved
        self.collected  = 0

        # create an array to keep count how often each action was taken
        self.actionCount = np.zeros(len(self.actionSpace))

        # the previous population is set to an empty list
        self.generations = []

        # the previous fitness variable is initilized with a verh high cost
        self.prevFitness = float('inf')
        
        # the current fitness delta
        self.fitness = 0
        self.fitnessDeltas = []

        # the current change index
        self.changeIndex = 1
        self.changeIndices = []
        
        # the current reward awarded
        self.reward = 0

        # initialize the first state (high cost difference (good), and very high diversity)
        self.currState = 0
        self.nextState = 0

        # the first actions are given
        self.action = self.actionSpace.index((div, 0, 0, 0, 0))

        # # initialie the json file
        # self.json = str(run) + '.json'
        # with open(self.json, 'w') as f:
        #     json.dump({}, f)

    def initializeRL(self):

        self.actionCount = np.zeros(len(self.actionSpace))
        self.actionCount[self.action] += 1
        # self.__persistResults(self.iterRL)

        return [self.actionSpace[self.action][0], self.actionSpace[self.action][1], self.actionSpace[self.action][2], self.actionSpace[self.action][3]], self.actionSpace[self.action][4]

    def analyzeRL(self, generations):

        print('\tRLA - GA')
        print()

        self.fitness = self.__getFitness(generations)
        self.fitnessDeltas.append(self.fitness)
        self.changeIndex = self.__getChangeIndex(generations)
        self.changeIndices.append(self.changeIndex)

        self.nextState = self.__getNewState(self.fitness, self.changeIndex)
        self.reward = self.__getReward()
        self.collected += self.reward

        print('\tFitness deltas: {}'.format([round(x, 3) for x in self.fitnessDeltas]))
        print('\tChange Indexes: {}'.format([round(x, 3) for x in self.changeIndices]))

    def updateRL(self):

        self.__persistResults(self.iterRL)

        ## Bellman equation
        self.Q[self.currState, self.action] += self.alpha * (self.reward + self.gamma * self.__getMax(1, self.Q[self.nextState]) - self.Q[self.currState, self.action])
        self.currState = self.nextState

    def iterateRL(self):

        if np.random.random() < self.epsilon:
            self.action = int(np.random.randint(low=0, high=len(self.actionSpace)))
        else:
            self.action = int(self.__getMax(0, (self.Q[self.currState])))

        self.actionCount[self.action] += 1

        return [self.actionSpace[self.action][0], self.actionSpace[self.action][1], self.actionSpace[self.action][2], self.actionSpace[self.action][3]], self.actionSpace[self.action][4]

    def __findState(self, state):

        for i in self.stateSpace:
            if self.stateSpace[i] == state:
                return i

    def __getMax(self, reqParameter, qRow):
        ## reqParameter; 1 if value is required, 0 if index in row is required

        bests = []
        best = float('inf')
        for qIndex in range(len(qRow)):
            qVal = qRow[qIndex]
            if qVal < best:
                bests = []
                best = qVal
                bests.append([qIndex, qVal])
            elif qVal == best:
                bests.append([qIndex, qVal])

        arbitraryPick = np.random.choice(np.arange(len(bests)))

        return bests[arbitraryPick][reqParameter]

    def __getFitness(self, generations):
        
        fitnesses = [(generation, generation.bestGenerationResult) for generation in generations]
        bestFitness = min(fitnesses, key = lambda t: t[1])[1]
        delta = self.prevFitness - bestFitness
        deltaFitness = delta / self.prevFitness
        print('\tPrev Fitness:\t{}'.format(round(self.prevFitness, 1)))
        print('\tBest Fitness:\t{}'.format(round(bestFitness, 1)))
        print('\tDelta (%):\t{}'.format(round(deltaFitness, 3)))
        self.prevFitness = bestFitness
        
        return deltaFitness

    def __getChangeIndex(self, generations):

        changeRatios = []
        for generation in generations:
            for chromosome in generation.population:
                if chromosome.parent1 != None:
                    changeIndexMachine, changeIndexPallet = calculateChangeIndex(chromosome)
                    changeRatio = (changeIndexMachine + changeIndexPallet) / 2
                    changeRatios.append(changeRatio)
                    # print('Change Ratios: {} - {} - {}'.format(changeRatioSeq, changeRatioMachine, changeRatioPallet))

        totalChangeIndex = sum(changeRatios) / len(changeRatios)

        print('\tChange index:\t{}'.format(round(totalChangeIndex, 3)))

        return totalChangeIndex

    def __getNewState(self, fitness, changeIndex):

        if fitness < -0.005:
            fState = 'I'
        elif fitness < 0.005:
            fState = 'S'
        elif fitness < 0.01:
            fState = 'LL'
        elif fitness < 0.0175:
            fState = 'L'
        elif fitness < 0.025:
            fState = 'H'
        else:
            fState = 'HH'

        if changeIndex < 0.1:
            cState = 'VLD'
        elif changeIndex < 0.3:
            cState = 'LD'
        elif changeIndex < 0.6:
            cState = 'MD'
        elif changeIndex < 0.9:
            cState = 'HD'
        else:
            cState = 'VHD'

        newState = '(' + fState + ', ' + cState + ')'
        indexState = self.stateSpace[newState]

        return indexState

    def __getReward(self):

        reward = self.rewardSpace[self.nextState]
        return reward

    def __persistResults(self, iterRL):
        
        action = self.actionSpace[self.action]
        results = {'state': self.__findState(self.currState), 'action': [int(action[0]), int(action[1]), int(action[2]), int(action[3]), int(action[4])], 'fitness delta': float(round(self.fitness, 3)), 'change index': float(round(self.changeIndex, 3)), 'new state': self.__findState(self.nextState), 'reward': int(self.reward), 'collected': int(self.collected)}
        
        # with open(self.json, 'r+') as f:
        #     data = json.load(f)
        #     data.update({iterRL:results})
        #     f.seek(0)
        #     json.dump(data, f, indent=4)
        
        self.iterRL += 1

        print()        
        for i in results:
            print('\t' + i + ':', results[i])
        print()

def rlTune(RLA, generations):

    for gen in range(generations):
        if gen == 0:
            pUX, pOX, pPMX, pXX, mMethod = RLA.initializeRL()
        else:
            pUX, pOX, pPMX, pXX, mMethod = RLA.iterateRL(RLA.iterRL)

        generation = 'add code with GA'

        RLA.observe(generation)

if __name__ == '__main__':
    alpha = 0.7
    gamma = 0.1
    epsilon = 0.3
    rlGaAgent = RLA(alpha, gamma, epsilon, 5, 1)
