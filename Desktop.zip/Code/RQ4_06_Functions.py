# from audioop import avg
# from datetime import time
from re import A
# import pandas as pd
# import simpy
import numpy as np
import random
import math
# import threading
# import sys
# from simpy import AllOf, Event
# from itertools import count
# from multiprocessing import Process

def CalculateSupervisedTimes(timeAct, supervisedShiftLength):
    
    timeDaysAct = (timeAct // (24 * 60))
    timeMinuteAct = timeAct - (timeDaysAct * 24 * 60)                                       ## get the complete days by //-operator. Sub reduce loadTime with full days
    if (timeMinuteAct < (supervisedShiftLength * 60)):                                      # if start is earlier than beginning of unsupervised shift
        start1 = timeAct
        timeRemaining = ((supervisedShiftLength * 60) - timeMinuteAct)
        start2 = ((timeDaysAct + 1) * 24 * 60)                                              #   2nd start is begin of supervised shift
    else:                                                                                   # if start is in unsupervised time
        start1 = ((timeDaysAct + 1) * 24 * 60)                                              #   new start is at start of supervised shift
        timeRemaining = 0                                                                   #   remaining minutes is 0 (all done at start)
        start2 = start1                                                                     #   2nd start is also at supervised shift

    # print('Check time:\nActual start: {}, Start 1: {}, Remaining time: {}, Start 2 at: {}'.format(timeAct, start1, timeRemaining, start2))

    return start1, timeRemaining, start2

def TRM(toolStorageTemp, jobListTemp, jobDatabase, ncDatabase, toolStorageCapacity):

    tobeRemoved = len(toolStorageTemp) - toolStorageCapacity
    toolRemoveList = []
    toolTRMList = []

    for toolNumber in toolStorageTemp:
        trmVal = len(jobListTemp) + 1
        for j in range(len(jobListTemp)):
            uidJob = jobListTemp[j]
            if toolNumber in ncDatabase[jobDatabase[uidJob]['nc']]['ta']:
                trmVal = j
                break
        toolTRMList.append((toolNumber, trmVal))
        # print('{}/{}:\t{}'.format((len(toolStorageTemp) - len(toolTRMList)), printVal, toolTRMList))
    toolTRMList.sort(key=lambda t: t[1], reverse=True)
    toolTRMList = [t[0] for t in toolTRMList]
    
    while len(toolRemoveList) != tobeRemoved:
        toolRemoveList.append(toolTRMList.pop(0))

    return toolRemoveList

def calculateSimilarity(jobList, ncDatabase, xrefJobNc, resource):

    ## JACCARD similarity coefficient
        # a = tools in both operations
        # b = tool in operation i
        # c = tool in operation j
                # JAC sim = a / (a + b + c)
    a = 0   # tools required by both
    b = 0   # tools required by i
    c = 0   # tools required by j
    d = 0   # tools required by none
    
    jobListSimilarityAll = []
    for jobI in jobList:
        similarities = []
        testAgainst = [x for x in jobList if (x != jobI)]
        resourcesI = [x for x in ncDatabase[xrefJobNc[jobI]][resource]]
        for jobJ in testAgainst:
            resourcesJ = [x for x in ncDatabase[xrefJobNc[jobJ]][resource]]
            resourcesA = len([x for x in resourcesI if x in resourcesJ])
            resourcesB = len(list(set(resourcesI) - set(resourcesJ)))
            resourcesC = len(list(set(resourcesJ) - set(resourcesI)))
            similarities.append(resourcesA / (resourcesA + resourcesB + resourcesC))
            a += resourcesA
            b += resourcesB
            c += resourcesC
        similarity = sum(similarities) / len(similarities)
        jobListSimilarityAll.append(similarity)

    jobListSimilarity = sum(jobListSimilarityAll) / len(jobListSimilarityAll)

    return jobListSimilarity

def determineChangeovers(resourceVector, sequenceVector):

    changeoversDct =  {r: [] for r in list(set(resourceVector))}
    trackLatest  =  {r: None for r in list(set(resourceVector))}
    for r in list(set(resourceVector)):
        for seq in range(len(sequenceVector)):
            if r == resourceVector[seq]:
                if trackLatest[r] != None:
                    changeoversDct[r].append((trackLatest[r], sequenceVector[seq]))
                trackLatest[r] = sequenceVector[seq]
    
    changeoversLst = []
    for r in list(set(resourceVector)):
        for changeover in changeoversDct[r]:
            changeoversLst.append(changeover)

    return changeoversLst

def calculateChangeIndex(child):

    differentMachineChangovers = [True for co in child.changeoversMachine if (co not in child.parents[0].changeoversMachine) and (co not in child.parents[1].changeoversMachine)]
    if len(child.changeoversMachine) == 0:
        changeIndexMachine = 1
    else:
        changeIndexMachine = len(differentMachineChangovers) / len(child.changeoversMachine)

    differentPalletChangovers = [True for co in child.changeoversPallet if (co not in child.parents[0].changeoversPallet) and (co not in child.parents[1].changeoversPallet)]
    if len(child.changeoversPallet) == 0:
        changeIndexPallet = 1
    else:
        changeIndexPallet = len(differentPalletChangovers) / len(child.changeoversPallet)

    return changeIndexMachine, changeIndexPallet

def determineCutpoints(cProb, nJobs):

    cutPoints = [random.randint(0, (nJobs - 1))]

    picks = []
    length = int(math.ceil(nJobs * cProb))
    for cutPoint2 in [cutPoints[0] - length, cutPoints[0] + length]:
        if (cutPoint2 >= 0) and (cutPoint2 <= nJobs - 1) and (cutPoint2 not in cutPoints):
            picks.append(cutPoint2)
    if len(picks) > 1:
        arbitraryPick = np.random.choice(picks)
        cutPoints.append(arbitraryPick)
    else:
        cutPoints.append(picks[0])
    cutPoints.sort()


    return cutPoints