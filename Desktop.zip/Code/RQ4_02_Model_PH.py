from asyncio.format_helpers import extract_stack
from datetime import datetime, time, timedelta
from doctest import testfile
from re import S
# from statistics import mean, stdev
import time as timeDouble
# from lib2to3.pgen2.pgen import generate_grammar
# from msilib import sequence
# from numpy.core.numeric import False
# from multiprocessing import Pool
# from multiprocessing import Process
import multiprocessing
from tkinter import N, TRUE
from typing import overload
import pandas as pd
# import simpy
import numpy as np
import random
import math
# import threading
# import sys
# from tqdm import tqdm
# import csv
import json


def PhBuildSequences(initialData, inputParametersPH):

    cncCapacity = inputParametersPH['cncCapacity']
    cncDepreciationCost = inputParametersPH['cncDepreciationCost']
    palletSetupCost = inputParametersPH['palletSetupCost']
    palletSetupTime = inputParametersPH['palletSetupTime']
    toolSwitchCost = inputParametersPH['toolSwitchCost']

    palletCapacity = inputParametersPH['palletCapacity']
    toolCapacity = inputParametersPH['toolCapacity']
    supervisedShift = inputParametersPH['supervisedShift']

    jobList = initialData[0].copy()
    ncDatabase = initialData[1].copy()
    xrefJobNc = initialData[4].copy()
    toolStorageAct = initialData[6].copy()
    jobFamily = initialData[7].copy()
    xrefJobSuccession = initialData[8].copy()

    ## FIRST:   Create the existing tool storage per machine
    
    toolStorageAct = initialData[6]
    toolStorageMachine = {}
    for machineId in toolStorageAct.keys():
        toolStorageMachine[int(machineId)] = [x for x in toolStorageAct[machineId].keys()]
    
    ## SECOND:  Set the total threshold per machine and per pallet

    totalWorkload = 0
    for job in jobList:
        totalWorkload += ncDatabase[xrefJobNc[job]]['cycle']

    thresholdMachine = totalWorkload / cncCapacity
    thresholdPallet = totalWorkload / palletCapacity

    ## THIRD:   Allocate jobs to pallets based on:
    #               1. pallet similarity of current job allocated to it

    jobAllocation = {}
    for job in jobList:
        jobAllocation[job] = {'p': None, 'm': None, 'seq': None}

    palletAllocation = {}
    for p in range(palletCapacity):
        palletAllocation[p] = {'jobs': [], 'workload': 0, 'pallets': [], 'randomSearch': True}   
    
    palletOpenJobList = jobList.copy()
    for _p in palletAllocation:
        while palletOpenJobList != []:
            allocateJobInstance = None
            if palletAllocation[_p]['randomSearch']:
                allocateJobCandidate = palletOpenJobList[0]
                allocateJobCandidateCycle = ncDatabase[xrefJobNc[allocateJobCandidate]]['cycle']
                ## if the randomly allocated job (and thus doesnt fit in the current pallets) increases the threshold higher than average ==> break, unless it is the final pallet
                if ((palletAllocation[_p]['workload'] + allocateJobCandidateCycle) > thresholdPallet) and (palletAllocation[_p]['workload'] > 0) and (_p != len(palletAllocation)-1):
                    break
                ## if this is not the case allocate the job
                else:
                    allocateJobInstance = allocateJobCandidate
                    palletAllocation[_p]['randomSearch'] = False
            else:
                for allocateJobCandidate in palletOpenJobList:
                    allocateJobCandidatePallet = ncDatabase[xrefJobNc[allocateJobCandidate]]['pa']
                    if allocateJobCandidatePallet in palletAllocation[_p]['pallets']:
                        allocateJobInstance = allocateJobCandidate
                        break
            if allocateJobInstance == None:
                palletAllocation[_p]['randomSearch'] = True
            else:
                jobAllocation[allocateJobInstance]['p'] = _p
                palletAllocation[_p]['jobs'].append(allocateJobInstance)
                palletAllocation[_p]['workload'] += ncDatabase[xrefJobNc[allocateJobInstance]]['cycle']
                allocateJobPallet = ncDatabase[xrefJobNc[allocateJobInstance]]['pa']
                if allocateJobPallet not in palletAllocation[_p]['pallets']:
                    palletAllocation[_p]['pallets'].append(allocateJobPallet)
                palletOpenJobList.remove(allocateJobInstance)
            ## stopping criteria
            if (palletAllocation[_p]['workload'] > thresholdPallet) or (palletOpenJobList == []):
                break

    ## to check the workload per pallet
    # for _p in palletAllocation:
    #     print('Pallet [{}]: {}\t{}'.format(_p, round(palletAllocation[_p]['workload']), round((palletAllocation[_p]['workload']-thresholdPallet))))
    #     print('\tUnique Pallets: {}'.format(len(palletAllocation[_p]['pallets'])))

    ## FOURTH:  Allocate jobs to machines based on tool similarities

    machineAllocation = {}
    for _m in range(cncCapacity):
        machineAllocation[_m] = {'jobs': [], 'workload': 0, 'toolset': [], 'randomSearch': True}

    machineOpenJobList = jobList.copy()
    jobFamilyMachine = jobFamily.copy()
    for _m in machineAllocation:
        while machineOpenJobList != []:
            allocateJobInstance = None
            if machineAllocation[_m]['randomSearch']:
                allocateJobCandidate = machineOpenJobList[0]
                allocateJobCandidateCycle = ncDatabase[xrefJobNc[allocateJobCandidate]]['cycle']
                ## if the randomly allocated job (and thus doesnt fit in the current pallets) increases the threshold higher than average ==> break, unless it is the final pallet
                if ((machineAllocation[_m]['workload'] + allocateJobCandidateCycle) > thresholdMachine) and (_m != len(machineAllocation)-1):
                    break
                else:
                    allocateJobInstance = allocateJobCandidate
                    machineAllocation[_m]['randomSearch'] = False
            else:
                bestFit = toolCapacity + 1
                for allocateJobCandidate in machineOpenJobList:
                    allocateJobCandidateTools = ncDatabase[xrefJobNc[allocateJobCandidate]]['ta']
                    allocateJobCandidateUniqueTools = len(list(set(allocateJobCandidateTools) - set(machineAllocation[_m]['toolset'])))
                    if allocateJobCandidateUniqueTools < bestFit:
                        bestFit = allocateJobCandidateUniqueTools
                        allocateJobInstance = allocateJobCandidate
            if allocateJobInstance == None:
                machineAllocation[_m]['randomSearch'] = True
            else:
                allocateJobFamily = None
                for family in jobFamilyMachine:
                    if allocateJobInstance in jobFamilyMachine[family]:
                        allocateJobList = jobFamilyMachine[family]
                        allocateJobFamily = family
                        break
                jobFamilyMachine.pop(allocateJobFamily, None)
                for allocateJob in allocateJobList:
                    jobAllocation[allocateJob]['m'] = _m
                    machineAllocation[_m]['jobs'].append(allocateJob)
                    machineAllocation[_m]['workload'] += ncDatabase[xrefJobNc[allocateJob]]['cycle']
                    allocateJobTools = ncDatabase[xrefJobNc[allocateJob]]['ta']
                    allocateJobUniqueTools = list(set(allocateJobTools) - set(machineAllocation[_m]['toolset']))
                    machineAllocation[_m]['toolset'].extend(allocateJobUniqueTools)
                    machineOpenJobList.remove(allocateJob)
            ## stopping criteria
            if (machineAllocation[_m]['workload'] > thresholdMachine) or (machineOpenJobList == []):
                break

    ## to check the workload per pallet
    # for machine in machineAllocation:
    #     print('Machine [{}]: {}\t{}'.format(machine, round(machineAllocation[machine]['workload']), round((machineAllocation[machine]['workload']-thresholdMachine))))

    # for job in jobList:
    #     print(jobAllocation[job])

    ## FIFTH:   Sequence jobs based on least differences rule based on previous operation per machine, assign index

    scheduleOpenJobList = jobList.copy()
    sequenceVector = [-1 for job in jobList]
    palletTypeTrack = {_p: None for _p in palletAllocation}
    machineToolTrack = {_m: toolStorageMachine[_m] for _m in machineAllocation}
    jobEligible = {_j: False for _j in jobList}
    ## instantiate the eligibility claim
    for _j in jobEligible:
        if _j[-2:] == 'S1':
            jobEligible[_j] = True
    sequence = 0
    
    while scheduleOpenJobList != []:
        scheduleJobInstance = None
        jobEligibleTrue = [job for job in jobEligible if jobEligible[job] if job in scheduleOpenJobList]
        palletFit = False
        toolFit = toolCapacity + 1
        for _m in machineAllocation:
            for _p in palletAllocation:
                for _j in jobEligibleTrue:
                    currentPalletType = palletTypeTrack[_p]
                    requiredPalletType = ncDatabase[xrefJobNc[_j]]['pa']
                    toolsRequired = ncDatabase[xrefJobNc[_j]]['ta']
                    toolsToBeLoaded = list(set(toolsRequired) - set(machineToolTrack[_m]))
                    amountOfToolsToBeLoaded = len(toolsToBeLoaded)
                    ## code if the required pallet is the same
                    if (currentPalletType == requiredPalletType):
                        if (amountOfToolsToBeLoaded < toolFit) or (palletFit == False):
                            scheduleJobInstance = _j
                            toolFit = amountOfToolsToBeLoaded
                        palletFit = True
                    ## code to check tool similarity IF there is no matching pallet found YET
                    elif palletFit == False:
                        if (amountOfToolsToBeLoaded < toolFit):
                            scheduleJobInstance = _j
                            toolFit = amountOfToolsToBeLoaded
        jobAllocation[scheduleJobInstance]['seq'] = sequence
        # jobIndexJobList = jobList.index(scheduleJobInstance)
        # sequenceVector[jobIndexJobList] = sequence
        scheduleOpenJobList.remove(scheduleJobInstance)
        newJobeligible = xrefJobSuccession[scheduleJobInstance]
        if newJobeligible != None:
            jobEligible[newJobeligible] = True
        sequence += 1
    
    sequenceVector = [jobAllocation[_j]['seq'] for _j in jobList]
    machineVector = [jobAllocation[_j]['m'] for _j in jobList]
    palletVector = [jobAllocation[_j]['p'] for _j in jobList]

    return sequenceVector, machineVector, palletVector